package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.UserProfile
import com.example.model.UserRole
import com.example.ui.theme.NexCyan
import com.example.ui.theme.NexDeepBlack
import com.example.ui.theme.NexElectricBlue
import com.example.ui.theme.NexStatusSuspended

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccessDeniedScreen(
    requiredRole: String,
    currentUser: UserProfile,
    onBack: () -> Unit,
    onSwitchRole: (UserRole) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ADMIN AUTH GUARD 🔐", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("access_denied_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(NexStatusSuspended.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Lock,
                    contentDescription = "Accès Refusé",
                    tint = NexStatusSuspended,
                    modifier = Modifier.size(48.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Accès Administrateur Restreint",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = NexStatusSuspended.copy(alpha = 0.15f),
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                Text(
                    text = "Code HTTP 403 : FORBIDDEN",
                    color = NexStatusSuspended,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Cette interface et ses fonctions sont protégées par le système ADMIN AUTH GUARD côté serveur. Vos identifiants actuels ne disposent pas des privilèges requis.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Utilisateur actuel :", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("@${currentUser.username}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Rôle actuel :", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(currentUser.role.displayName, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = NexStatusSuspended)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Rôle requis :", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(requiredRole, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = NexCyan)
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(
                        text = "🔒 Protection Sécurité : Aucun jeton, mot de passe ou clé secrète n'est exposé. Toute tentative d'accès non autorisé est journalisée dans les registres d'audit.",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            Button(
                onClick = onBack,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("access_denied_return_button"),
                colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue)
            ) {
                Text("Retourner à l'accueil sécurisé", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = { onSwitchRole(UserRole.SUPER_ADMIN) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("access_denied_switch_admin_button")
            ) {
                Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp), tint = NexCyan)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Mode Démo : Se connecter comme Super Admin", color = NexCyan)
            }
        }
    }
}
