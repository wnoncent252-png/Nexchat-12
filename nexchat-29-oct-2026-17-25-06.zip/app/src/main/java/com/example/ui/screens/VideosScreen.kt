package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.UserProfile
import com.example.model.VideoPost
import com.example.ui.theme.NexCyan
import com.example.ui.theme.NexDeepBlack
import com.example.ui.theme.NexElectricBlue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideosScreen(
    videos: List<VideoPost>,
    currentUser: UserProfile,
    onToggleLike: (String) -> Unit,
    onAddComment: (String, String) -> Unit,
    onPublishVideo: (String) -> Unit,
    onReportVideo: (String) -> Unit
) {
    var showPublishDialog by remember { mutableStateOf(false) }
    var selectedVideoForComments by remember { mutableStateOf<VideoPost?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PlayCircle, contentDescription = null, tint = NexCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Vidéos NexChat", fontWeight = FontWeight.Bold)
                    }
                },
                actions = {
                    FilledTonalButton(
                        onClick = { showPublishDialog = true },
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = NexElectricBlue),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.padding(end = 8.dp).testTag("publish_video_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Publier", color = Color.White, fontSize = 12.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = NexCyan)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Espace Vidéos publié & partagé (distinct des diffusions en Direct).",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            items(videos) { post ->
                val isLikedByMe = post.likedByUsers.contains(currentUser.userId)

                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().testTag("video_post_${post.id}")
                ) {
                    Column {
                        // Author header
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(NexElectricBlue),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = post.authorName.take(1),
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(post.authorName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text("@${post.authorUsername}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            IconButton(onClick = { onReportVideo(post.id) }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "Options", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        // Simulated Video Player Stage
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color(0xFF0F172A), Color(0xFF070B12))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(54.dp)
                                        .clip(CircleShape)
                                        .background(NexCyan.copy(alpha = 0.25f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = "Lire",
                                        tint = NexCyan,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Lecteur Vidéo H.264 / WebM HD",
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }

                            Surface(
                                color = Color.Black.copy(alpha = 0.6f),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp)
                            ) {
                                Text(
                                    text = post.videoDurationText,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        // Caption & tags
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = post.caption,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                post.tags.forEach { tag ->
                                    Text("#$tag", fontSize = 11.sp, color = NexCyan, fontWeight = FontWeight.SemiBold)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                            Spacer(modifier = Modifier.height(6.dp))

                            // Interactive Bar (Like toggle, Comments, Share, Report)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Like Button (Toggleable with immediate server calculation)
                                TextButton(
                                    onClick = { onToggleLike(post.id) },
                                    modifier = Modifier.testTag("like_btn_${post.id}")
                                ) {
                                    Icon(
                                        imageVector = if (isLikedByMe) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                        contentDescription = "J'aime",
                                        tint = if (isLikedByMe) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${post.likesCount}",
                                        fontWeight = if (isLikedByMe) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isLikedByMe) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                // Comments Button
                                TextButton(
                                    onClick = { selectedVideoForComments = post },
                                    modifier = Modifier.testTag("comment_btn_${post.id}")
                                ) {
                                    Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Commentaires", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("${post.commentsCount}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }

                                // Share
                                TextButton(onClick = { /* Share in chat */ }) {
                                    Icon(Icons.Default.Share, contentDescription = "Partager", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("${post.sharesCount}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }

                                // Report
                                IconButton(onClick = { onReportVideo(post.id) }) {
                                    Icon(Icons.Default.Report, contentDescription = "Signaler", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Modal: Publish New Video
    if (showPublishDialog) {
        var captionText by remember { mutableStateOf("") }
        Dialog(onDismissRequest = { showPublishDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Publier une Vidéo sur NexChat", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("Partagez votre contenu avec la communauté. Format HD pris en charge.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(100.dp),
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.VideoCall, contentDescription = null, tint = NexCyan, modifier = Modifier.size(32.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Vidéo sélectionnée depuis l'appareil", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = captionText,
                        onValueChange = { captionText = it },
                        placeholder = { Text("Ajoutez une légende...") },
                        modifier = Modifier.fillMaxWidth().testTag("publish_video_caption_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { showPublishDialog = false }, modifier = Modifier.weight(1f)) {
                            Text("Annuler")
                        }
                        Button(
                            onClick = {
                                if (captionText.isNotBlank()) {
                                    onPublishVideo(captionText)
                                    showPublishDialog = false
                                }
                            },
                            enabled = captionText.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue),
                            modifier = Modifier.weight(1f).testTag("confirm_publish_video_button")
                        ) {
                            Text("Publier", color = Color.White)
                        }
                    }
                }
            }
        }
    }

    // Modal: Comments Sheet
    if (selectedVideoForComments != null) {
        val targetPost = selectedVideoForComments!!
        var commentInput by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { selectedVideoForComments = null }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth().fillMaxHeight(0.75f).padding(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Commentaires (${targetPost.comments.size})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        IconButton(onClick = { selectedVideoForComments = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Fermer")
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

                    LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(targetPost.comments) { c ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(c.authorName, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = NexCyan)
                                        Text(SimpleDateFormat("HH:mm", Locale.FRENCH).format(Date(c.timestamp)), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(c.text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = commentInput,
                            onValueChange = { commentInput = it },
                            placeholder = { Text("Écrire un commentaire...") },
                            modifier = Modifier.weight(1f).testTag("video_comment_input"),
                            shape = RoundedCornerShape(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = {
                                if (commentInput.isNotBlank()) {
                                    onAddComment(targetPost.id, commentInput)
                                    commentInput = ""
                                }
                            },
                            colors = IconButtonDefaults.iconButtonColors(containerColor = NexElectricBlue),
                            modifier = Modifier.testTag("submit_video_comment_btn")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Envoyer", tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}
