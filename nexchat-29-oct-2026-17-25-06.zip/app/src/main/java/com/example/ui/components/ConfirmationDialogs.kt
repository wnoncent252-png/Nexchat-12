package com.example.ui.components

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.security.AdminOperationResult
import com.example.ui.theme.*

/**
 * Visual Confirmation Dialog for Sensitive Administrative Actions (Blocking, Suspensions, Bans, Deletions).
 * Enforces deliberate operator confirmation before applying any disruptive mutation.
 */
@Composable
fun SensitiveActionConfirmDialog(
    title: String,
    targetIdentifier: String,
    actionDescription: String,
    consequenceNotice: String,
    confirmButtonLabel: String = "Confirmer l'opération",
    isDestructive: Boolean = true,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val accentColor = if (isDestructive) Color(0xFFEF4444) else NexCyan

    val infiniteTransition = rememberInfiniteTransition(label = "pulse_dialog_button")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 750),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(dismissOnBackPress = true, dismissOnClickOutside = false),
        modifier = Modifier
            .testTag("sensitive_action_confirm_dialog")
            .onKeyEvent { event ->
                if (event.type == KeyEventType.KeyUp) {
                    when (event.key) {
                        Key.Enter, Key.NumPadEnter -> {
                            onConfirm()
                            true
                        }
                        Key.Escape -> {
                            onDismiss()
                            true
                        }
                        else -> false
                    }
                } else false
            },
        icon = {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.15f))
                    .border(1.dp, accentColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isDestructive) Icons.Default.Warning else Icons.Default.Security,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(26.dp)
                )
            }
        },
        title = {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Person,
                            contentDescription = null,
                            tint = NexCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Entité ciblée :",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = targetIdentifier,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium,
                                color = NexCyan
                            )
                        }
                    }
                }

                Text(
                    text = actionDescription,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Surface(
                    color = accentColor.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            Icons.Default.Info,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(16.dp).padding(top = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = consequenceNotice,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = accentColor,
                    contentColor = if (isDestructive) Color.White else NexDeepBlack
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .graphicsLayer {
                        scaleX = pulseScale
                        scaleY = pulseScale
                    }
                    .testTag("dialog_confirm_button")
            ) {
                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(confirmButtonLabel, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("dialog_cancel_button")
            ) {
                Text("Annuler")
            }
        }
    )
}

/**
 * Visual Confirmation Dialog for Dynamic Server Configuration changes.
 */
@Composable
fun ConfirmConfigChangeDialog(
    configTitle: String,
    changeSummary: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_config_dialog_button")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 750),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .testTag("confirm_config_change_dialog")
            .onKeyEvent { event ->
                if (event.type == KeyEventType.KeyUp) {
                    when (event.key) {
                        Key.Enter, Key.NumPadEnter -> {
                            onConfirm()
                            true
                        }
                        Key.Escape -> {
                            onDismiss()
                            true
                        }
                        else -> false
                    }
                } else false
            },
        icon = {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(NexElectricBlue.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.SettingsSuggest, contentDescription = null, tint = NexCyan, modifier = Modifier.size(24.dp))
            }
        },
        title = {
            Text("Appliquer la configuration dynamique ?", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Paramètre : $configTitle",
                    fontWeight = FontWeight.SemiBold,
                    color = NexCyan,
                    fontSize = 13.sp
                )
                Text(
                    text = changeSummary,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "⚡ Ces modifications seront propagées immédiatement au backend et aux clients sans nécessiter de recompilation de l'APK.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue),
                modifier = Modifier
                    .graphicsLayer {
                        scaleX = pulseScale
                        scaleY = pulseScale
                    }
                    .testTag("confirm_config_apply_btn")
            ) {
                Text("Sauvegarder sur le serveur", color = Color.White)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Annuler")
            }
        }
    )
}

/**
 * Secure Audit Log Export Dialog with PII protection, format selection (JSON / CSV),
 * preview viewer, copy-to-clipboard, and system share intent.
 */
@Composable
fun ExportLogsModal(
    onExportLogs: (format: String) -> AdminOperationResult<String>,
    onDismiss: () -> Unit,
    onFeedback: (String) -> Unit
) {
    var selectedFormat by remember { mutableStateOf("JSON") }
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    val exportResult = remember(selectedFormat) {
        onExportLogs(selectedFormat)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(20.dp))
                .border(1.dp, NexCyan.copy(alpha = 0.4f), RoundedCornerShape(20.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(NexCyan.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, tint = NexCyan, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("EXPORT SÉCURISÉ DES JOURNAUX", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Protection PII & Événements certifiés", style = MaterialTheme.typography.labelSmall, color = NexCyan)
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Fermer", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                // Security & PII Protection Notice Banner
                Surface(
                    color = Color(0xFF0F243A),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = NexCyan, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Protection stricte des données personnelles : Zéro mot de passe, zéro jeton d'authentification et zéro clé secrète dans l'archive exportée.",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFE2E8F0),
                            lineHeight = 15.sp
                        )
                    }
                }

                // Format Selector (JSON vs CSV)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Format :", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)

                    FilterChip(
                        selected = selectedFormat == "JSON",
                        onClick = { selectedFormat = "JSON" },
                        label = { Text("Format JSON (API)") },
                        leadingIcon = {
                            if (selectedFormat == "JSON") Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NexElectricBlue,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("export_format_json_chip")
                    )

                    FilterChip(
                        selected = selectedFormat == "CSV",
                        onClick = { selectedFormat = "CSV" },
                        label = { Text("Format CSV (Audit)") },
                        leadingIcon = {
                            if (selectedFormat == "CSV") Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NexElectricBlue,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("export_format_csv_chip")
                    )
                }

                // Content View / Result
                when (exportResult) {
                    is AdminOperationResult.Success -> {
                        val exportedText = exportResult.data
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF050811),
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Aperçu certifié (${exportedText.lines().size} lignes • ${exportedText.length} octets)",
                                        fontSize = 11.sp,
                                        color = NexCyan,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "SHA-256 Intégrité OK",
                                        fontSize = 10.sp,
                                        color = NexStatusActive,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxWidth()
                                        .verticalScroll(rememberScrollState())
                                ) {
                                    Text(
                                        text = exportedText,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.5.sp,
                                        color = Color(0xFF94A3B8),
                                        lineHeight = 15.sp,
                                        modifier = Modifier.testTag("exported_logs_preview_text")
                                    )
                                }
                            }
                        }

                        // Action Buttons: Copy, Share, Close
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(exportedText))
                                    onFeedback("✅ Journaux d'audit exportés et copiés dans le presse-papier !")
                                },
                                modifier = Modifier.weight(1f).testTag("copy_logs_button"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Copier", fontSize = 12.sp)
                            }

                            Button(
                                onClick = {
                                    shareExportedFile(context, exportedText, selectedFormat)
                                    onFeedback("📤 Partage des journaux d'audit initié.")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NexCyan),
                                modifier = Modifier.weight(1f).testTag("share_logs_button"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, tint = NexDeepBlack, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Partager", color = NexDeepBlack, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }

                    is AdminOperationResult.Unauthorized -> {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF2D1515),
                            modifier = Modifier.weight(1f).fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(40.dp))
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("Accès Refusé (403 Forbidden)", fontWeight = FontWeight.Bold, color = Color(0xFFEF4444))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = exportResult.message,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFE2E8F0)
                                )
                            }
                        }
                    }

                    is AdminOperationResult.ValidationError -> {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF2D1515),
                            modifier = Modifier.weight(1f).fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text("Erreur de validation : ${exportResult.message}", color = Color(0xFFEF4444))
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun shareExportedFile(context: Context, text: String, format: String) {
    try {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, text)
            type = if (format == "JSON") "application/json" else "text/csv"
            putExtra(Intent.EXTRA_SUBJECT, "NexChat_Audit_Logs_${System.currentTimeMillis()}.$format")
        }
        val shareIntent = Intent.createChooser(sendIntent, "Exporter les journaux d'audit NEXCHAT")
        shareIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(shareIntent)
    } catch (_: Exception) {
        // Fallback gracefully
    }
}
