package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.NexChatProPlan
import com.example.model.ProTransactionRecord
import com.example.model.UserProfile
import com.example.ui.theme.NexCyan
import com.example.ui.theme.NexDeepBlack
import com.example.ui.theme.NexElectricBlue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NexChatProScreen(
    user: UserProfile,
    plans: List<NexChatProPlan>,
    transactions: List<ProTransactionRecord>,
    onBack: () -> Unit,
    onSubscribe: (planId: String) -> Unit,
    onToggleAutoRenew: () -> Unit
) {
    var selectedPlanId by remember { mutableStateOf(plans.firstOrNull { it.isPopular }?.id ?: plans.first().id) }
    var showPaymentModalForPlan by remember { mutableStateOf<NexChatProPlan?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFFFD700))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("NexChat Pro ⚡", fontWeight = FontWeight.Bold)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero VIP Banner
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF001F54), Color(0xFF0066FF), Color(0xFF00F5D4))
                            ),
                            shape = RoundedCornerShape(24.dp)
                        )
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Débloquez la Puissance NexChat Pro", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Expérience premium exclusive, personnalisation néon illimitée, sauvegardes sécurisées et badges VIP officiels.",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )

                        if (user.isProSubscriber) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Surface(
                                color = Color(0xFFFFD700),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Verified, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    val expiryStr = user.proExpiryDate?.let { SimpleDateFormat("dd/MM/yyyy", Locale.FRENCH).format(Date(it)) } ?: "Permanent"
                                    Text("Abonnement Actif jusqu'au $expiryStr", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Black)
                                }
                            }
                        }
                    }
                }
            }

            // Plans Selector
            item {
                Text(
                    text = "Choisissez votre formule :",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
            }

            items(plans) { plan ->
                val isSelected = selectedPlanId == plan.id
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedPlanId = plan.id }
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) NexCyan else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(18.dp)
                        )
                        .testTag("plan_card_${plan.id}"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { selectedPlanId = plan.id },
                                    colors = RadioButtonDefaults.colors(selectedColor = NexCyan)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(plan.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                            }
                            if (plan.savingsBadge != null) {
                                Surface(
                                    color = NexElectricBlue,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = plan.savingsBadge,
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                Text(plan.priceFormatted, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = NexCyan)
                                Text(plan.billingFrequencyText, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            Button(
                                onClick = { showPaymentModalForPlan = plan },
                                colors = ButtonDefaults.buttonColors(containerColor = NexCyan),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                                modifier = Modifier.height(34.dp).testTag("subscribe_btn_${plan.id}")
                            ) {
                                Text("S'abonner", color = NexDeepBlack, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            plan.features.forEach { feat ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = NexCyan, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(feat, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }
                    }
                }
            }

            // Subscription Management & Auto-Renew
            if (user.isProSubscriber) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Gestion de l'Abonnement", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Renouvellement automatique", fontSize = 13.sp)
                                Switch(
                                    checked = user.proAutoRenew,
                                    onCheckedChange = { onToggleAutoRenew() }
                                )
                            }
                            Text(
                                text = "Vous pouvez annuler le renouvellement à tout moment sans frais supplémentaires.",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Payment History
            item {
                Text("Historique des Paiements & Factures :", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            }

            items(transactions) { tx ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(tx.planName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("${tx.invoiceNumber} • ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRENCH).format(Date(tx.timestamp))}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(tx.amountFormatted, fontWeight = FontWeight.Bold, color = NexCyan)
                            Text(tx.status, fontSize = 10.sp, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Modal: Verified Server Payment Processing Flow
    if (showPaymentModalForPlan != null) {
        val targetPlan = showPaymentModalForPlan!!
        var isVerifyingOnServer by remember { mutableStateOf(false) }

        Dialog(onDismissRequest = { showPaymentModalForPlan = null }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Paiement Sécurisé NexChat Pro", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("Formule : ${targetPlan.name} (${targetPlan.priceFormatted})", fontSize = 12.sp, color = NexCyan)

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Protocole de vérification serveur :", fontWeight = FontWeight.SemiBold, fontSize = 11.sp, color = NexElectricBlue)
                            Text("• Passerelle bancaire chiffrée SSL / TLS", fontSize = 10.sp)
                            Text("• Vérification du reçu cryptographique côté serveur", fontSize = 10.sp)
                            Text("• Activation instantanée du badge VIP et des fonctions Pro", fontSize = 10.sp)
                        }
                    }

                    if (isVerifyingOnServer) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 10.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), color = NexCyan)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Validation de la transaction auprès du serveur...", fontSize = 11.sp)
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = { showPaymentModalForPlan = null },
                            modifier = Modifier.weight(1f),
                            enabled = !isVerifyingOnServer
                        ) {
                            Text("Annuler")
                        }
                        Button(
                            onClick = {
                                isVerifyingOnServer = true
                                onSubscribe(targetPlan.id)
                                showPaymentModalForPlan = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NexCyan),
                            modifier = Modifier.weight(1f).testTag("confirm_server_payment_button"),
                            enabled = !isVerifyingOnServer
                        ) {
                            Text("Valider (${targetPlan.priceFormatted})", color = NexDeepBlack, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}
