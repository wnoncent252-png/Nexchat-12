package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.model.*
import com.example.ui.theme.NexCyan
import com.example.ui.theme.NexDeepBlack
import com.example.ui.theme.NexElectricBlue
import com.example.ui.theme.NexStatusSuspended
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiscussionsScreen(
    conversations: List<Conversation>,
    messages: List<ChatMessage>,
    currentUser: UserProfile,
    selectedConversationId: String?,
    managedUsers: List<UserProfile> = emptyList(),
    onSelectConversation: (String) -> Unit,
    onBackToList: () -> Unit,
    onSendMessage: (conversationId: String, text: String) -> Unit,
    onSendVoiceNote: (conversationId: String, durationSeconds: Int) -> Unit = { _, _ -> },
    onSendMessageWithReply: (conversationId: String, text: String, snippet: String) -> Unit = { _, _, _ -> },
    onToggleReaction: (messageId: String, emoji: String) -> Unit = { _, _ -> },
    onStartCall: (contactName: String, type: CallType) -> Unit,
    onReportTarget: (ReportEntityType, String) -> Unit,
    onOpenAiAssistant: () -> Unit,
    onStartNewChatWithUser: (UserProfile) -> Unit = {},
    onSendMediaMessage: (conversationId: String, text: String, mediaType: String, mediaUrl: String, mediaName: String, mediaSize: String, isViewOnce: Boolean) -> Unit = { _, _, _, _, _, _, _ -> },
    onMarkMessageViewed: (messageId: String) -> Unit = {},
    onToggleBlockUser: (String) -> Unit = {}
) {
    if (selectedConversationId != null) {
        val activeConv = conversations.find { it.id == selectedConversationId }
            ?: Conversation(selectedConversationId, "Discussion", "user_x", "D", "", "")
        val convMessages = messages.filter { it.conversationId == selectedConversationId }

        ConversationDetailView(
            conversation = activeConv,
            messages = convMessages,
            currentUser = currentUser,
            onBack = onBackToList,
            onSendMessage = { text, isViewOnce ->
                if (isViewOnce) {
                    onSendMediaMessage(activeConv.id, text, "TEXT", "", "Message texte", "", true)
                } else {
                    onSendMessage(activeConv.id, text)
                }
            },
            onSendVoiceNote = { duration -> onSendVoiceNote(activeConv.id, duration) },
            onSendMessageWithReply = { text, snippet -> onSendMessageWithReply(activeConv.id, text, snippet) },
            onToggleReaction = onToggleReaction,
            onStartCall = { type -> onStartCall(activeConv.title, type) },
            onReportMessage = { msgId -> onReportTarget(ReportEntityType.MESSAGE, msgId) },
            onReportUser = { onReportTarget(ReportEntityType.USER_ACCOUNT, activeConv.participantId) },
            onSendMedia = { text, type, url, name, size, isViewOnce ->
                onSendMediaMessage(activeConv.id, text, type, url, name, size, isViewOnce)
            },
            onMarkViewed = onMarkMessageViewed,
            onToggleBlockUser = { onToggleBlockUser(activeConv.title) }
        )
    } else {
        ConversationListView(
            conversations = conversations,
            allUsers = managedUsers,
            onSelect = onSelectConversation,
            onOpenAi = onOpenAiAssistant,
            onStartNewChatWithUser = onStartNewChatWithUser
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationListView(
    conversations: List<Conversation>,
    allUsers: List<UserProfile> = emptyList(),
    onSelect: (String) -> Unit,
    onOpenAi: () -> Unit,
    onStartNewChatWithUser: (UserProfile) -> Unit = {}
) {
    var searchQuery by remember { mutableStateOf("") }
    var showNewChatModal by remember { mutableStateOf(false) }
    var userSearchQuery by remember { mutableStateOf("") }

    val filtered = remember(searchQuery, conversations) {
        if (searchQuery.isBlank()) conversations
        else conversations.filter { it.title.contains(searchQuery, ignoreCase = true) }
    }

    val filteredUsers = remember(userSearchQuery, allUsers) {
        if (userSearchQuery.isBlank()) allUsers
        else allUsers.filter {
            it.displayName.contains(userSearchQuery, ignoreCase = true) ||
            it.username.contains(userSearchQuery, ignoreCase = true)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("NEXCHAT", fontWeight = FontWeight.Black, fontSize = 20.sp, color = NexElectricBlue)
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = NexCyan.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "E2EE 🔒",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = NexCyan,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onOpenAi, modifier = Modifier.testTag("open_ai_chat_button")) {
                        Icon(Icons.Default.SmartToy, contentDescription = "NexChat AI Assistant", tint = NexCyan)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showNewChatModal = true },
                containerColor = NexCyan,
                contentColor = NexDeepBlack,
                modifier = Modifier
                    .padding(bottom = 8.dp)
                    .testTag("floating_new_chat_button")
            ) {
                Icon(
                    imageVector = Icons.Default.ChatBubble,
                    contentDescription = "Nouvelle discussion",
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Rechercher des discussions...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(12.dp)
            )

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(filtered) { conv ->
                    ConversationItemRow(
                        conversation = conv,
                        onClick = { onSelect(conv.id) }
                    )
                    HorizontalDivider(
                        modifier = Modifier.padding(start = 74.dp, end = 16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                }
            }
        }

        if (showNewChatModal) {
            AlertDialog(
                onDismissRequest = { showNewChatModal = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PersonAdd, contentDescription = null, tint = NexCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Nouvelle Discussion", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                },
                text = {
                    Column(modifier = Modifier.fillMaxWidth().heightIn(max = 380.dp)) {
                        Text(
                            text = "Recherchez un contact ou un utilisateur NEXCHAT :",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = userSearchQuery,
                            onValueChange = { userSearchQuery = it },
                            placeholder = { Text("Nom ou @identifiant...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("new_discussion_search_input"),
                            shape = RoundedCornerShape(12.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            val displayUsers = if (filteredUsers.isEmpty()) {
                                listOf(
                                    UserProfile("u_1", "clara_mod", "Clara Dupont", "clara@nexchat.pro"),
                                    UserProfile("u_2", "alex_dev", "Alexandre Martin", "alex@nexchat.pro"),
                                    UserProfile("u_3", "sophie_lux", "Sophie Laurent", "sophie@nexchat.pro")
                                )
                            } else filteredUsers

                            items(displayUsers) { user ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            onStartNewChatWithUser(user)
                                            showNewChatModal = false
                                        }
                                        .testTag("user_select_row_${user.username}")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(NexElectricBlue),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = user.displayName.take(1).uppercase(),
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 16.sp
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(user.displayName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            Text("@${user.username} • ${user.email}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Icon(Icons.Default.Chat, contentDescription = null, tint = NexCyan, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showNewChatModal = false }) {
                        Text("Fermer")
                    }
                }
            )
        }
    }
}

@Composable
fun ConversationItemRow(
    conversation: Conversation,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("conversation_item_${conversation.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            Surface(
                modifier = Modifier.size(50.dp),
                shape = CircleShape,
                color = NexElectricBlue
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = conversation.avatarLetter,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 18.sp
                    )
                }
            }
            if (conversation.isOnline) {
                Surface(
                    modifier = Modifier
                        .size(13.dp)
                        .align(Alignment.BottomEnd),
                    shape = CircleShape,
                    color = NexCyan
                ) {}
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = conversation.title,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    if (conversation.isEndToEndEncrypted) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Chiffré E2EE",
                            tint = NexCyan,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
                Text(
                    text = conversation.lastMessageTime,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(3.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = conversation.lastMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )

                if (conversation.unreadCount > 0) {
                    Surface(
                        color = NexCyan,
                        shape = CircleShape,
                        modifier = Modifier.padding(start = 6.dp)
                    ) {
                        Text(
                            text = conversation.unreadCount.toString(),
                            color = NexDeepBlack,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationDetailView(
    conversation: Conversation,
    messages: List<ChatMessage>,
    currentUser: UserProfile,
    onBack: () -> Unit,
    onSendMessage: (text: String, isViewOnce: Boolean) -> Unit,
    onSendVoiceNote: (Int) -> Unit,
    onSendMessageWithReply: (text: String, snippet: String) -> Unit,
    onToggleReaction: (messageId: String, emoji: String) -> Unit,
    onStartCall: (CallType) -> Unit,
    onReportMessage: (String) -> Unit,
    onReportUser: () -> Unit,
    onSendMedia: (text: String, type: String, url: String, name: String, size: String, isViewOnce: Boolean) -> Unit,
    onMarkViewed: (messageId: String) -> Unit,
    onToggleBlockUser: () -> Unit = {}
) {
    val isContactBlocked = currentUser.privacySettings.blockedUsers.contains(conversation.title)
    var textInput by remember { mutableStateOf("") }
    var isViewOnceActive by remember { mutableStateOf(false) }
    var replyingToMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var selectedMessageForOptions by remember { mutableStateOf<ChatMessage?>(null) }
    var isRecordingAudio by remember { mutableStateOf(false) }
    var audioRecordSeconds by remember { mutableIntStateOf(0) }
    var showAttachmentPicker by remember { mutableStateOf(false) }
    var activeViewOnceMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var showContactProfile by remember { mutableStateOf(false) }
    var showEmojiStickerGifPicker by remember { mutableStateOf(false) }
    var emojiPickerTab by remember { mutableIntStateOf(0) }

    // Live Voice Recorder Timer
    LaunchedEffect(isRecordingAudio) {
        if (isRecordingAudio) {
            audioRecordSeconds = 0
            while (isRecordingAudio) {
                kotlinx.coroutines.delay(1000L)
                audioRecordSeconds++
            }
        }
    }

    val isUserRestricted = currentUser.status == AccountStatus.RESTRICTED ||
            currentUser.status == AccountStatus.TEMPORARILY_SUSPENDED ||
            currentUser.status == AccountStatus.PERMANENTLY_BANNED

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        modifier = Modifier
                            .clickable { showContactProfile = true }
                            .testTag("chat_contact_header"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (isContactBlocked) NexStatusSuspended.copy(alpha = 0.3f) else NexCyan.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = conversation.avatarLetter.ifBlank { conversation.title.take(1) },
                                fontWeight = FontWeight.Bold,
                                color = if (isContactBlocked) NexStatusSuspended else NexCyan,
                                fontSize = 15.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(conversation.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (isContactBlocked) {
                                    Text("Bloqué 🚫", fontSize = 11.sp, color = NexStatusSuspended, fontWeight = FontWeight.SemiBold)
                                } else {
                                    Text(
                                        text = if (conversation.isOnline) "En ligne • Chiffré E2EE" else "Chiffré de bout en bout 🔒",
                                        fontSize = 11.sp,
                                        color = NexCyan
                                    )
                                }
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { if (!isContactBlocked) onStartCall(CallType.AUDIO) },
                        enabled = !isContactBlocked
                    ) {
                        Icon(Icons.Default.Call, contentDescription = "Appel audio", tint = if (isContactBlocked) Color.Gray else NexCyan)
                    }
                    IconButton(
                        onClick = { if (!isContactBlocked) onStartCall(CallType.VIDEO) },
                        enabled = !isContactBlocked
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = "Appel vidéo", tint = if (isContactBlocked) Color.Gray else NexCyan)
                    }
                    IconButton(onClick = onReportUser, modifier = Modifier.testTag("report_user_in_chat_btn")) {
                        Icon(Icons.Default.Report, contentDescription = "Signaler utilisateur", tint = MaterialTheme.colorScheme.error)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // E2EE Notice
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = NexCyan, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "Messages, photos, vidéos, fichiers et appels protégés par le protocole E2EE de NEXCHAT.",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Messages List
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 10.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    ChatBubbleItem(
                        message = msg,
                        onLongClick = { selectedMessageForOptions = msg },
                        onOpenViewOnce = {
                            activeViewOnceMessage = msg
                        }
                    )
                }
            }

            // Quoted message banner if replying
            if (replyingToMessage != null) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Réponse à ${replyingToMessage!!.senderName} :",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = NexCyan
                            )
                            Text(
                                text = replyingToMessage!!.text,
                                fontSize = 12.sp,
                                maxLines = 1,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { replyingToMessage = null }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Fermer la citation", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            // Input Bar
            if (isUserRestricted && currentUser.status == AccountStatus.PERMANENTLY_BANNED) {
                Surface(
                    color = Color(0xFF3B1E1E),
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "Ce compte est banni définitivement. Envoi de messages désactivé.",
                        color = Color(0xFFFF8A80),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            } else if (isContactBlocked) {
                Surface(
                    color = NexStatusSuspended.copy(alpha = 0.15f),
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Block, contentDescription = null, tint = NexStatusSuspended, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Contact bloqué. Débloquez pour échanger des messages.",
                                fontSize = 12.sp,
                                color = NexStatusSuspended,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = onToggleBlockUser,
                            colors = ButtonDefaults.buttonColors(containerColor = NexCyan),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("unblock_in_chat_btn")
                        ) {
                            Text("Débloquer", color = NexDeepBlack, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            } else {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (isRecordingAudio) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Mic, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                val formatSec = String.format(Locale.FRENCH, "%02d:%02d", audioRecordSeconds / 60, audioRecordSeconds % 60)
                                Text("Enregistrement vocal... $formatSec", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Row {
                                TextButton(onClick = { isRecordingAudio = false }) {
                                    Text("Annuler", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                                Button(
                                    onClick = {
                                        val recordedSec = if (audioRecordSeconds > 0) audioRecordSeconds else 3
                                        isRecordingAudio = false
                                        onSendVoiceNote(recordedSec)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = NexCyan)
                                ) {
                                    Text("Envoyer 🎤", color = NexDeepBlack, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    } else {
                        Column {
                            // Emoji, Sticker & GIF Selector Panel
                            if (showEmojiStickerGifPicker) {
                                EmojiStickerGifPickerView(
                                    selectedTab = emojiPickerTab,
                                    onSelectTab = { emojiPickerTab = it },
                                    onInsertEmoji = { emoji -> textInput += emoji },
                                    onSendSticker = { name, url ->
                                        onSendMedia(name, "STICKER", url, name, "50 KB", false)
                                        showEmojiStickerGifPicker = false
                                    },
                                    onSendGif = { name, url ->
                                        onSendMedia(name, "GIF", url, name, "350 KB", false)
                                        showEmojiStickerGifPicker = false
                                    }
                                )
                            }

                            // View Once Active Notice Banner
                            if (isViewOnceActive) {
                                Surface(
                                    color = NexCyan.copy(alpha = 0.15f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Filter1, contentDescription = null, tint = NexCyan, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Mode Vue Unique Activé : Le message s'autodétruira après lecture.", fontSize = 11.sp, color = NexCyan, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 6.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // 1. Attachment Button (Photos, Videos, Files)
                                IconButton(
                                    onClick = { showAttachmentPicker = true },
                                    modifier = Modifier.testTag("attach_file_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AttachFile,
                                        contentDescription = "Joindre photo, vidéo ou fichier",
                                        tint = NexCyan
                                    )
                                }

                                // 2. Emoji, Stickers & GIFs Picker Toggle Button
                                IconButton(
                                    onClick = { showEmojiStickerGifPicker = !showEmojiStickerGifPicker },
                                    modifier = Modifier.testTag("emoji_sticker_gif_picker_button")
                                ) {
                                    Icon(
                                        imageVector = if (showEmojiStickerGifPicker) Icons.Default.Keyboard else Icons.Default.SentimentSatisfiedAlt,
                                        contentDescription = "Émojis, Stickers et GIFs",
                                        tint = if (showEmojiStickerGifPicker) NexCyan else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                // 3. View Once Toggle Button (①)
                                IconButton(
                                    onClick = { isViewOnceActive = !isViewOnceActive },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(if (isViewOnceActive) NexCyan else Color.Transparent)
                                        .testTag("view_once_toggle_btn")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Filter1,
                                        contentDescription = "Vue unique",
                                        tint = if (isViewOnceActive) NexDeepBlack else NexCyan,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(4.dp))

                                OutlinedTextField(
                                    value = textInput,
                                    onValueChange = { textInput = it },
                                    placeholder = { Text(if (isViewOnceActive) "Message vue unique..." else "Message chiffré...") },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("chat_input_text_field"),
                                    shape = RoundedCornerShape(24.dp)
                                )

                                Spacer(modifier = Modifier.width(6.dp))

                                if (textInput.isBlank()) {
                                    IconButton(
                                        onClick = { isRecordingAudio = true },
                                        colors = IconButtonDefaults.iconButtonColors(containerColor = NexCyan.copy(alpha = 0.2f)),
                                        modifier = Modifier.testTag("record_voice_note_btn")
                                    ) {
                                        Icon(Icons.Default.Mic, contentDescription = "Enregistrer une note vocale", tint = NexCyan)
                                    }
                                } else {
                                    IconButton(
                                        onClick = {
                                            if (textInput.isNotBlank()) {
                                                if (replyingToMessage != null) {
                                                    onSendMessageWithReply(textInput, replyingToMessage!!.text)
                                                    replyingToMessage = null
                                                } else {
                                                    onSendMessage(textInput, isViewOnceActive)
                                                }
                                                textInput = ""
                                                isViewOnceActive = false
                                            }
                                        },
                                        colors = IconButtonDefaults.iconButtonColors(containerColor = NexElectricBlue),
                                        modifier = Modifier.testTag("send_chat_message_btn")
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Envoyer", tint = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal: Attachment Picker (Photos, Videos, Files from Storage/Resources)
    if (showAttachmentPicker) {
        AttachmentPickerModal(
            isViewOnceInitially = isViewOnceActive,
            onDismiss = { showAttachmentPicker = false },
            onSend = { text, type, url, name, size, isViewOnce ->
                onSendMedia(text, type, url, name, size, isViewOnce)
                showAttachmentPicker = false
                isViewOnceActive = false
            }
        )
    }

    // Modal: Fullscreen Secure View-Once Viewer
    if (activeViewOnceMessage != null) {
        val msg = activeViewOnceMessage!!
        SecureViewOnceModalViewer(
            message = msg,
            onClose = {
                onMarkViewed(msg.id)
                activeViewOnceMessage = null
            }
        )
    }

    // Modal: Contact Profile View
    if (showContactProfile) {
        ContactProfileModal(
            conversation = conversation,
            isBlocked = isContactBlocked,
            onStartCall = onStartCall,
            onToggleBlock = onToggleBlockUser,
            onReport = onReportUser,
            onDismiss = { showContactProfile = false }
        )
    }

    // Message options dialog: Reactions + Reply + Report
    if (selectedMessageForOptions != null) {
        val targetMsg = selectedMessageForOptions!!
        AlertDialog(
            onDismissRequest = { selectedMessageForOptions = null },
            title = { Text("Interaction Message") },
            text = {
                Column {
                    Text("\"${targetMsg.text}\"", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(14.dp))
                    Text("Réagir avec un emoji :", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf("👍", "❤️", "🔥", "😂", "😮", "👏").forEach { emoji ->
                            Surface(
                                shape = CircleShape,
                                color = if (targetMsg.reactionEmoji == emoji) NexCyan.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clickable {
                                        onToggleReaction(targetMsg.id, emoji)
                                        selectedMessageForOptions = null
                                    }
                                    .padding(4.dp)
                            ) {
                                Text(
                                    text = emoji,
                                    fontSize = 22.sp,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row {
                    TextButton(
                        onClick = {
                            replyingToMessage = targetMsg
                            selectedMessageForOptions = null
                        }
                    ) {
                        Icon(Icons.Default.Reply, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Répondre")
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = {
                            onReportMessage(targetMsg.id)
                            selectedMessageForOptions = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Signaler", fontSize = 12.sp)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedMessageForOptions = null }) {
                    Text("Fermer")
                }
            }
        )
    }
}

// Modal: Attachment Picker (Photos, Videos, Files from Storage/Resources)
@Composable
fun AttachmentPickerModal(
    isViewOnceInitially: Boolean,
    onDismiss: () -> Unit,
    onSend: (text: String, type: String, url: String, name: String, size: String, isViewOnce: Boolean) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var captionText by remember { mutableStateOf("") }
    var isViewOnce by remember { mutableStateOf(isViewOnceInitially) }
    var selectedMediaUrl by remember { mutableStateOf("") }
    var selectedMediaName by remember { mutableStateOf("") }
    var selectedMediaSize by remember { mutableStateOf("") }

    val photoPresets = listOf(
        Pair("Photo Haute Résolution", "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=800"),
        Pair("Capture Sécurisée E2EE", "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800"),
        Pair("Portrait Studio Pro", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800"),
        Pair("Architecture & Design", "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800")
    )

    val videoPresets = listOf(
        Pair("Démo Chiffrement NexChat (0:30)", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"),
        Pair("Tutoriel Sécurité & Clés (1:15)", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"),
        Pair("Clip Événement Officiel (0:45)", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4")
    )

    val filePresets = listOf(
        Triple("Contrat_Confidentialite_v2.pdf", "1.4 Mo", "DOCUMENT"),
        Triple("Audit_Securite_Certifie.json", "68 Ko", "DOCUMENT"),
        Triple("Archive_Chiffree_NEX.zip", "5.2 Mo", "DOCUMENT"),
        Triple("Cle_Publique_E2EE.asc", "16 Ko", "DOCUMENT"),
        Triple("Audio_Enregistrement_HQ.flac", "1.1 Mo", "DOCUMENT")
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Envoyer des Médias & Fichiers", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Fermer")
                    }
                }

                TabRow(selectedTabIndex = selectedTab) {
                    Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("📷 Photos", fontSize = 11.sp) })
                    Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("🎥 Vidéos", fontSize = 11.sp) })
                    Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("📁 Fichiers", fontSize = 11.sp) })
                }

                // Content Picker depending on Tab
                Box(modifier = Modifier.weight(1f)) {
                    when (selectedTab) {
                        0 -> {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                item {
                                    Text("Choisissez une photo de la galerie ou des ressources :", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                items(photoPresets) { (name, url) ->
                                    val isSelected = selectedMediaUrl == url
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) NexElectricBlue.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier.fillMaxWidth().clickable {
                                            selectedMediaUrl = url
                                            selectedMediaName = name
                                            selectedMediaSize = "1.8 Mo"
                                        }
                                    ) {
                                        Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                            AsyncImage(
                                                model = url,
                                                contentDescription = name,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.size(46.dp).clip(RoundedCornerShape(8.dp))
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                Text("Image HD sécurisée • 1080p", fontSize = 11.sp, color = NexCyan)
                                            }
                                            if (isSelected) {
                                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NexCyan)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        1 -> {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                item {
                                    Text("Choisissez une vidéo à envoyer :", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                items(videoPresets) { (name, url) ->
                                    val isSelected = selectedMediaUrl == url
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) NexElectricBlue.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier.fillMaxWidth().clickable {
                                            selectedMediaUrl = url
                                            selectedMediaName = name
                                            selectedMediaSize = "12.4 Mo"
                                        }
                                    ) {
                                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)).background(NexElectricBlue),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(Icons.Default.PlayCircleFilled, contentDescription = null, tint = Color.White)
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                Text("Vidéo MP4 sécurisée • 12.4 Mo", fontSize = 11.sp, color = NexCyan)
                                            }
                                            if (isSelected) {
                                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NexCyan)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        2 -> {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                item {
                                    Text("Puiser dans les fichiers locaux et ressources du système :", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                items(filePresets) { (name, size, type) ->
                                    val isSelected = selectedMediaName == name
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) NexElectricBlue.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier.fillMaxWidth().clickable {
                                            selectedMediaName = name
                                            selectedMediaSize = size
                                            selectedMediaUrl = "file://nexchat/resources/$name"
                                        }
                                    ) {
                                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier.size(42.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF334155)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = NexCyan)
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(name, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                                Text("Ressource locale chiffrée • $size", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            if (isSelected) {
                                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NexCyan)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = captionText,
                    onValueChange = { captionText = it },
                    placeholder = { Text("Ajouter une légende...") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                // View Once Toggle in Attachment Dialog
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isViewOnce) NexCyan.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Filter1, contentDescription = null, tint = if (isViewOnce) NexCyan else MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("Message Vue Unique", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("Le destinataire ne pourra le voir qu'une fois", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Switch(checked = isViewOnce, onCheckedChange = { isViewOnce = it })
                    }
                }

                Button(
                    onClick = {
                        val finalType = when (selectedTab) {
                            0 -> "IMAGE"
                            1 -> "VIDEO"
                            else -> "DOCUMENT"
                        }
                        val defaultUrl = when (selectedTab) {
                            0 -> "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=800"
                            1 -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
                            else -> "file://nexchat/resources/Document_Officiel.pdf"
                        }
                        val finalUrl = if (selectedMediaUrl.isNotBlank()) selectedMediaUrl else defaultUrl
                        val finalName = if (selectedMediaName.isNotBlank()) selectedMediaName else "Pièce_Jointe.nex"
                        val finalSize = if (selectedMediaSize.isNotBlank()) selectedMediaSize else "2.4 Mo"
                        onSend(captionText, finalType, finalUrl, finalName, finalSize, isViewOnce)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Envoyer ${if (isViewOnce) "(Vue Unique)" else ""}")
                }
            }
        }
    }
}

// Modal: Fullscreen Secure View-Once Viewer
@Composable
fun SecureViewOnceModalViewer(
    message: ChatMessage,
    onClose: () -> Unit
) {
    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = NexDeepBlack,
            modifier = Modifier.fillMaxWidth().fillMaxHeight(0.85f)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Banner
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = NexCyan,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("1", fontWeight = FontWeight.Black, color = NexDeepBlack, fontSize = 12.sp)
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Vue Unique Sécurisée", fontWeight = FontWeight.Bold, color = NexCyan, fontSize = 14.sp)
                    }
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, contentDescription = "Fermer", tint = Color.White)
                    }
                }

                Surface(
                    color = Color(0xFF1E293B),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Text(
                        text = "🔒 Attention : Ce contenu ne peut être vu qu'une seule fois. Dès la fermeture, il sera effacé définitivement.",
                        fontSize = 11.sp,
                        color = Color(0xFFFFD700),
                        modifier = Modifier.padding(8.dp)
                    )
                }

                // Media Preview
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    when (message.mediaType) {
                        "IMAGE" -> {
                            AsyncImage(
                                model = message.mediaUrl ?: "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=800",
                                contentDescription = "Photo vue unique",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp))
                            )
                        }
                        "VIDEO" -> {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(100.dp)
                                        .clip(CircleShape)
                                        .background(NexCyan),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = NexDeepBlack, modifier = Modifier.size(60.dp))
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("Lecture de la vidéo vue unique", color = Color.White, fontWeight = FontWeight.Bold)
                                Text(message.mediaName ?: "Clip vidéo sécurisé", color = NexCyan, fontSize = 12.sp)
                            }
                        }
                        "DOCUMENT" -> {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = NexCyan, modifier = Modifier.size(64.dp))
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(message.mediaName ?: "Fichier sécurisé", color = Color.White, fontWeight = FontWeight.Bold)
                                Text(message.mediaDurationOrSize ?: "Taille inconnue", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                        else -> {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = NexElectricBlue.copy(alpha = 0.3f),
                                modifier = Modifier.fillMaxWidth().padding(16.dp)
                            ) {
                                Text(
                                    text = message.text,
                                    fontSize = 16.sp,
                                    color = Color.White,
                                    modifier = Modifier.padding(16.dp)
                                )
                            }
                        }
                    }
                }

                if (message.text.isNotBlank() && message.mediaType != null) {
                    Text(
                        text = message.text,
                        color = Color.White,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = NexCyan),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("J'ai terminé (Fermer et détruire)", color = NexDeepBlack, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ChatBubbleItem(
    message: ChatMessage,
    onLongClick: () -> Unit,
    onOpenViewOnce: () -> Unit = {}
) {
    val time = SimpleDateFormat("HH:mm", Locale.FRENCH).format(Date(message.timestamp))
    var isAudioPlaying by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onLongClick() },
        horizontalAlignment = if (message.isFromMe) Alignment.End else Alignment.Start
    ) {
        Box {
            Surface(
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (message.isFromMe) 16.dp else 4.dp,
                    bottomEnd = if (message.isFromMe) 4.dp else 16.dp
                ),
                color = if (message.isFromMe) NexElectricBlue else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.widthIn(max = 290.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    if (!message.isFromMe) {
                        Text(
                            text = message.senderName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = NexCyan
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                    }

                    // Quoted Snippet if present
                    if (message.repliedToSnippet != null) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp)
                        ) {
                            Row(modifier = Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .width(3.dp)
                                        .height(24.dp)
                                        .background(NexCyan, RoundedCornerShape(2.dp))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = message.repliedToSnippet,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    color = Color.White.copy(alpha = 0.9f)
                                )
                            }
                        }
                    }

                    // 1. Vue Unique Rendering
                    if (message.isViewOnce) {
                        if (message.isViewed) {
                            // Expired / Already Viewed
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.Black.copy(alpha = 0.3f),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.DoneAll, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("① Ouvert • Contenu expiré", fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        } else {
                            // Unviewed: Interactive Tap-To-View
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = NexCyan.copy(alpha = 0.2f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, NexCyan, RoundedCornerShape(8.dp))
                                    .clickable { onOpenViewOnce() }
                                    .padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = NexCyan,
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text("1", fontWeight = FontWeight.Black, color = NexDeepBlack, fontSize = 12.sp)
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        val label = when (message.mediaType) {
                                            "IMAGE" -> "Photo (Vue unique)"
                                            "VIDEO" -> "Vidéo (Vue unique)"
                                            "DOCUMENT" -> "Fichier (Vue unique)"
                                            else -> "Message (Vue unique)"
                                        }
                                        Text(label, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = NexCyan)
                                        Text("Appuyez pour afficher", fontSize = 10.sp, color = Color.White.copy(alpha = 0.8f))
                                    }
                                    Icon(Icons.Default.Visibility, contentDescription = null, tint = NexCyan, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    } else {
                        // Standard Media & Text Rendering
                        when (message.mediaType) {
                            "IMAGE" -> {
                                if (message.mediaUrl != null) {
                                    AsyncImage(
                                        model = message.mediaUrl,
                                        contentDescription = "Image envoyée",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(160.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                }
                                if (message.text.isNotBlank() && message.text != "📷 Photo") {
                                    Text(text = message.text, color = Color.White, fontSize = 13.sp)
                                }
                            }
                            "VIDEO" -> {
                                Card(
                                    shape = RoundedCornerShape(8.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.3f)),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                ) {
                                    Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier.size(36.dp).clip(CircleShape).background(NexCyan),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = NexDeepBlack)
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(message.mediaName ?: "Vidéo HD", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                                            Text(message.mediaDurationOrSize ?: "Vidéo sécurisée", fontSize = 10.sp, color = NexCyan)
                                        }
                                    }
                                }
                                if (message.text.isNotBlank() && message.text != "🎥 Vidéo") {
                                    Text(text = message.text, color = Color.White, fontSize = 13.sp)
                                }
                            }
                            "DOCUMENT" -> {
                                Card(
                                    shape = RoundedCornerShape(8.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.3f)),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                ) {
                                    Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = NexCyan, modifier = Modifier.size(32.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(message.mediaName ?: "Document", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                                            Text(message.mediaDurationOrSize ?: "Fichier local", fontSize = 10.sp, color = NexCyan)
                                        }
                                    }
                                }
                            }
                            "AUDIO" -> {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                                    IconButton(
                                        onClick = { isAudioPlaying = !isAudioPlaying },
                                        modifier = Modifier.size(36.dp).background(NexCyan, CircleShape)
                                    ) {
                                        Icon(
                                            imageVector = if (isAudioPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            contentDescription = "Lecture note vocale",
                                            tint = NexDeepBlack,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(3.dp),
                                            modifier = Modifier.height(20.dp)
                                        ) {
                                            listOf(12, 18, 8, 22, 14, 20, 10, 24, 16, 12, 19, 14).forEachIndexed { idx, barH ->
                                                val isPassed = idx < 6
                                                Box(
                                                    modifier = Modifier
                                                        .width(3.dp)
                                                        .height(barH.dp)
                                                        .background(if (isPassed) NexCyan else Color.White.copy(alpha = 0.5f), RoundedCornerShape(2.dp))
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(message.mediaDurationOrSize ?: "0:12", fontSize = 10.sp, color = Color.White.copy(alpha = 0.8f))
                                    }
                                }
                            }
                            "STICKER" -> {
                                if (message.mediaUrl != null) {
                                    AsyncImage(
                                        model = message.mediaUrl,
                                        contentDescription = "Sticker NexChat",
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier
                                            .size(120.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                }
                                Text(text = message.text, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                            "GIF" -> {
                                if (message.mediaUrl != null) {
                                    AsyncImage(
                                        model = message.mediaUrl,
                                        contentDescription = "GIF animé",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(130.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        color = NexCyan,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text("GIF", color = NexDeepBlack, fontWeight = FontWeight.Black, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = message.text, color = Color.White, fontSize = 11.sp)
                                }
                            }
                            else -> {
                                Text(
                                    text = message.text,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (message.isFromMe) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.align(Alignment.End),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = time,
                            fontSize = 9.sp,
                            color = if (message.isFromMe) Color.White.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (message.isFromMe) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.DoneAll,
                                contentDescription = "Lu",
                                tint = NexCyan,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }
                }
            }

            if (message.reactionEmoji != null) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 2.dp,
                    modifier = Modifier
                        .align(if (message.isFromMe) Alignment.BottomStart else Alignment.BottomEnd)
                        .offset(y = 8.dp)
                ) {
                    Text(
                        text = message.reactionEmoji,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun EmojiStickerGifPickerView(
    selectedTab: Int,
    onSelectTab: (Int) -> Unit,
    onInsertEmoji: (String) -> Unit,
    onSendSticker: (name: String, url: String) -> Unit,
    onSendGif: (name: String, url: String) -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .height(230.dp)
            .border(1.dp, MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = NexCyan
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { onSelectTab(0) },
                    text = { Text("😊 Émojis", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { onSelectTab(1) },
                    text = { Text("👾 Stickers", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { onSelectTab(2) },
                    text = { Text("🎬 GIFs", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
            }

            when (selectedTab) {
                0 -> {
                    val emojis = listOf(
                        "😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "😊", "😇",
                        "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚",
                        "😋", "😛", "😝", "😜", "🤪", "🤨", "🧐", "🤓", "😎", "🤩",
                        "🥳", "😏", "😒", "😞", "😔", "😟", "😕", "🙁", "☹️", "😣",
                        "😖", "😫", "😩", "🥺", "😢", "😭", "😤", "😠", "😡", "🤬",
                        "🤯", "😳", "🥵", "🥶", "😱", "😨", "😰", "😥", "😓", "🤗",
                        "🤔", "🤭", "🤫", "🤥", "😶", "😐", "😑", "😬", "🙄", "😯",
                        "👍", "👎", "👏", "🙌", "👐", "🤲", "🤝", "🙏", "✌️", "🤞",
                        "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💔",
                        "🔥", "✨", "🌟", "💫", "💥", "💯", "🚀", "🤖", "⚡", "🔒"
                    )
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 40.dp),
                        modifier = Modifier.fillMaxSize().padding(6.dp),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        items(emojis) { emoji ->
                            Box(
                                modifier = Modifier
                                    .padding(2.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { onInsertEmoji(emoji) }
                                    .padding(6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(emoji, fontSize = 22.sp)
                            }
                        }
                    }
                }
                1 -> {
                    val stickers = listOf(
                        Pair("NexBot Salut", "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400"),
                        Pair("Cyber Flamme", "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=400"),
                        Pair("Fusée Turbo", "https://images.unsplash.com/photo-1518770660439-4636190af475?w=400"),
                        Pair("Cœur Néon", "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=400"),
                        Pair("Matrix Code", "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=400"),
                        Pair("Gamer Pro", "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=400")
                    )
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier.fillMaxSize().padding(6.dp),
                        contentPadding = PaddingValues(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(stickers) { (name, url) ->
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                modifier = Modifier
                                    .clickable { onSendSticker(name, url) }
                                    .fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    AsyncImage(
                                        model = url,
                                        contentDescription = name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.size(60.dp).clip(RoundedCornerShape(8.dp))
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(name, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                }
                            }
                        }
                    }
                }
                2 -> {
                    val gifs = listOf(
                        Pair("Danse Néon", "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=500"),
                        Pair("Victoire Cyber", "https://images.unsplash.com/photo-1518770660439-4636190af475?w=500"),
                        Pair("High Five Matrix", "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=500"),
                        Pair("Super Wow", "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=500")
                    )
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.fillMaxSize().padding(6.dp),
                        contentPadding = PaddingValues(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(gifs) { (name, url) ->
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                modifier = Modifier
                                    .clickable { onSendGif(name, url) }
                                    .fillMaxWidth()
                            ) {
                                Box {
                                    AsyncImage(
                                        model = url,
                                        contentDescription = name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxWidth().height(85.dp).clip(RoundedCornerShape(10.dp))
                                    )
                                    Surface(
                                        color = NexCyan,
                                        shape = RoundedCornerShape(bottomEnd = 6.dp),
                                        modifier = Modifier.align(Alignment.TopStart)
                                    ) {
                                        Text("GIF", color = NexDeepBlack, fontWeight = FontWeight.Black, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                    }
                                    Surface(
                                        color = Color.Black.copy(alpha = 0.6f),
                                        shape = RoundedCornerShape(topStart = 6.dp),
                                        modifier = Modifier.align(Alignment.BottomEnd)
                                    ) {
                                        Text(name, color = Color.White, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ContactProfileModal(
    conversation: Conversation,
    isBlocked: Boolean,
    onStartCall: (CallType) -> Unit,
    onToggleBlock: () -> Unit,
    onReport: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Avatar
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(if (isBlocked) NexStatusSuspended.copy(alpha = 0.2f) else NexElectricBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = conversation.avatarLetter.ifBlank { conversation.title.take(1) },
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 32.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(conversation.title, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text(
                    text = "@${conversation.title.lowercase().replace(" ", "_")}",
                    fontSize = 12.sp,
                    color = NexCyan
                )

                Spacer(modifier = Modifier.height(6.dp))

                Surface(
                    color = if (isBlocked) NexStatusSuspended.copy(alpha = 0.2f) else if (conversation.isOnline) Color(0xFF10B981).copy(alpha = 0.2f) else Color.Gray.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (isBlocked) "🚫 Compte Bloqué" else if (conversation.isOnline) "🟢 En ligne actuellement" else "⚪ Hors ligne",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isBlocked) NexStatusSuspended else if (conversation.isOnline) Color(0xFF10B981) else Color.Gray,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Membre vérifié de NEXCHAT. Discussions et appels chiffrés de bout en bout (protocole E2EE).",
                    fontSize = 12.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Actions: Message, Call, Video
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = CircleShape,
                        modifier = Modifier.size(50.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = "Message", tint = NexCyan)
                    }

                    OutlinedButton(
                        onClick = {
                            if (!isBlocked) {
                                onDismiss()
                                onStartCall(CallType.AUDIO)
                            }
                        },
                        enabled = !isBlocked,
                        shape = CircleShape,
                        modifier = Modifier.size(50.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Icon(Icons.Default.Call, contentDescription = "Appel audio", tint = if (isBlocked) Color.Gray else NexCyan)
                    }

                    OutlinedButton(
                        onClick = {
                            if (!isBlocked) {
                                onDismiss()
                                onStartCall(CallType.VIDEO)
                            }
                        },
                        enabled = !isBlocked,
                        shape = CircleShape,
                        modifier = Modifier.size(50.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = "Appel vidéo", tint = if (isBlocked) Color.Gray else NexCyan)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(14.dp))

                // Block / Unblock Button
                Button(
                    onClick = {
                        onToggleBlock()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isBlocked) NexCyan else NexStatusSuspended
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("contact_profile_block_btn")
                ) {
                    Icon(
                        imageVector = if (isBlocked) Icons.Default.CheckCircle else Icons.Default.Block,
                        contentDescription = null,
                        tint = if (isBlocked) NexDeepBlack else Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isBlocked) "Débloquer cet utilisateur" else "Bloquer cet utilisateur",
                        color = if (isBlocked) NexDeepBlack else Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Report button
                OutlinedButton(
                    onClick = {
                        onDismiss()
                        onReport()
                    },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("contact_profile_report_btn")
                ) {
                    Icon(Icons.Default.Report, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Signaler cet utilisateur", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
