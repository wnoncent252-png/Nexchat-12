package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Report
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.ReportEntityType
import com.example.ui.theme.NexElectricBlue
import com.example.ui.theme.NexStatusSuspended

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportDialog(
    targetType: ReportEntityType,
    targetId: String,
    onSubmitReport: (reason: String, comment: String) -> Unit,
    onDismiss: () -> Unit
) {
    val motives = listOf(
        "Harcèlement",
        "Spam",
        "Fraude",
        "Usurpation d'identité",
        "Menaces",
        "Contenu interdit",
        "Autre motif"
    )
    var selectedMotive by remember { mutableStateOf(motives.first()) }
    var additionalDetails by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Report,
                        contentDescription = "Signalement",
                        tint = NexStatusSuspended,
                        modifier = Modifier.size(28.dp)
                    )
                    Column {
                        Text(
                            text = "Signaler à la Modération",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Cible : ${targetType.label} ($targetId)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Text(
                    text = "Sélectionnez le motif principal de violation de la charte NEXCHAT :",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Motive Dropdown / Radio selection
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    motives.forEach { motive ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            RadioButton(
                                selected = (selectedMotive == motive),
                                onClick = { selectedMotive = motive },
                                colors = RadioButtonDefaults.colors(selectedColor = NexElectricBlue)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = motive,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = additionalDetails,
                    onValueChange = { additionalDetails = it },
                    label = { Text("Précisions factuelles / Horodatage (facultatif)") },
                    placeholder = { Text("Détaillez le comportement ou le contexte constaté...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(90.dp)
                        .testTag("report_details_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                // Info banner on evidence & privacy
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = NexElectricBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Un dossier horodaté avec score de risque automatique sera transmis aux modérateurs humains sous chiffrement.",
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Annuler")
                    }
                    Button(
                        onClick = {
                            isSubmitting = true
                            onSubmitReport(selectedMotive, additionalDetails)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NexStatusSuspended),
                        modifier = Modifier.weight(1f).testTag("confirm_submit_report_button"),
                        enabled = !isSubmitting
                    ) {
                        Text("Transmettre", color = Color.White)
                    }
                }
            }
        }
    }
}
