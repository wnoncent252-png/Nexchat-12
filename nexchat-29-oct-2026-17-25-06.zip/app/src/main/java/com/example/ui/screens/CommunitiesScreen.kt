package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.model.CommunityItem
import com.example.model.CommunityType
import com.example.model.UserProfile
import com.example.ui.theme.NexCyan
import com.example.ui.theme.NexDeepBlack
import com.example.ui.theme.NexElectricBlue

data class GroupMember(
    val userId: String,
    val displayName: String,
    val username: String,
    val bio: String,
    val role: String, // "Admin", "Modérateur", "Membre"
    val avatarUrl: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommunitiesScreen(
    communities: List<CommunityItem>,
    currentUser: UserProfile? = null,
    onReportCommunity: (communityId: String) -> Unit = {},
    onStartChatWithUser: (UserProfile) -> Unit = {}
) {
    var filterType by remember { mutableStateOf<CommunityType?>(null) }
    var selectedCommunityForProfiles by remember { mutableStateOf<CommunityItem?>(null) }
    var selectedMemberProfile by remember { mutableStateOf<GroupMember?>(null) }
    var showCreateGroupModal by remember { mutableStateOf(false) }

    val sampleMembers = listOf(
        GroupMember("m_1", "Clara Dupont", "clara_mod", "Modératrice de la communauté • Spécialiste sécurité", "Admin", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300"),
        GroupMember("m_2", "Alexandre Dev", "alex_dev", "Ingénieur Cloud & Cryptographie E2EE", "Modérateur", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300"),
        GroupMember("m_3", "Sophie Laurent", "sophie_lux", "Designer UI & Ergonomie mobile", "Membre", "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300"),
        GroupMember("m_4", "Marc Vasseur", "marc_sec", "Auditeur de sécurité certifié CISSP", "Membre", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300")
    )

    val filtered = remember(filterType, communities) {
        if (filterType == null) communities
        else communities.filter { it.type == filterType }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Groups, contentDescription = null, tint = NexCyan, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Groupes & Communautés", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                },
                actions = {
                    IconButton(onClick = { showCreateGroupModal = true }) {
                        Icon(Icons.Default.GroupAdd, contentDescription = "Créer un groupe", tint = NexCyan)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Profile banner in groups
            if (currentUser != null) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = NexElectricBlue.copy(alpha = 0.15f)),
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .border(2.dp, NexCyan, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (currentUser.avatarUrl.isNotBlank()) {
                                AsyncImage(
                                    model = currentUser.avatarUrl,
                                    contentDescription = "Mon profil",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize().clip(CircleShape)
                                )
                            } else {
                                Box(
                                    modifier = Modifier.fillMaxSize().background(NexElectricBlue),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(currentUser.displayName.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(currentUser.displayName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Default.Verified, contentDescription = null, tint = NexCyan, modifier = Modifier.size(14.dp))
                            }
                            Text(
                                text = if (currentUser.bio.isNotBlank()) currentUser.bio else "Votre profil visible par tous les membres des groupes",
                                fontSize = 11.sp,
                                maxLines = 1,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Surface(
                            color = NexCyan,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("Mon Profil", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NexDeepBlack, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                        }
                    }
                }
            }

            // Filters
            Row(
                modifier = Modifier.padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = filterType == null,
                    onClick = { filterType = null },
                    label = { Text("Tous") }
                )
                FilterChip(
                    selected = filterType == CommunityType.GROUP,
                    onClick = { filterType = CommunityType.GROUP },
                    label = { Text("Groupes Sécurisés") }
                )
                FilterChip(
                    selected = filterType == CommunityType.CHANNEL,
                    onClick = { filterType = CommunityType.CHANNEL },
                    label = { Text("Chaînes Publiques") }
                )
            }

            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(filtered) { item ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth().testTag("community_item_${item.id}")
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier.size(38.dp).clip(CircleShape).background(NexElectricBlue),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(item.name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = item.name,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.titleSmall
                                            )
                                            if (item.isOfficialVerified) {
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = "Certifié",
                                                    tint = NexCyan,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                        Text("${item.memberCount} membres actifs", fontSize = 11.sp, color = NexCyan)
                                    }
                                }

                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = if (item.type == CommunityType.CHANNEL) "CHAÎNE" else "GROUPE",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NexElectricBlue,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Text(
                                text = item.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

                            // Action buttons: Profils des membres & Rejoindre
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(
                                    onClick = { selectedCommunityForProfiles = item },
                                    modifier = Modifier.testTag("group_members_profiles_btn_${item.id}")
                                ) {
                                    Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(16.dp), tint = NexCyan)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Profils des Membres", color = NexCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                Row {
                                    IconButton(onClick = { onReportCommunity(item.id) }) {
                                        Icon(Icons.Default.Report, contentDescription = "Signaler", tint = MaterialTheme.colorScheme.error)
                                    }
                                    Button(
                                        onClick = { },
                                        colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text("Rejoindre", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal 1: Group Members Profiles List
    if (selectedCommunityForProfiles != null) {
        val com = selectedCommunityForProfiles!!
        Dialog(onDismissRequest = { selectedCommunityForProfiles = null }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth().heightIn(max = 480.dp).padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Profils dans : ${com.name}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Consultez les administrateurs et membres", fontSize = 11.sp, color = NexCyan)
                        }
                        IconButton(onClick = { selectedCommunityForProfiles = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Fermer")
                        }
                    }

                    HorizontalDivider()

                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        items(sampleMembers) { member ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedMemberProfile = member }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AsyncImage(
                                        model = member.avatarUrl,
                                        contentDescription = member.displayName,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.size(42.dp).clip(CircleShape).border(1.dp, NexCyan, CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(member.displayName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Surface(
                                                color = if (member.role == "Admin") NexCyan else NexElectricBlue.copy(alpha = 0.3f),
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(member.role, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (member.role == "Admin") NexDeepBlack else Color.White, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                            }
                                        }
                                        Text(member.bio, fontSize = 11.sp, maxLines = 1, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal 2: Individual Member Profile Card
    if (selectedMemberProfile != null) {
        val member = selectedMemberProfile!!
        AlertDialog(
            onDismissRequest = { selectedMemberProfile = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccountCircle, contentDescription = null, tint = NexCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Profil de ${member.displayName}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AsyncImage(
                        model = member.avatarUrl,
                        contentDescription = member.displayName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .border(3.dp, NexCyan, CircleShape)
                    )

                    Text(member.displayName, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("@${member.username} • Rôle : ${member.role}", fontSize = 12.sp, color = NexCyan)

                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Description & Biographie :", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NexCyan)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(member.bio, fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onStartChatWithUser(UserProfile(member.userId, member.username, member.displayName, "${member.username}@nexchat.pro", bio = member.bio, avatarUrl = member.avatarUrl))
                        selectedMemberProfile = null
                        selectedCommunityForProfiles = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue)
                ) {
                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Envoyer un message")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedMemberProfile = null }) {
                    Text("Fermer")
                }
            }
        )
    }

    // Modal 3: Create New Group with Profile Photo & Description
    if (showCreateGroupModal) {
        var groupName by remember { mutableStateOf("") }
        var groupDesc by remember { mutableStateOf("") }
        var groupPhotoUrl by remember { mutableStateOf("https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=300") }

        Dialog(onDismissRequest = { showCreateGroupModal = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Créer un Nouveau Groupe", fontWeight = FontWeight.Bold, fontSize = 16.sp)

                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .align(Alignment.CenterHorizontally)
                            .clip(CircleShape)
                            .border(2.dp, NexCyan, CircleShape)
                    ) {
                        AsyncImage(
                            model = groupPhotoUrl,
                            contentDescription = "Photo du groupe",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    OutlinedTextField(
                        value = groupName,
                        onValueChange = { groupName = it },
                        label = { Text("Nom du groupe") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = groupDesc,
                        onValueChange = { groupDesc = it },
                        label = { Text("Description & Règles du groupe") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showCreateGroupModal = false }) {
                            Text("Annuler")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { showCreateGroupModal = false },
                            colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue),
                            enabled = groupName.isNotBlank()
                        ) {
                            Text("Créer le groupe")
                        }
                    }
                }
            }
        }
    }
}
