package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.UserProfile
import com.example.model.UserRole
import com.example.ui.theme.NexCyan
import com.example.ui.theme.NexDeepBlack
import com.example.ui.theme.NexElectricBlue
import com.example.ui.theme.NexStatusSuspended
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// --- 1. Paramètres Généraux ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsGeneralScreen(
    user: UserProfile,
    onBack: () -> Unit
) {
    var dataSaver by remember { mutableStateOf(false) }
    var soundEffects by remember { mutableStateOf(true) }
    var selectedLanguage by remember { mutableStateOf("Français (Par défaut)") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Paramètres Généraux", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Préférences de l'Application", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("Mode économie de données", fontWeight = FontWeight.SemiBold)
                                Text("Réduit la consommation réseau pour les vidéos et images", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = dataSaver, onCheckedChange = { dataSaver = it })
                        }

                        HorizontalDivider()

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("Sons et effets sonores", fontWeight = FontWeight.SemiBold)
                                Text("Sons discrets lors de l'envoi et réception de messages", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = soundEffects, onCheckedChange = { soundEffects = it })
                        }

                        HorizontalDivider()

                        Column {
                            Text("Langue de l'interface", fontWeight = FontWeight.SemiBold)
                            Text(selectedLanguage, fontSize = 12.sp, color = NexCyan)
                        }
                    }
                }
            }
        }
    }
}

// --- 2. Mon Compte ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountDetailsScreen(
    user: UserProfile,
    onBack: () -> Unit,
    onUpdateProfileDetails: (avatarUrl: String, bio: String) -> Unit = { _, _ -> }
) {
    var showPhotoModal by remember { mutableStateOf(false) }
    var showBioModal by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mon Compte", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Profile Avatar
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .border(2.dp, NexCyan, CircleShape)
                                .clickable { showPhotoModal = true },
                            contentAlignment = Alignment.Center
                        ) {
                            if (user.avatarUrl.isNotBlank()) {
                                coil.compose.AsyncImage(
                                    model = user.avatarUrl,
                                    contentDescription = "Photo de profil",
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize().clip(CircleShape)
                                )
                            } else {
                                Box(
                                    modifier = Modifier.fillMaxSize().background(NexElectricBlue),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = user.displayName.take(1).uppercase(),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 32.sp
                                    )
                                }
                            }
                        }

                        TextButton(onClick = { showPhotoModal = true }) {
                            Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp), tint = NexCyan)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Modifier la photo de profil", color = NexCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        HorizontalDivider()

                        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Informations Personnelles", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                            AccountFieldItem("Nom d'affichage", user.displayName)
                            AccountFieldItem("Identifiant unique", "@${user.username}")
                            AccountFieldItem("Adresse e-mail", user.email)
                            AccountFieldItem("Numéro de téléphone", user.phone)

                            // Interactive Bio Card
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                modifier = Modifier.fillMaxWidth().clickable { showBioModal = true }
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Biographie / Description", fontSize = 11.sp, color = NexCyan, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = if (user.bio.isNotBlank()) user.bio else "Ajouter une description...",
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Icon(Icons.Default.Edit, contentDescription = "Éditer", tint = NexCyan, modifier = Modifier.size(16.dp))
                                }
                            }

                            AccountFieldItem("Rôle attribué", user.role.displayName)
                            AccountFieldItem("Date d'inscription", SimpleDateFormat("dd MMMM yyyy", Locale.FRENCH).format(Date(user.createdAt)))
                        }
                    }
                }
            }
        }
    }

    if (showPhotoModal) {
        ProfilePhotoPickerModal(
            currentPhotoUrl = user.avatarUrl,
            onDismiss = { showPhotoModal = false },
            onSavePhoto = { url ->
                onUpdateProfileDetails(url, user.bio)
                showPhotoModal = false
            }
        )
    }

    if (showBioModal) {
        BioEditModalDialog(
            currentBio = user.bio,
            onDismiss = { showBioModal = false },
            onSaveBio = { bio ->
                onUpdateProfileDetails(user.avatarUrl, bio)
                showBioModal = false
            }
        )
    }
}

@Composable
fun AccountFieldItem(label: String, value: String) {
    Column {
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}

// --- 3. Confidentialité et Sécurité ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacySecurityScreen(
    user: UserProfile,
    onBack: () -> Unit,
    onToggleBlockUser: (String) -> Unit = {}
) {
    var readReceipts by remember { mutableStateOf(user.privacySettings.readReceiptsEnabled) }
    var onlinePresence by remember { mutableStateOf(user.privacySettings.onlinePresenceVisible) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Confidentialité & Sécurité", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Contrôle de Visibilité", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("Accusés de lecture (Check bleu)", fontWeight = FontWeight.SemiBold)
                                Text("Indique à vos correspondants lorsque vous avez lu un message", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = readReceipts, onCheckedChange = { readReceipts = it })
                        }

                        HorizontalDivider()

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("Présence en ligne", fontWeight = FontWeight.SemiBold)
                                Text("Affiche l'indicateur vert lorsque vous êtes connecté", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = onlinePresence, onCheckedChange = { onlinePresence = it })
                        }

                        HorizontalDivider()

                        Column {
                            Text("Qui peut m'appeler", fontWeight = FontWeight.SemiBold)
                            Text(user.privacySettings.whoCanCallMe, fontSize = 12.sp, color = NexCyan)
                        }

                        HorizontalDivider()

                        Column {
                            Text("Chiffrement de bout en bout", fontWeight = FontWeight.SemiBold)
                            Text("Clés privées générées localement sur l'appareil 🔒", fontSize = 12.sp, color = Color(0xFF10B981))
                        }
                    }
                }
            }

            // Blocked Users Management Card
            item {
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Block, contentDescription = null, tint = NexStatusSuspended, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Utilisateurs Bloqués (${user.privacySettings.blockedUsers.size})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        }
                        Text(
                            text = "Les contacts bloqués ne peuvent ni vous envoyer de messages ni vous appeler.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (user.privacySettings.blockedUsers.isEmpty()) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Aucun utilisateur bloqué.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        } else {
                            user.privacySettings.blockedUsers.forEach { blockedTarget ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(NexStatusSuspended.copy(alpha = 0.2f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.PersonOff, contentDescription = null, tint = NexStatusSuspended, modifier = Modifier.size(18.dp))
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text("@$blockedTarget", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text("Bloqué", fontSize = 10.sp, color = NexStatusSuspended)
                                        }
                                    }
                                    OutlinedButton(
                                        onClick = { onToggleBlockUser(blockedTarget) },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                    ) {
                                        Text("Débloquer", fontSize = 11.sp, color = NexCyan)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- 4. Personnalisation (Thèmes & Couleurs Néon) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonalizationSettingsScreen(
    user: UserProfile,
    onBack: () -> Unit,
    onUpdateTheme: (accentHex: Long, secondaryHex: Long, wallpaperIndex: Int) -> Unit,
    onUpdateThemeMode: (String) -> Unit = {}
) {
    val accentColors = listOf(
        Pair("Bleu Électrique (Officiel)", 0xFF0066FF),
        Pair("Cyan Néon / Turquoise", 0xFF00F5D4),
        Pair("Violet Cyberpunk", 0xFF8B5CF6),
        Pair("Vert Émeraude", 0xFF10B981)
    )
    var selectedAccent by remember { mutableLongStateOf(user.personalization.primaryAccentColorHex) }
    var selectedWallpaper by remember { mutableIntStateOf(user.personalization.chatWallpaperIndex) }
    var selectedThemeMode by remember { mutableStateOf(user.personalization.themeMode) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Personnalisation", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Theme Mode Selector (Light, Dark, System)
            item {
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DarkMode, contentDescription = null, tint = NexCyan, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Mode d'Affichage & Thème", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        }
                        Text(
                            text = "Choisissez l'apparence générale de NEXCHAT. Votre préférence est sauvegardée de manière persistante.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val modes = listOf(
                                Triple("DARK", "Sombre", Icons.Default.DarkMode),
                                Triple("LIGHT", "Clair", Icons.Default.LightMode),
                                Triple("SYSTEM", "Système", Icons.Default.SettingsBrightness)
                            )
                            modes.forEach { (modeKey, modeTitle, modeIcon) ->
                                val isSelected = selectedThemeMode == modeKey
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isSelected) NexElectricBlue.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant,
                                    border = androidx.compose.foundation.BorderStroke(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) NexCyan else Color.Transparent
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            selectedThemeMode = modeKey
                                            onUpdateThemeMode(modeKey)
                                        }
                                ) {
                                    Column(
                                        modifier = Modifier.padding(vertical = 12.dp, horizontal = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = modeIcon,
                                            contentDescription = null,
                                            tint = if (isSelected) NexCyan else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = modeTitle,
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) NexCyan else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Primary Accent Color
            item {
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Couleur d'Accent Principale", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)

                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            accentColors.forEach { (name, hex) ->
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(Color(hex))
                                        .border(
                                            width = if (selectedAccent == hex) 3.dp else 0.dp,
                                            color = Color.White,
                                            shape = CircleShape
                                        )
                                        .clickable {
                                            selectedAccent = hex
                                            onUpdateTheme(hex, 0xFF00F5D4, selectedWallpaper)
                                        }
                                )
                            }
                        }

                        HorizontalDivider()

                        Text("Style de Fond d'Écran des Discussions", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            listOf("Noir Profond", "Dégradé Cyber", "Étoilé Néon").forEachIndexed { index, name ->
                                FilterChip(
                                    selected = selectedWallpaper == index,
                                    onClick = {
                                        selectedWallpaper = index
                                        onUpdateTheme(selectedAccent, 0xFF00F5D4, index)
                                    },
                                    label = { Text(name, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- 5. À Propos de NexChat & Matrice des Autorisations ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutNexChatScreen(
    currentUserRole: UserRole,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("À propos de NexChat", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Brand Logo Artwork Presentation
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.nexchat_brand_logo),
                            contentDescription = "Logo officiel NexChat",
                            modifier = Modifier
                                .size(110.dp)
                                .clip(RoundedCornerShape(22.dp))
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("NexChat", fontWeight = FontWeight.Black, fontSize = 24.sp, color = NexCyan)
                        Text("Connect • Chat • Share", fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f))
                        Text("Version 2.5.0 (Build 2026.11)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "Messagerie temps réel • Réseau social sécurisé • Trust & Safety",
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Matrice Officielle des Autorisations par Rôle
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = NexCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Matrice des Autorisations par Rôle", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        }
                        Text(
                            text = "Contrôle d'accès strict côté serveur conforme à l'architecture multi-niveaux :",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                        UserRole.entries.forEach { role ->
                            Surface(
                                color = if (role == currentUserRole) NexElectricBlue.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(role.displayName, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (role == currentUserRole) NexCyan else MaterialTheme.colorScheme.onSurface)
                                        if (role == currentUserRole) {
                                            Surface(color = NexCyan, shape = RoundedCornerShape(4.dp)) {
                                                Text("VOTRE RÔLE", color = NexDeepBlack, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        RoleBadge("Modération", role.canModerate)
                                        RoleBadge("Gestion Users", role.canManageUsers)
                                        RoleBadge("Config Distante", role.canEditConfig)
                                        RoleBadge("Tarifs Pro", role.canManageBilling)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RoleBadge(label: String, allowed: Boolean) {
    Surface(
        color = if (allowed) Color(0xFF10B981).copy(alpha = 0.2f) else Color.Gray.copy(alpha = 0.2f),
        shape = RoundedCornerShape(4.dp)
    ) {
        Row(modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (allowed) Icons.Default.Check else Icons.Default.Close,
                contentDescription = null,
                tint = if (allowed) Color(0xFF10B981) else Color.Gray,
                modifier = Modifier.size(10.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(label, fontSize = 9.sp, color = if (allowed) Color(0xFF10B981) else Color.Gray, fontWeight = FontWeight.SemiBold)
        }
    }
}

// --- Main Settings Hub Screen ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsMainScreen(
    user: UserProfile,
    connectedSessions: List<com.example.model.ConnectedDeviceSession> = emptyList(),
    onNavigateToAccount: () -> Unit,
    onNavigateToPrivacy: () -> Unit,
    onNavigateToNotifications: () -> Unit,
    onNavigateToPersonalization: () -> Unit,
    onNavigateToDiscussions: () -> Unit,
    onNavigateToConnectedDevices: () -> Unit,
    onNavigateToSupport: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Paramètres", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        SettingsItemRow("1. Mon compte", "Gérer vos informations personnelles et identifiants", Icons.Default.AccountCircle, onNavigateToAccount, "settings_item_account")
                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        SettingsItemRow("2. Confidentialité et sécurité", "Chiffrement E2EE, masquage de statut et verrous", Icons.Default.Security, onNavigateToPrivacy, "settings_item_privacy")
                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        SettingsItemRow("3. Notifications", "Sons, vibrations et alertes de sécurité", Icons.Default.Notifications, onNavigateToNotifications, "settings_item_notifications")
                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        SettingsItemRow("4. Personnalisation", "Thèmes néon, fonds d'écran et polices", Icons.Default.Palette, onNavigateToPersonalization, "settings_item_personalization")
                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        SettingsItemRow("5. Discussions et messages", "Sauvegardes chiffrées et téléchargement média", Icons.Default.Forum, onNavigateToDiscussions, "settings_item_discussions")
                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        SettingsItemRow("6. Appareils connectés", "Consulter vos sessions actives et appareils", Icons.Default.Devices, onNavigateToConnectedDevices, "settings_item_devices")
                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        SettingsItemRow("7. Aide et assistance", "FAQ, tickets Gmail et support technique", Icons.Default.ContactSupport, onNavigateToSupport, "settings_item_support")
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsItemRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 14.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(NexCyan.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = NexCyan, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(text = subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// --- Notifications Settings Screen ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsSettingsScreen(
    onBack: () -> Unit
) {
    var pushEnabled by remember { mutableStateOf(true) }
    var soundEnabled by remember { mutableStateOf(true) }
    var vibrationEnabled by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Notifications", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Préférences de Notifications", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("Notifications Push", fontWeight = FontWeight.SemiBold)
                                Text("Recevoir des alertes instantanées pour les nouveaux messages", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = pushEnabled, onCheckedChange = { pushEnabled = it })
                        }

                        HorizontalDivider()

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("Sonnerie des messages", fontWeight = FontWeight.SemiBold)
                                Text("Émettre un signal sonore lors de la réception", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = soundEnabled, onCheckedChange = { soundEnabled = it })
                        }

                        HorizontalDivider()

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("Vibreur", fontWeight = FontWeight.SemiBold)
                                Text("Vibration personnalisée pour les conversations privées", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = vibrationEnabled, onCheckedChange = { vibrationEnabled = it })
                        }
                    }
                }
            }
        }
    }
}

// --- Discussions Settings Screen ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiscussionsSettingsScreen(
    onBack: () -> Unit
) {
    var autoMediaDownload by remember { mutableStateOf(true) }
    var enterToSend by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Discussions et messages", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Options des Messages", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("Téléchargement automatique des médias", fontWeight = FontWeight.SemiBold)
                                Text("Télécharger automatiquement les images et notes vocales", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = autoMediaDownload, onCheckedChange = { autoMediaDownload = it })
                        }

                        HorizontalDivider()

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("Touche Entrée pour envoyer", fontWeight = FontWeight.SemiBold)
                                Text("La touche Entrée du clavier envoie directement le message", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = enterToSend, onCheckedChange = { enterToSend = it })
                        }
                    }
                }
            }
        }
    }
}

// --- Connected Devices Screen ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectedDevicesScreen(
    sessions: List<com.example.model.ConnectedDeviceSession>,
    onDisconnectSession: (String) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Appareils connectés", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Devices, contentDescription = null, tint = NexCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Vos Sessions Actives", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        }
                        Text(
                            text = "Liste sécurisée de vos appareils connectés à votre compte NEXCHAT :",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        sessions.forEach { sess ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (sess.isCurrent) NexElectricBlue.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (sess.deviceType.contains("Web", ignoreCase = true) || sess.deviceType.contains("Desktop", ignoreCase = true)) Icons.Default.Computer else Icons.Default.Smartphone,
                                        contentDescription = null,
                                        tint = NexCyan,
                                        modifier = Modifier.size(28.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(sess.deviceName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            if (sess.isCurrent) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Surface(color = NexCyan, shape = RoundedCornerShape(4.dp)) {
                                                    Text("CET APPAREIL", color = NexDeepBlack, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                                }
                                            }
                                        }
                                        Text("${sess.deviceType} • ${sess.location}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("Dernière activité : ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRENCH).format(Date(sess.lastActive))}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    if (!sess.isCurrent) {
                                        TextButton(onClick = { onDisconnectSession(sess.sessionId) }) {
                                            Text("Révoker", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
