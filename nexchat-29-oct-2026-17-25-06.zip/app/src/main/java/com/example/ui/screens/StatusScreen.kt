package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.ReportEntityType
import com.example.model.StatusStory
import com.example.model.UserProfile
import com.example.ui.theme.NexCyan
import com.example.ui.theme.NexDeepBlack
import com.example.ui.theme.NexElectricBlue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val storyGradients = listOf(
    listOf(Color(0xFF0066FF), Color(0xFF00F5D4)),
    listOf(Color(0xFF8B5CF6), Color(0xFFEC4899)),
    listOf(Color(0xFFF59E0B), Color(0xFFEF4444)),
    listOf(Color(0xFF0F172A), Color(0xFF334155))
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatusScreen(
    stories: List<StatusStory>,
    currentUser: UserProfile,
    onPostStory: (caption: String, gradientIndex: Int, mediaType: String, mediaUrl: String?) -> Unit,
    onReportStory: (storyId: String) -> Unit
) {
    var showCreateModal by remember { mutableStateOf(false) }
    var selectedViewingStory by remember { mutableStateOf<StatusStory?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Statuts Temporaires (24h)", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateModal = true },
                containerColor = NexElectricBlue,
                contentColor = Color.White,
                modifier = Modifier.testTag("create_status_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Nouveau Statut")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                // My Status Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showCreateModal = true },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(NexElectricBlue),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Mon statut", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                            Text("Publier texte, photo, vidéo ou note vocale (expire à 24h)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Mises à jour récentes de vos contacts :",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            items(stories) { story ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedViewingStory = story }
                        .testTag("story_card_${story.id}"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val grad = storyGradients.getOrElse(story.backgroundGradientIndex) { storyGradients[0] }
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(grad)),
                            contentAlignment = Alignment.Center
                        ) {
                            val mediaIcon = when (story.mediaType) {
                                "PHOTO" -> Icons.Default.Image
                                "VIDEO" -> Icons.Default.Videocam
                                "AUDIO" -> Icons.Default.Mic
                                else -> Icons.Default.TextFields
                            }
                            Icon(imageVector = mediaIcon, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(story.authorName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = NexCyan.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = when (story.mediaType) {
                                            "PHOTO" -> "📷 Photo"
                                            "VIDEO" -> "🎥 Vidéo"
                                            "AUDIO" -> "🎙️ Audio"
                                            else -> "📝 Texte"
                                        },
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NexCyan,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            Text(story.textCaption, maxLines = 1, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            val remainingHours = ((story.expiresAt - System.currentTimeMillis()) / 3600000L).coerceAtLeast(0)
                            Text("Expire dans $remainingHours h • ${story.viewsCount} vues", fontSize = 10.sp, color = NexCyan)
                        }
                        IconButton(onClick = { onReportStory(story.id) }) {
                            Icon(Icons.Default.Report, contentDescription = "Signaler", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    // Modal Create Status
    if (showCreateModal) {
        var captionText by remember { mutableStateOf("") }
        var selectedGradIndex by remember { mutableIntStateOf(0) }
        var selectedMediaType by remember { mutableStateOf("TEXT") } // "TEXT", "PHOTO", "VIDEO", "AUDIO"
        var mediaUrlInput by remember { mutableStateOf("") }
        var audioSeconds by remember { mutableIntStateOf(15) }

        Dialog(onDismissRequest = { showCreateModal = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Nouveau Statut 24h", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

                    // Media type selector tabs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf(
                            Triple("TEXT", "Texte", Icons.Default.TextFields),
                            Triple("PHOTO", "Photo", Icons.Default.Image),
                            Triple("VIDEO", "Vidéo", Icons.Default.Videocam),
                            Triple("AUDIO", "Audio", Icons.Default.Mic)
                        ).forEach { (type, label, icon) ->
                            FilterChip(
                                selected = selectedMediaType == type,
                                onClick = { selectedMediaType = type },
                                label = { Text(label, fontSize = 11.sp) },
                                leadingIcon = { Icon(icon, contentDescription = null, modifier = Modifier.size(14.dp)) },
                                modifier = Modifier.testTag("status_media_tab_$type")
                            )
                        }
                    }

                    // Content preview depending on media type
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Brush.linearGradient(storyGradients[selectedGradIndex])),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(12.dp)
                        ) {
                            when (selectedMediaType) {
                                "PHOTO" -> {
                                    Icon(Icons.Default.AddAPhoto, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Image sélectionnée / Galerie", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                                "VIDEO" -> {
                                    Icon(Icons.Default.PlayCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Vidéo HD sélectionnée (0:30)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                                "AUDIO" -> {
                                    Icon(Icons.Default.GraphicEq, contentDescription = null, tint = NexCyan, modifier = Modifier.size(36.dp))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Note vocale enregistrée (${audioSeconds}s)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                else -> {
                                    Text(
                                        text = captionText.ifBlank { "Votre message apparaîtra ici..." },
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }
                            }
                        }
                    }

                    // Gradient picker
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        storyGradients.forEachIndexed { idx, colors ->
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(colors))
                                    .clickable { selectedGradIndex = idx }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = captionText,
                        onValueChange = { captionText = it },
                        placeholder = {
                            Text(
                                when (selectedMediaType) {
                                    "PHOTO" -> "Ajouter une légende photo..."
                                    "VIDEO" -> "Ajouter une description vidéo..."
                                    "AUDIO" -> "Ajouter un titre à la note vocale..."
                                    else -> "Écrivez votre message de statut..."
                                }
                            )
                        },
                        modifier = Modifier.fillMaxWidth().testTag("status_caption_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { showCreateModal = false }, modifier = Modifier.weight(1f)) {
                            Text("Annuler")
                        }
                        Button(
                            onClick = {
                                val captionToPost = captionText.ifBlank {
                                    when (selectedMediaType) {
                                        "PHOTO" -> "Photo partagée sur mon statut"
                                        "VIDEO" -> "Vidéo partagée sur mon statut"
                                        "AUDIO" -> "Note vocale de statut"
                                        else -> "Mise à jour"
                                    }
                                }
                                onPostStory(captionToPost, selectedGradIndex, selectedMediaType, mediaUrlInput.ifBlank { null })
                                showCreateModal = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue),
                            modifier = Modifier.weight(1f).testTag("publish_status_button")
                        ) {
                            Text("Publier (24h)", color = Color.White)
                        }
                    }
                }
            }
        }
    }

    // Modal View Story
    if (selectedViewingStory != null) {
        val st = selectedViewingStory!!
        Dialog(onDismissRequest = { selectedViewingStory = null }) {
            val grad = storyGradients.getOrElse(st.backgroundGradientIndex) { storyGradients[0] }
            var isAudioPlaying by remember { mutableStateOf(false) }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.7f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.linearGradient(grad))
                    .padding(20.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(st.authorName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(color = Color.Black.copy(alpha = 0.4f), shape = RoundedCornerShape(4.dp)) {
                                    Text(
                                        text = when (st.mediaType) {
                                            "PHOTO" -> "📷 PHOTO"
                                            "VIDEO" -> "🎥 VIDÉO"
                                            "AUDIO" -> "🎙️ AUDIO"
                                            else -> "📝 TEXTE"
                                        },
                                        color = NexCyan,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text("Audience: ${st.audience}", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                        }
                        IconButton(onClick = { onReportStory(st.id) }) {
                            Icon(Icons.Default.Report, contentDescription = "Signaler", tint = Color.White)
                        }
                    }

                    Box(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        when (st.mediaType) {
                            "PHOTO" -> {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Surface(
                                        color = Color.White.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier.size(160.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.Image, contentDescription = null, tint = Color.White, modifier = Modifier.size(64.dp))
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(st.textCaption, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                }
                            }
                            "VIDEO" -> {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Surface(
                                        color = Color.Black.copy(alpha = 0.3f),
                                        shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier.fillMaxWidth().height(160.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.PlayCircle, contentDescription = "Lire la vidéo", tint = NexCyan, modifier = Modifier.size(64.dp))
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(st.textCaption, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                }
                            }
                            "AUDIO" -> {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Surface(
                                        color = Color.Black.copy(alpha = 0.4f),
                                        shape = RoundedCornerShape(24.dp),
                                        modifier = Modifier.fillMaxWidth().padding(16.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            IconButton(
                                                onClick = { isAudioPlaying = !isAudioPlaying },
                                                modifier = Modifier.size(44.dp).background(NexCyan, CircleShape)
                                            ) {
                                                Icon(
                                                    if (isAudioPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                    contentDescription = null,
                                                    tint = NexDeepBlack
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text("Note Vocale de Statut", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                Text("Durée : ${if (st.audioDurationSeconds > 0) st.audioDurationSeconds else 15}s • HD Audio", color = NexCyan, fontSize = 11.sp)
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(st.textCaption, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                }
                            }
                            else -> {
                                Text(
                                    text = st.textCaption,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 22.sp,
                                    modifier = Modifier.padding(16.dp)
                                )
                            }
                        }
                    }

                    Surface(
                        color = Color.Black.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "Consulté par ${st.viewsCount} contacts • Chiffrement temporaire",
                            color = Color.White,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }
    }
}
