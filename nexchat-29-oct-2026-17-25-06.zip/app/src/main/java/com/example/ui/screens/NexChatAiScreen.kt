package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ai.AiMessage
import com.example.ai.AiProvider
import com.example.ui.theme.NexCyan
import com.example.ui.theme.NexDeepBlack
import com.example.ui.theme.NexElectricBlue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NexChatAiScreen(
    messages: List<AiMessage>,
    isLoading: Boolean,
    streamingText: String,
    currentProvider: AiProvider,
    onSendMessage: (String) -> Unit,
    onClearHistory: () -> Unit,
    onSelectProvider: (AiProvider) -> Unit,
    onNavigateToRules: () -> Unit,
    onNavigateToAppeal: () -> Unit,
    onNavigateToSupport: () -> Unit
) {
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    var showProviderMenu by remember { mutableStateOf(false) }
    var showApiConfigModal by remember { mutableStateOf(false) }

    LaunchedEffect(messages.size, streamingText) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(NexCyan.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SmartToy,
                                contentDescription = null,
                                tint = NexCyan,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("NEXCHAT AI STUDIO", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Surface(color = NexCyan, shape = RoundedCornerShape(4.dp)) {
                                    Text("API PRO", color = NexDeepBlack, fontSize = 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                }
                            }
                            Text(
                                "Modèle : ${currentProvider.displayName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = NexCyan,
                                maxLines = 1
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showApiConfigModal = true },
                        modifier = Modifier.testTag("ai_api_config_btn")
                    ) {
                        Icon(Icons.Default.SettingsSuggest, contentDescription = "Configuration API", tint = NexCyan)
                    }

                    Box {
                        IconButton(
                            onClick = { showProviderMenu = true },
                            modifier = Modifier.testTag("ai_provider_selector_button")
                        ) {
                            Icon(Icons.Default.Tune, contentDescription = "Fournisseur IA", tint = NexCyan)
                        }
                        DropdownMenu(
                            expanded = showProviderMenu,
                            onDismissRequest = { showProviderMenu = false }
                        ) {
                            AiProvider.entries.forEach { p ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(p.displayName, fontWeight = FontWeight.SemiBold)
                                            Text(p.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    },
                                    onClick = {
                                        onSelectProvider(p)
                                        showProviderMenu = false
                                    }
                                )
                            }
                        }
                    }
                    IconButton(
                        onClick = onClearHistory,
                        modifier = Modifier.testTag("clear_ai_history_button")
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Effacer l'historique", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Messages Feed
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                if (messages.isEmpty() && streamingText.isEmpty()) {
                    item {
                        AiWelcomeBanner(
                            onSelectPresetPrompt = { prompt -> onSendMessage(prompt) }
                        )
                    }
                }

                items(messages, key = { it.id }) { msg ->
                    AiChatBubbleItem(
                        message = msg,
                        onNavigateToRules = onNavigateToRules,
                        onNavigateToAppeal = onNavigateToAppeal,
                        onNavigateToSupport = onNavigateToSupport
                    )
                }

                // Progressive Streaming Chunk Preview
                if (isLoading && streamingText.isNotEmpty()) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth().padding(end = 40.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = NexCyan)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Génération en cours via API...", fontSize = 11.sp, color = NexCyan, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = streamingText,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            // Quick Prompt Chips (Coding, Fast Images & Rules)
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                item {
                    AssistChip(
                        onClick = { onSendMessage("Écris une fonction Kotlin de chiffrement E2EE avec Coroutines et Flow") },
                        label = { Text("💻 Coder en Kotlin", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.Code, null, modifier = Modifier.size(14.dp), tint = NexCyan) }
                    )
                }
                item {
                    AssistChip(
                        onClick = { onSendMessage("Écris un script Python asynchrone pour l'API NexChat avec HMAC") },
                        label = { Text("🐍 Coder en Python", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.Terminal, null, modifier = Modifier.size(14.dp), tint = NexCyan) }
                    )
                }
                item {
                    AssistChip(
                        onClick = { onSendMessage("Génère une image rapide d'une ville cyberpunk sous la pluie 1080p") },
                        label = { Text("⚡ Image Cyberpunk", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.Palette, null, modifier = Modifier.size(14.dp), tint = NexCyan) }
                    )
                }
                item {
                    AssistChip(
                        onClick = { onSendMessage("Génère un logo futuriste néon 3D pour NexChat") },
                        label = { Text("🎨 Logo Néon 3D", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.Brush, null, modifier = Modifier.size(14.dp), tint = NexCyan) }
                    )
                }
                item {
                    AssistChip(
                        onClick = { onSendMessage("Quelles sont les 14 règles officielles de NEXCHAT v2.4.1 ?") },
                        label = { Text("📜 14 Règles", fontSize = 11.sp) }
                    )
                }
            }

            // Input Bar
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = { Text("Demander du code, une image rapide, etc...") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ai_input_text_field"),
                        shape = RoundedCornerShape(24.dp),
                        maxLines = 3
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank() && !isLoading) {
                                val query = inputText
                                inputText = ""
                                onSendMessage(query)
                            }
                        },
                        colors = IconButtonDefaults.iconButtonColors(containerColor = NexElectricBlue),
                        enabled = inputText.isNotBlank() && !isLoading,
                        modifier = Modifier.testTag("send_ai_prompt_button")
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Envoyer", tint = Color.White)
                        }
                    }
                }
            }
        }
    }

    // Modal Configuration API
    if (showApiConfigModal) {
        var selectedModel by remember { mutableStateOf("gemini-3.8-flash") }
        var isCodingMode by remember { mutableStateOf(true) }
        var isFastImageMode by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { showApiConfigModal = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.SettingsSuggest, contentDescription = null, tint = NexCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Configuration API NexChat AI", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Paramètres avancés du moteur d'IA pour le code et les images rapides :", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Card(shape = RoundedCornerShape(10.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Modèle Fondamental Actif", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = NexCyan)
                            Text("Gemini 3.8 Flash (Optimisé pour la programmation et réponses en < 0.5s)", fontSize = 12.sp)

                            HorizontalDivider()

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Moteur d'assistance au Code", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Switch(checked = isCodingMode, onCheckedChange = { isCodingMode = it })
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Génération d'Images Rapides", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Switch(checked = isFastImageMode, onCheckedChange = { isFastImageMode = it })
                            }
                        }
                    }

                    Text("Statut API : Connectée et prête ⚡ (Chiffrement sécurisé)", fontSize = 11.sp, color = NexCyan, fontWeight = FontWeight.Bold)
                }
            },
            confirmButton = {
                Button(onClick = { showApiConfigModal = false }, colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue)) {
                    Text("Appliquer")
                }
            }
        )
    }
}

@Composable
fun AiWelcomeBanner(
    onSelectPresetPrompt: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(NexCyan.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Terminal, contentDescription = null, tint = NexCyan, modifier = Modifier.size(32.dp))
            }

            Text("NexChat AI Studio & API", fontWeight = FontWeight.Black, fontSize = 18.sp, color = NexCyan)
            Text(
                "Assistant tout-en-un pour répondre à vos questions, coder dans tous les langages et générer des images en temps réel.",
                fontSize = 12.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

            Text("Exemples de requêtes rapides :", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)

            Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                PresetPromptRow("💻 Écris une fonction Kotlin pour valider un hash E2EE") { onSelectPresetPrompt(it) }
                PresetPromptRow("🐍 Génère un script Python pour envoyer des messages sécurisés") { onSelectPresetPrompt(it) }
                PresetPromptRow("🎨 Dessine une ville cyberpunk lumineuse en 1080p") { onSelectPresetPrompt(it) }
                PresetPromptRow("📋 Quelles sanctions en cas de violation des règles ?") { onSelectPresetPrompt(it) }
            }
        }
    }
}

@Composable
fun PresetPromptRow(text: String, onClick: (String) -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth().clickable { onClick(text) }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Bolt, contentDescription = null, tint = NexCyan, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
        }
    }
}

@Composable
fun AiChatBubbleItem(
    message: AiMessage,
    onNavigateToRules: () -> Unit,
    onNavigateToAppeal: () -> Unit,
    onNavigateToSupport: () -> Unit
) {
    val isUser = message.sender == "USER"
    val time = SimpleDateFormat("HH:mm", Locale.FRENCH).format(Date(message.timestamp))
    val clipboardManager = LocalClipboardManager.current
    var isCodeCopied by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Row(
            verticalAlignment = Alignment.Top,
            modifier = Modifier.fillMaxWidth(if (isUser) 0.85f else 0.95f)
        ) {
            if (!isUser) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(NexCyan),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.SmartToy, contentDescription = null, tint = NexDeepBlack, modifier = Modifier.size(16.dp))
                }
                Spacer(modifier = Modifier.width(6.dp))
            }

            Surface(
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isUser) 16.dp else 4.dp,
                    bottomEnd = if (isUser) 4.dp else 16.dp
                ),
                color = if (isUser) NexElectricBlue else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // 1. Fast Generated Image Card Render
                    if (message.isFastImage || message.generatedImageUrl != null) {
                        val imgUrl = message.generatedImageUrl ?: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=1080"
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = NexDeepBlack),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(color = NexCyan, shape = RoundedCornerShape(4.dp)) {
                                        Text("FAST IMAGE ENGINE ⚡", color = NexDeepBlack, fontSize = 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                    Text("1080x1080 HD • 0.6s", fontSize = 10.sp, color = NexCyan, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(8.dp))

                                AsyncImage(
                                    model = imgUrl,
                                    contentDescription = "Rendu Image IA",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(180.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                )
                            }
                        }
                    }

                    // 2. Syntax-Highlighted Code Block
                    if (message.isCodeBlock && message.codeSnippet != null) {
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                        ) {
                            Column {
                                // Code Header Bar
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF1E293B))
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFEF4444)))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFEAB308)))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF22C55E)))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(message.codeLanguage ?: "CODE", fontSize = 10.sp, color = NexCyan, fontWeight = FontWeight.Bold)
                                    }

                                    TextButton(
                                        onClick = {
                                            clipboardManager.setText(AnnotatedString(message.codeSnippet))
                                            isCodeCopied = true
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.height(24.dp)
                                    ) {
                                        Icon(
                                            if (isCodeCopied) Icons.Default.Check else Icons.Default.ContentCopy,
                                            contentDescription = "Copier",
                                            tint = NexCyan,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(if (isCodeCopied) "Copié !" else "Copier", fontSize = 10.sp, color = NexCyan)
                                    }
                                }

                                // Code Content in Monospace
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState())
                                        .padding(10.dp)
                                ) {
                                    Text(
                                        text = message.codeSnippet,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        color = Color(0xFFE2E8F0)
                                    )
                                }
                            }
                        }
                    }

                    // 3. Text Message Content
                    Text(
                        text = message.content,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = time,
                        fontSize = 9.sp,
                        color = if (isUser) Color.White.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.align(Alignment.End)
                    )
                }
            }
        }

        // Action buttons if relevant
        if (!isUser) {
            val contentLower = message.content.lowercase()
            Row(
                modifier = Modifier.padding(start = 34.dp, top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (contentLower.contains("règle") || contentLower.contains("14")) {
                    OutlinedButton(
                        onClick = onNavigateToRules,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text("Consulter les Règles", fontSize = 10.sp)
                    }
                }
                if (contentLower.contains("recours")) {
                    Button(
                        onClick = onNavigateToAppeal,
                        colors = ButtonDefaults.buttonColors(containerColor = NexCyan),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text("Ouvrir Recours", fontSize = 10.sp, color = NexDeepBlack)
                    }
                }
                if (contentLower.contains("gmail") || contentLower.contains("support")) {
                    OutlinedButton(
                        onClick = onNavigateToSupport,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text("Contacter Support Gmail", fontSize = 10.sp)
                    }
                }
            }
        }
    }
}
