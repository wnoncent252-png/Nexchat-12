package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallMissed
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.CallDirection
import com.example.model.CallRecord
import com.example.model.CallType
import com.example.ui.theme.NexCyan
import com.example.ui.theme.NexDeepBlack
import com.example.ui.theme.NexElectricBlue
import com.example.ui.theme.NexStatusSuspended
import com.example.viewmodel.ActiveCallState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallsScreen(
    callLogs: List<CallRecord>,
    onStartCall: (contactName: String, type: CallType) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Journal des Appels Sécurisés", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = NexCyan)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Tous les appels vocaux et vidéo bénéficient d'un chiffrement de bout en bout.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            items(callLogs) { log ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().testTag("call_record_${log.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(NexElectricBlue.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (log.type == CallType.VIDEO) Icons.Default.Videocam else Icons.Default.Call,
                                contentDescription = null,
                                tint = NexCyan
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(log.contactName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val (icon, tint) = when (log.direction) {
                                    CallDirection.INCOMING -> Pair(Icons.AutoMirrored.Filled.CallReceived, Color(0xFF10B981))
                                    CallDirection.OUTGOING -> Pair(Icons.AutoMirrored.Filled.CallMade, NexElectricBlue)
                                    CallDirection.MISSED -> Pair(Icons.AutoMirrored.Filled.CallMissed, NexStatusSuspended)
                                }
                                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${log.durationText} • ${SimpleDateFormat("dd/MM HH:mm", Locale.FRENCH).format(Date(log.timestamp))}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        IconButton(onClick = { onStartCall(log.contactName, log.type) }) {
                            Icon(
                                imageVector = if (log.type == CallType.VIDEO) Icons.Default.Videocam else Icons.Default.Call,
                                contentDescription = "Rappeler",
                                tint = NexElectricBlue
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ActiveCallOverlay(
    activeCall: ActiveCallState,
    onToggleMute: () -> Unit,
    onToggleVideo: () -> Unit,
    onUpdateDuration: (Int) -> Unit = {},
    onEndCall: () -> Unit
) {
    var callTimerSeconds by remember { mutableIntStateOf(activeCall.durationSeconds) }

    // Ticking Live Timer
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(1000L)
            callTimerSeconds++
            onUpdateDuration(callTimerSeconds)
        }
    }

    val timerFormatted = String.format(Locale.FRENCH, "%02d:%02d", callTimerSeconds / 60, callTimerSeconds % 60)

    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = NexDeepBlack,
            modifier = Modifier.fillMaxSize()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top contact info
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(modifier = Modifier.height(48.dp))
                    Text(
                        text = activeCall.contactName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 26.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        color = NexCyan.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (activeCall.callType == CallType.VIDEO) "Appel Vidéo Chiffré E2EE 🔒" else "Appel Vocal Chiffré E2EE 🔒",
                            color = NexCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "En communication ($timerFormatted)",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }


                // Center visual avatar
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .clip(CircleShape)
                        .background(NexElectricBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = activeCall.contactName.take(1),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 54.sp
                    )
                }

                // Controls (Mute, Video, Hangup)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onToggleMute,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(if (activeCall.isMuted) Color.White else MaterialTheme.colorScheme.surfaceVariant)
                            .testTag("mute_call_button")
                    ) {
                        Icon(
                            imageVector = if (activeCall.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = "Microphone",
                            tint = if (activeCall.isMuted) Color.Black else Color.White
                        )
                    }

                    if (activeCall.callType == CallType.VIDEO) {
                        IconButton(
                            onClick = onToggleVideo,
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(if (activeCall.isVideoOff) Color.White else MaterialTheme.colorScheme.surfaceVariant)
                                .testTag("video_call_button")
                        ) {
                            Icon(
                                imageVector = if (activeCall.isVideoOff) Icons.Default.VideocamOff else Icons.Default.Videocam,
                                contentDescription = "Caméra",
                                tint = if (activeCall.isVideoOff) Color.Black else Color.White
                            )
                        }
                    }

                    IconButton(
                        onClick = onEndCall,
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(NexStatusSuspended)
                            .testTag("end_call_button")
                    ) {
                        Icon(Icons.Default.CallEnd, contentDescription = "Raccrocher", tint = Color.White, modifier = Modifier.size(32.dp))
                    }
                }
            }
        }
    }
}
