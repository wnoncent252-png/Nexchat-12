package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SupportTicket
import com.example.model.TicketCategory
import com.example.model.UserProfile
import com.example.ui.theme.NexCyan
import com.example.ui.theme.NexElectricBlue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SupportCenterScreen(
    currentUser: UserProfile,
    tickets: List<SupportTicket>,
    onSubmitTicket: (email: String, category: TicketCategory, deviceType: String, description: String) -> Unit
) {
    var emailInput by remember { mutableStateOf(currentUser.email) }
    var selectedCategory by remember { mutableStateOf(TicketCategory.ACCOUNT_BLOCKED) }
    var deviceTypeInput by remember { mutableStateOf("Android (Pixel 9 Pro)") }
    var descriptionInput by remember { mutableStateOf("") }
    var isCategoryDropdownExpanded by remember { mutableStateOf(false) }

    val visibleTickets = remember(tickets, currentUser) {
        if (currentUser.role.canModerate || currentUser.role.canEditConfig) {
            tickets
        } else {
            tickets.filter { it.userEmail.equals(currentUser.email, ignoreCase = true) || it.userEmail.isBlank() }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.HelpOutline, contentDescription = null, tint = NexCyan)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Centre d'Assistance & Gmail", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Support Officiel NEXCHAT HQ", fontSize = 11.sp, color = NexCyan)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Email, contentDescription = null, tint = NexElectricBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Passerelle Officielle Support Gmail", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        }
                        Text(
                            text = "Toute demande transmise génère un numéro de dossier unique (format NEX-XXXXX) avec horodatage et transfert vers notre boîte support Gmail sécurisée.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Ticket Creation Form
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Ouvrir un nouveau dossier de support", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)

                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { emailInput = it },
                            label = { Text("Adresse e-mail de contact") },
                            leadingIcon = { Icon(Icons.Default.AlternateEmail, null) },
                            modifier = Modifier.fillMaxWidth().testTag("support_email_input"),
                            shape = RoundedCornerShape(10.dp)
                        )

                        // Category Selector
                        Box {
                            OutlinedTextField(
                                value = selectedCategory.label,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Catégorie du problème") },
                                trailingIcon = {
                                    IconButton(onClick = { isCategoryDropdownExpanded = true }) {
                                        Icon(Icons.Default.ArrowDropDown, null)
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )
                            DropdownMenu(
                                expanded = isCategoryDropdownExpanded,
                                onDismissRequest = { isCategoryDropdownExpanded = false }
                            ) {
                                TicketCategory.entries.forEach { cat ->
                                    DropdownMenuItem(
                                        text = { Text(cat.label) },
                                        onClick = {
                                            selectedCategory = cat
                                            isCategoryDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = deviceTypeInput,
                            onValueChange = { deviceTypeInput = it },
                            label = { Text("Type d'appareil & Système") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = descriptionInput,
                            onValueChange = { descriptionInput = it },
                            label = { Text("Description détaillée du problème") },
                            placeholder = { Text("Expliquez ce qui s'est produit...") },
                            modifier = Modifier.fillMaxWidth().height(110.dp).testTag("support_description_input"),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Button(
                            onClick = {
                                if (descriptionInput.isNotBlank()) {
                                    onSubmitTicket(emailInput, selectedCategory, deviceTypeInput, descriptionInput)
                                    descriptionInput = ""
                                }
                            },
                            enabled = descriptionInput.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue),
                            modifier = Modifier.fillMaxWidth().testTag("submit_ticket_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Transmettre à l'équipe Gmail", color = Color.White)
                        }
                    }
                }
            }

            // Existing Tickets
            item {
                Text(
                    text = "Vos dossiers de support ouverts :",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleSmall
                )
            }

            items(visibleTickets) { ticket ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth().testTag("ticket_item_${ticket.ticketNumber}")
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Dossier ${ticket.ticketNumber}", fontWeight = FontWeight.Bold, color = NexCyan)
                            Surface(
                                color = NexElectricBlue.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = ticket.status.label,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NexElectricBlue,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text("Catégorie : ${ticket.category.label}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Text(ticket.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                        val date = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRENCH).format(Date(ticket.createdAt))
                        Text("Ouvert le $date • Appareil : ${ticket.deviceType}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                        ticket.messages.forEach { msg ->
                            Surface(
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(msg.sender, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NexCyan)
                                    Text(msg.text, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
