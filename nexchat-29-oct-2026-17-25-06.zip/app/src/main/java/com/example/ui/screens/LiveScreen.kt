package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LiveComment
import com.example.model.LiveStream
import com.example.model.UserProfile
import com.example.ui.theme.NexCyan
import com.example.ui.theme.NexDeepBlack
import com.example.ui.theme.NexElectricBlue
import com.example.ui.theme.NexStatusSuspended

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveScreen(
    lives: List<LiveStream>,
    comments: List<LiveComment>,
    currentUser: UserProfile,
    selectedLiveId: String?,
    onSelectLive: (String) -> Unit,
    onBackToList: () -> Unit,
    onSendComment: (liveId: String, text: String) -> Unit,
    onReportLive: (liveId: String) -> Unit
) {
    if (selectedLiveId != null) {
        val currentLive = lives.find { it.id == selectedLiveId }
            ?: LiveStream(selectedLiveId, "hq", "Live NEXCHAT", "Diffusion", "Direct", 100, true, System.currentTimeMillis())

        ActiveLivePlayerView(
            live = currentLive,
            comments = comments.filter { it.liveId == selectedLiveId },
            currentUser = currentUser,
            onBack = onBackToList,
            onSendComment = { text -> onSendComment(currentLive.id, text) },
            onReportLive = { onReportLive(currentLive.id) }
        )
    } else {
        LiveStreamsListView(
            lives = lives,
            onSelectLive = onSelectLive
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveStreamsListView(
    lives: List<LiveStream>,
    onSelectLive: (String) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("NexChat Lives en Direct", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(NexStatusSuspended),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.LiveTv, contentDescription = null, tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Diffusions Modérées en Temps Réel", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            Text("Les créateurs et spectateurs sont tenus au respect strict de la charte de sécurité.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            items(lives) { live ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectLive(live.id) }
                        .testTag("live_card_${live.id}"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = NexStatusSuspended,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "EN DIRECT",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Visibility, contentDescription = null, tint = NexCyan, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("${live.viewersCount} spectateurs", fontSize = 12.sp, color = NexCyan, fontWeight = FontWeight.Bold)
                            }
                        }

                        Text(live.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text(live.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Diffuseur : ${live.streamerName} • ${live.category}", fontSize = 11.sp, color = NexElectricBlue)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActiveLivePlayerView(
    live: LiveStream,
    comments: List<LiveComment>,
    currentUser: UserProfile,
    onBack: () -> Unit,
    onSendComment: (String) -> Unit,
    onReportLive: () -> Unit
) {
    var commentInput by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(live.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                        Text("${live.viewersCount} spectateurs • Par ${live.streamerName}", fontSize = 11.sp, color = NexCyan)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    IconButton(onClick = onReportLive, modifier = Modifier.testTag("report_live_button")) {
                        Icon(Icons.Default.Report, contentDescription = "Signaler ce Live", tint = MaterialTheme.colorScheme.error)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Simulated Live Video Stage
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .background(Color(0xFF070B12)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(NexElectricBlue.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = null, tint = NexCyan, modifier = Modifier.size(34.dp))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Flux Vidéo Haute Définition WebRTC Chiffré", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Canal certifié • Modération proactive active", color = NexCyan, fontSize = 11.sp)
                }

                Surface(
                    color = NexStatusSuspended,
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
                ) {
                    Text("LIVE REC", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                }
            }

            // Live Comments Stream
            Text(
                text = "Commentaires en direct :",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
            )

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(comments) { c ->
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                            Text(text = "${c.authorName} : ", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = NexCyan)
                            Text(text = c.comment, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }

            // Comment Input
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = commentInput,
                        onValueChange = { commentInput = it },
                        placeholder = { Text("Commenter en direct...") },
                        modifier = Modifier.weight(1f).testTag("live_comment_input"),
                        shape = RoundedCornerShape(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (commentInput.isNotBlank()) {
                                onSendComment(commentInput)
                                commentInput = ""
                            }
                        },
                        colors = IconButtonDefaults.iconButtonColors(containerColor = NexElectricBlue),
                        modifier = Modifier.testTag("send_live_comment_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Envoyer", tint = Color.White)
                    }
                }
            }
        }
    }
}
