package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.model.UserProfile
import com.example.ui.theme.NexCyan
import com.example.ui.theme.NexDeepBlack
import com.example.ui.theme.NexElectricBlue

data class ChannelPost(
    val id: String,
    val channelId: String,
    val channelName: String,
    val textContent: String,
    val mediaType: String? = null, // "IMAGE", "VIDEO", "AUDIO"
    val timestamp: Long,
    val viewsCount: Int,
    val likesCount: Int,
    val userReaction: String? = null
)

data class ChannelData(
    val id: String,
    val name: String,
    val handle: String,
    val category: String,
    val description: String,
    val followerCount: Int,
    val isOfficialVerified: Boolean = true,
    var isSubscribed: Boolean = false,
    val avatarUrl: String = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300",
    val creatorName: String = "Équipe Officielle NexChat",
    val creatorHandle: String = "@admin_nexchat",
    val creatorBio: String = "Créateur et gestionnaire certifié de cette chaîne officielle.",
    val posts: List<ChannelPost> = emptyList()
)

val initialChannels = listOf(
    ChannelData(
        id = "chn_actu",
        name = "NexChat Actu & Flash",
        handle = "@nexchat_actu",
        category = "Actualités",
        description = "Canal officiel d'actualités en temps réel, annonces de sécurité et mises à jour système.",
        followerCount = 148200,
        isOfficialVerified = true,
        isSubscribed = true,
        avatarUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300",
        creatorName = "NexChat Communications",
        creatorHandle = "@nexchat_hq",
        creatorBio = "Direction de la communication et des relations publiques NEXCHAT.",
        posts = listOf(
            ChannelPost("p_01", "chn_actu", "NexChat Actu & Flash", "🚀 Version 2.5.0 déployée ! Découvrez les nouvelles Chaînes certifiées, les appels HD chiffrés et l'assistant vocal NexChat AI.", "IMAGE", System.currentTimeMillis() - 3600000L * 2, 18400, 1240),
            ChannelPost("p_02", "chn_actu", "NexChat Actu & Flash", "🔒 Rapport Trust & Safety : 99,8% des tentatives de spam neutralisées par notre algorithme serveur ce mois-ci.", null, System.currentTimeMillis() - 86400000L, 24100, 2100)
        )
    ),
    ChannelData(
        id = "chn_security",
        name = "Cyber Security Watch",
        handle = "@cyber_security",
        category = "Tech & Sécurité",
        description = "Veille cybersécurité, conseils de protection des données et alertes phishing en temps réel.",
        followerCount = 89400,
        isOfficialVerified = true,
        isSubscribed = true,
        avatarUrl = "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=300",
        creatorName = "Alexandre Martin",
        creatorHandle = "@alex_sec",
        creatorBio = "Directeur de la Sécurité des Systèmes d'Information (RSSI).",
        posts = listOf(
            ChannelPost("p_03", "chn_security", "Cyber Security Watch", "🛡️ Rappel important : Activer l'authentification à deux facteurs et vérifier la liste de vos sessions actives.", "VIDEO", System.currentTimeMillis() - 3600000L * 5, 12800, 950)
        )
    ),
    ChannelData(
        id = "chn_pro",
        name = "NexChat Pro Insiders",
        handle = "@pro_insiders",
        category = "Pro & Business",
        description = "Espace exclusif pour les membres Pro : aperçus en avant-première des fonctionnalités et conseils de productivité.",
        followerCount = 42100,
        isOfficialVerified = true,
        isSubscribed = false,
        avatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300",
        creatorName = "Sarah Chen",
        creatorHandle = "@sarah_pro",
        creatorBio = "Lead Product Manager NexChat Pro & Expérience Utilisateur.",
        posts = listOf(
            ChannelPost("p_04", "chn_pro", "NexChat Pro Insiders", "💎 Le badge VIP PRO est désormais visible dans vos profils et dans les discussions sécurisées.", "IMAGE", System.currentTimeMillis() - 3600000L * 4, 9800, 810)
        )
    ),
    ChannelData(
        id = "chn_gaming",
        name = "Gaming & eSports Club",
        handle = "@gaming_club",
        category = "Gaming",
        description = "Communauté de gamers, partages de streams et organisation de tournois communautaires.",
        followerCount = 62300,
        isOfficialVerified = false,
        isSubscribed = false,
        avatarUrl = "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300",
        creatorName = "Marc Lecomte",
        creatorHandle = "@marc_esport",
        creatorBio = "Organisateur de tournois gaming et animateur de communauté.",
        posts = listOf(
            ChannelPost("p_05", "chn_gaming", "Gaming & eSports Club", "🎮 Le grand tournoi eSports du week-end commence ce samedi. Suivez les Lives en direct !", null, System.currentTimeMillis() - 3600000L * 8, 14200, 1120)
        )
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChannelsScreen(
    currentUser: UserProfile,
    onReportChannel: (channelId: String) -> Unit = {}
) {
    var channelsList by remember { mutableStateOf(initialChannels) }
    var selectedCategory by remember { mutableStateOf("Toutes") }
    var searchQuery by remember { mutableStateOf("") }
    var showCreateChannelModal by remember { mutableStateOf(false) }
    var selectedViewingChannel by remember { mutableStateOf<ChannelData?>(null) }
    var viewingChannelProfile by remember { mutableStateOf<ChannelData?>(null) }

    val categories = listOf("Toutes", "Actualités", "Tech & Sécurité", "Pro & Business", "Gaming")

    val filteredChannels = remember(channelsList, selectedCategory, searchQuery) {
        channelsList.filter { ch ->
            (selectedCategory == "Toutes" || ch.category == selectedCategory) &&
            (searchQuery.isBlank() || ch.name.contains(searchQuery, ignoreCase = true) || ch.handle.contains(searchQuery, ignoreCase = true))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.RssFeed, contentDescription = null, tint = NexCyan, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Chaînes & Fil d'Actualités", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showCreateChannelModal = true },
                        modifier = Modifier.testTag("create_channel_btn")
                    ) {
                        Icon(Icons.Default.AddCircle, contentDescription = "Créer une chaîne", tint = NexCyan)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // User Profile Banner in Channels
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = NexElectricBlue.copy(alpha = 0.12f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .border(2.dp, NexCyan, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (currentUser.avatarUrl.isNotBlank()) {
                            AsyncImage(
                                model = currentUser.avatarUrl,
                                contentDescription = "Photo profil",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize().clip(CircleShape)
                            )
                        } else {
                            Box(
                                modifier = Modifier.fillMaxSize().background(NexElectricBlue),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(currentUser.displayName.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(currentUser.displayName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.Default.Verified, contentDescription = null, tint = NexCyan, modifier = Modifier.size(13.dp))
                        }
                        Text(
                            text = if (currentUser.bio.isNotBlank()) currentUser.bio else "Votre profil d'abonné dans les chaînes",
                            fontSize = 11.sp,
                            maxLines = 1,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Surface(
                        color = NexCyan,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("Mon Profil", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NexDeepBlack, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
            }

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Rechercher une chaîne officielle...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            // Category Chips
            LazyRow(
                modifier = Modifier.padding(vertical = 4.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 11.sp) }
                    )
                }
            }

            // Channels List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredChannels, key = { it.id }) { channel ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedViewingChannel = channel }
                            .testTag("channel_card_${channel.id}")
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f).clickable { viewingChannelProfile = channel }
                                ) {
                                    AsyncImage(
                                        model = channel.avatarUrl,
                                        contentDescription = channel.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .border(1.dp, NexCyan, CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(channel.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            if (channel.isOfficialVerified) {
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = "Chaîne certifiée",
                                                    tint = NexCyan,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                        Text("${channel.handle} • ${channel.category}", fontSize = 11.sp, color = NexCyan)
                                    }
                                }

                                Button(
                                    onClick = {
                                        channelsList = channelsList.map {
                                            if (it.id == channel.id) {
                                                val newSub = !it.isSubscribed
                                                val countDelta = if (newSub) 1 else -1
                                                it.copy(isSubscribed = newSub, followerCount = it.followerCount + countDelta)
                                            } else it
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (channel.isSubscribed) MaterialTheme.colorScheme.surfaceVariant else NexElectricBlue
                                    ),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp).testTag("subscribe_btn_${channel.id}")
                                ) {
                                    Text(
                                        text = if (channel.isSubscribed) "Abonné ✓" else "S'abonner",
                                        fontSize = 11.sp,
                                        color = if (channel.isSubscribed) MaterialTheme.colorScheme.onSurface else Color.White
                                    )
                                }
                            }

                            Text(
                                text = channel.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            // Action to view Channel Profile
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${channel.followerCount} abonnés • Diffusions chiffrées",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                TextButton(
                                    onClick = { viewingChannelProfile = channel },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Icon(Icons.Default.AccountBox, contentDescription = null, modifier = Modifier.size(14.dp), tint = NexCyan)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Profil Chaîne", fontSize = 11.sp, color = NexCyan, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Modal 1: Channel & Creator Profile Viewer
        if (viewingChannelProfile != null) {
            val ch = viewingChannelProfile!!
            AlertDialog(
                onDismissRequest = { viewingChannelProfile = null },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccountBox, contentDescription = null, tint = NexCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Profil de la Chaîne", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    }
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AsyncImage(
                            model = ch.avatarUrl,
                            contentDescription = ch.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(84.dp)
                                .clip(CircleShape)
                                .border(3.dp, NexCyan, CircleShape)
                        )

                        Text(ch.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("${ch.handle} • ${ch.followerCount} abonnés", fontSize = 12.sp, color = NexCyan)

                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Description de la Chaîne :", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NexCyan)
                                Text(ch.description, fontSize = 12.sp)

                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                                Text("Créateur & Gestionnaire Certifié :", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NexCyan)
                                Text("${ch.creatorName} (${ch.creatorHandle})", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                Text(ch.creatorBio, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { viewingChannelProfile = null },
                        colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue)
                    ) {
                        Text("Fermer")
                    }
                }
            )
        }

        // Modal 2: Create New Channel Modal
        if (showCreateChannelModal) {
            var newName by remember { mutableStateOf("") }
            var newHandle by remember { mutableStateOf("") }
            var newDesc by remember { mutableStateOf("") }
            var newCategory by remember { mutableStateOf("Actualités") }
            var channelAvatarUrl by remember { mutableStateOf("https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300") }

            Dialog(onDismissRequest = { showCreateChannelModal = false }) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Créer une Chaîne NEXCHAT", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .align(Alignment.CenterHorizontally)
                                .clip(CircleShape)
                                .border(2.dp, NexCyan, CircleShape)
                        ) {
                            AsyncImage(
                                model = channelAvatarUrl,
                                contentDescription = "Photo chaîne",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        OutlinedTextField(
                            value = newName,
                            onValueChange = { newName = it },
                            label = { Text("Nom de la chaîne") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = newHandle,
                            onValueChange = { newHandle = if (it.startsWith("@")) it else "@$it" },
                            label = { Text("Identifiant unique (ex: @ma_chaine)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = newDesc,
                            onValueChange = { newDesc = it },
                            label = { Text("Description & Biographie de la chaîne") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            minLines = 2
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { showCreateChannelModal = false }) {
                                Text("Annuler")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (newName.isNotBlank() && newHandle.isNotBlank()) {
                                        val newChannel = ChannelData(
                                            id = "chn_${System.currentTimeMillis()}",
                                            name = newName,
                                            handle = newHandle,
                                            category = newCategory,
                                            description = newDesc,
                                            followerCount = 1,
                                            isOfficialVerified = false,
                                            isSubscribed = true,
                                            avatarUrl = channelAvatarUrl,
                                            creatorName = currentUser.displayName,
                                            creatorHandle = "@${currentUser.username}",
                                            creatorBio = currentUser.bio
                                        )
                                        channelsList = listOf(newChannel) + channelsList
                                        showCreateChannelModal = false
                                    }
                                },
                                enabled = newName.isNotBlank() && newHandle.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue)
                            ) {
                                Text("Créer", color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        // Modal 3: View Channel Feed
        if (selectedViewingChannel != null) {
            val ch = selectedViewingChannel!!
            Dialog(onDismissRequest = { selectedViewingChannel = null }) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth().fillMaxHeight(0.8f).padding(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(
                                    model = ch.avatarUrl,
                                    contentDescription = ch.name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.size(40.dp).clip(CircleShape).border(1.dp, NexCyan, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(ch.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                        if (ch.isOfficialVerified) {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NexCyan, modifier = Modifier.size(15.dp))
                                        }
                                    }
                                    Text("${ch.handle} • ${ch.followerCount} abonnés", fontSize = 11.sp, color = NexCyan)
                                }
                            }
                            IconButton(onClick = { selectedViewingChannel = null }) {
                                Icon(Icons.Default.Close, contentDescription = "Fermer")
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                        Text("Flux d'Annonces de la Chaîne :", fontWeight = FontWeight.Bold, fontSize = 12.sp)

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f).padding(top = 8.dp)
                        ) {
                            items(ch.posts) { post ->
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(post.textContent, style = MaterialTheme.typography.bodyMedium)
                                        if (post.mediaType != null) {
                                            Surface(
                                                color = NexElectricBlue.copy(alpha = 0.2f),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Row(modifier = Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.Image, contentDescription = null, tint = NexCyan, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text("Média joint (${post.mediaType})", fontSize = 11.sp, color = NexCyan)
                                                }
                                            }
                                        }
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("${post.viewsCount} vues • ${post.likesCount} réactions", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                listOf("👍", "❤️", "🔥").forEach { emoji ->
                                                    Text(emoji, fontSize = 14.sp, modifier = Modifier.clickable { })
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
