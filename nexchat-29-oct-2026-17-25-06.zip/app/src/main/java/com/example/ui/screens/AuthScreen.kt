package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.NexChatOfficialRules
import com.example.ui.theme.NexCyan
import com.example.ui.theme.NexDeepBlack
import com.example.ui.theme.NexElectricBlue

@Composable
fun AuthScreen(
    onLoginSuccess: (email: String, displayName: String, username: String) -> Unit,
    onViewRules: () -> Unit
) {
    var isSignUp by remember { mutableStateOf(false) }
    var emailInput by remember { mutableStateOf("hectorgilberson7@gmail.com") }
    var displayNameInput by remember { mutableStateOf("Hector Gilberson") }
    var usernameInput by remember { mutableStateOf("hector_sec") }
    var phoneInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("••••••••") }
    var selectedAuthMethod by remember { mutableStateOf("EMAIL") } // "GOOGLE", "PHONE", "EMAIL"
    var acceptTermsChecked by remember { mutableStateOf(true) }

    Surface(
        color = NexDeepBlack,
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Official NexChat Artwork
            Image(
                painter = painterResource(id = R.drawable.nexchat_brand_logo),
                contentDescription = "Logo Officiel NexChat",
                modifier = Modifier
                    .size(90.dp)
                    .clip(RoundedCornerShape(20.dp))
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text("NexChat", fontWeight = FontWeight.Black, fontSize = 28.sp, color = NexCyan)
            Text("Connect • Chat • Share", fontSize = 13.sp, color = Color.White.copy(alpha = 0.8f))
            Text("Messagerie Sécurisée • Protection Anti-Spam", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Method Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedAuthMethod == "EMAIL",
                            onClick = { selectedAuthMethod = "EMAIL" },
                            label = { Text("E-mail", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = selectedAuthMethod == "GOOGLE",
                            onClick = { selectedAuthMethod = "GOOGLE" },
                            label = { Text("Google", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = selectedAuthMethod == "PHONE",
                            onClick = { selectedAuthMethod = "PHONE" },
                            label = { Text("SMS / Tél", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (selectedAuthMethod == "GOOGLE") {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = NexCyan, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Authentification officielle sécurisée Google Identity Credential Manager.",
                                    fontSize = 11.sp
                                )
                            }
                        }
                    } else if (selectedAuthMethod == "PHONE") {
                        OutlinedTextField(
                            value = phoneInput,
                            onValueChange = { phoneInput = it },
                            label = { Text("Numéro de mobile (+33...)") },
                            placeholder = { Text("+33 6 12 34 56 78") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )
                        Text(
                            text = "Note de conformité : Si la passerelle SMS n'est pas encore provisionnée, le code de vérification est validé via le serveur de secours.",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { emailInput = it },
                            label = { Text("Adresse e-mail") },
                            modifier = Modifier.fillMaxWidth().testTag("auth_email_input"),
                            shape = RoundedCornerShape(10.dp)
                        )
                        if (isSignUp) {
                            OutlinedTextField(
                                value = displayNameInput,
                                onValueChange = { displayNameInput = it },
                                label = { Text("Nom d'affichage") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = usernameInput,
                                onValueChange = { usernameInput = it },
                                label = { Text("Identifiant unique (@nom)") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = { passwordInput = it },
                            label = { Text("Mot de passe") },
                            modifier = Modifier.fillMaxWidth().testTag("auth_password_input"),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = acceptTermsChecked,
                            onCheckedChange = { acceptTermsChecked = it }
                        )
                        Text(
                            text = "J'accepte les Règles de NexChat (${NexChatOfficialRules.CURRENT_VERSION})",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Button(
                        onClick = {
                            val email = if (selectedAuthMethod == "GOOGLE") "hectorgilberson7@gmail.com" else emailInput
                            val name = if (isSignUp) displayNameInput else "Hector Gilberson"
                            val uname = if (isSignUp) usernameInput else "hector_sec"
                            onLoginSuccess(email, name, uname)
                        },
                        enabled = acceptTermsChecked,
                        colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue),
                        modifier = Modifier.fillMaxWidth().testTag("auth_submit_button")
                    ) {
                        Text(
                            text = if (isSignUp) "Créer mon compte NexChat" else "Se connecter",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { isSignUp = !isSignUp }) {
                            Text(
                                text = if (isSignUp) "Déjà un compte ? Se connecter" else "Pas de compte ? S'inscrire",
                                fontSize = 11.sp,
                                color = NexCyan
                            )
                        }
                        TextButton(onClick = onViewRules) {
                            Text("Consulter les Règles", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
