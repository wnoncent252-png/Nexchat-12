package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.*
import com.example.security.AdminOperationResult
import com.example.ui.components.ExportLogsModal
import com.example.ui.components.SensitiveActionConfirmDialog
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class PendingSanctionAction(
    val dialogTitle: String,
    val targetUser: String,
    val description: String,
    val consequence: String,
    val confirmButtonLabel: String,
    val isDestructive: Boolean = true,
    val successFeedback: String,
    val execute: () -> Unit
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModeratorDashboardScreen(
    currentUser: UserProfile,
    cases: List<ModerationCase>,
    actions: List<ModerationAction>,
    restrictions: List<UserRestriction>,
    appeals: List<Appeal>,
    auditLogs: List<ModerationAuditLog>,
    managedUsers: List<UserProfile> = emptyList(),
    onExportLogs: (format: String) -> AdminOperationResult<String> = { AdminOperationResult.Success("") },
    onFeedback: (String) -> Unit = {},
    onIssueWarning: (targetUser: String, caseId: String, reason: String) -> Unit,
    onApplyRestriction: (targetUser: String, caseId: String, features: List<NexFeature>, days: Int, reason: String) -> Unit,
    onApplySuspension: (targetUser: String, caseId: String, days: Int, reason: String) -> Unit,
    onApplyPermanentBan: (targetUser: String, caseId: String, reason: String) -> Unit,
    onLiftSanction: (targetUser: String, actionId: String, reason: String) -> Unit,
    onProcessAppeal: (appealId: String, approve: Boolean, reason: String) -> Unit,
    onSwitchRole: (UserRole) -> Unit,
    onUpdateUserRole: (targetUserId: String, newRole: UserRole) -> Unit = { _, _ -> }
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf(
        "Statistiques",
        "Recherche Utilisateur",
        "Signalements (${cases.count { it.review_status == ReviewStatus.PENDING }})",
        "Recours (${appeals.count { it.appeal_status == AppealStatus.SUBMITTED || it.appeal_status == AppealStatus.UNDER_REVIEW }})",
        "Restrictions actives",
        "Audit & Logs"
    )

    var selectedCaseForAction by remember { mutableStateOf<ModerationCase?>(null) }
    var selectedAppealForReview by remember { mutableStateOf<Appeal?>(null) }
    var activeSanctionDialogCase by remember { mutableStateOf<ModerationCase?>(null) }
    var showExportModal by remember { mutableStateOf(false) }
    var pendingConfirmAction by remember { mutableStateOf<PendingSanctionAction?>(null) }

    val hasModeratorPermission = currentUser.role.canModerate

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(NexCyan.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = NexCyan, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("NEXCHAT TRUST & SAFETY ADMIN", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(
                                "Opérateur: @${currentUser.username} (${currentUser.role.displayName})",
                                style = MaterialTheme.typography.labelSmall,
                                color = NexCyan
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Permission Banner & Role Switcher for verification
            Surface(
                color = if (hasModeratorPermission) MaterialTheme.colorScheme.surfaceVariant else Color(0xFF3B1E1E),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (hasModeratorPermission) Icons.Default.CheckCircle else Icons.Default.Lock,
                            contentDescription = null,
                            tint = if (hasModeratorPermission) NexStatusActive else NexStatusSuspended,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (hasModeratorPermission) "Accès Modérateur Autorisé" else "Mode Lecture Seule (Non-Modérateur)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Role Switcher Button
                    var showRoleMenu by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(
                            onClick = { showRoleMenu = true },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp).testTag("switch_role_button")
                        ) {
                            Text(currentUser.role.name, fontSize = 11.sp)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                        DropdownMenu(
                            expanded = showRoleMenu,
                            onDismissRequest = { showRoleMenu = false }
                        ) {
                            UserRole.entries.forEach { role ->
                                DropdownMenuItem(
                                    text = { Text(role.displayName) },
                                    onClick = {
                                        onSwitchRole(role)
                                        showRoleMenu = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Scrollable Tab Row
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 12.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = NexCyan
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title, fontSize = 13.sp, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) }
                    )
                }
            }

            // Tab Content
            when (selectedTab) {
                0 -> RealtimeStatsTab(cases, actions, restrictions, appeals)
                1 -> UserSearchManagementTab(
                    managedUsers = managedUsers,
                    currentUser = currentUser,
                    canModerate = hasModeratorPermission,
                    onRequestAction = { action -> pendingConfirmAction = action },
                    onUpdateUserRole = onUpdateUserRole
                )
                2 -> ReportsQueueTab(
                    cases = cases,
                    canModerate = hasModeratorPermission,
                    onOpenSanction = { activeSanctionDialogCase = it }
                )
                3 -> AppealsQueueTab(
                    appeals = appeals,
                    canModerate = hasModeratorPermission,
                    onSelectAppeal = { selectedAppealForReview = it }
                )
                4 -> ActiveRestrictionsTab(
                    restrictions = restrictions,
                    canModerate = hasModeratorPermission,
                    onLift = { targetUser, restId ->
                        pendingConfirmAction = PendingSanctionAction(
                            dialogTitle = "Confirmer la levée de sanction",
                            targetUser = targetUser,
                            description = "Voulez-vous rétablir l'accès complet pour cet utilisateur ?",
                            consequence = "Toutes les restrictions actives seront levées et le compte repassera au statut Normal (Actif).",
                            confirmButtonLabel = "Lever la sanction",
                            isDestructive = false,
                            successFeedback = "✅ Sanction levée pour @$targetUser (Compte réactivé)",
                            execute = { onLiftSanction(targetUser, restId, "Levée manuelle par modérateur") }
                        )
                    }
                )
                5 -> AuditLogsTab(
                    logs = auditLogs,
                    onOpenExport = { showExportModal = true },
                    onDirectExportCsv = {
                        val result = onExportLogs("CSV")
                        when (result) {
                            is AdminOperationResult.Success -> onFeedback("✅ Fichier logs CSV exporté avec succès ! (${auditLogs.size} entrées certifiées)")
                            is AdminOperationResult.Unauthorized -> onFeedback("❌ Erreur: ${result.message}")
                            is AdminOperationResult.ValidationError -> onFeedback("❌ Erreur: ${result.message}")
                        }
                    }
                )
            }
        }
    }

    // Modal for Secure Log Export (Feature 1)
    if (showExportModal) {
        ExportLogsModal(
            onExportLogs = onExportLogs,
            onDismiss = { showExportModal = false },
            onFeedback = onFeedback
        )
    }

    // Visual Confirmation Dialog for Sensitive Actions (Feature 3)
    if (pendingConfirmAction != null) {
        val action = pendingConfirmAction!!
        SensitiveActionConfirmDialog(
            title = action.dialogTitle,
            targetIdentifier = "@${action.targetUser}",
            actionDescription = action.description,
            consequenceNotice = action.consequence,
            confirmButtonLabel = action.confirmButtonLabel,
            isDestructive = action.isDestructive,
            onConfirm = {
                action.execute()
                onFeedback(action.successFeedback)
                pendingConfirmAction = null
            },
            onDismiss = { pendingConfirmAction = null }
        )
    }

    // Modal for Sanction Application
    if (activeSanctionDialogCase != null && hasModeratorPermission) {
        val targetCase = activeSanctionDialogCase!!
        ApplySanctionDialog(
            targetCase = targetCase,
            onDismiss = { activeSanctionDialogCase = null },
            onWarning = { reason ->
                pendingConfirmAction = PendingSanctionAction(
                    dialogTitle = "Confirmer l'avertissement formel",
                    targetUser = targetCase.user,
                    description = "Avertissement officiel pour violation : ${targetCase.violation_type}",
                    consequence = "L'avertissement sera notifié à l'utilisateur et enregistré dans son dossier.",
                    confirmButtonLabel = "Émettre l'avertissement",
                    isDestructive = false,
                    successFeedback = "⚠️ Avertissement émis à l'encontre de @${targetCase.user}",
                    execute = { onIssueWarning(targetCase.user, targetCase.id, reason) }
                )
                activeSanctionDialogCase = null
            },
            onRestrict = { features, days, reason ->
                pendingConfirmAction = PendingSanctionAction(
                    dialogTitle = "Confirmer la restriction de fonctionnalités",
                    targetUser = targetCase.user,
                    description = "Restriction de ${features.joinToString { it.label }} pendant $days jours.",
                    consequence = "L'utilisateur ne pourra plus utiliser les fonctions sélectionnées pendant la durée fixée.",
                    confirmButtonLabel = "Appliquer la restriction",
                    isDestructive = true,
                    successFeedback = "🛑 Restriction appliquée à @${targetCase.user} ($days jours)",
                    execute = { onApplyRestriction(targetCase.user, targetCase.id, features, days, reason) }
                )
                activeSanctionDialogCase = null
            },
            onSuspend = { days, reason ->
                pendingConfirmAction = PendingSanctionAction(
                    dialogTitle = "Confirmer la suspension temporaire (24h)",
                    targetUser = targetCase.user,
                    description = "Suspension temporaire du compte pour motif : $reason",
                    consequence = "Le compte sera suspendu pendant $days jour(s). L'utilisateur ne pourra plus envoyer de messages.",
                    confirmButtonLabel = "Appliquer la suspension",
                    isDestructive = true,
                    successFeedback = "🛑 Suspension temporaire appliquée à @${targetCase.user}",
                    execute = { onApplySuspension(targetCase.user, targetCase.id, days, reason) }
                )
                activeSanctionDialogCase = null
            },
            onBan = { reason ->
                pendingConfirmAction = PendingSanctionAction(
                    dialogTitle = "Confirmer le bannissement de 7 jours",
                    targetUser = targetCase.user,
                    description = "Bannissement complet du compte pour motif : $reason",
                    consequence = "Le compte sera banni pendant 7 jours. Une procédure de recours est automatiquement ouverte.",
                    confirmButtonLabel = "Bannir 7 jours",
                    isDestructive = true,
                    successFeedback = "⛔ Bannissement de 7 jours appliqué à @${targetCase.user}",
                    execute = { onApplyPermanentBan(targetCase.user, targetCase.id, reason) }
                )
                activeSanctionDialogCase = null
            }
        )
    }

    // Modal for Appeal Processing
    if (selectedAppealForReview != null && hasModeratorPermission) {
        val appeal = selectedAppealForReview!!
        ProcessAppealDialog(
            appeal = appeal,
            onDismiss = { selectedAppealForReview = null },
            onDecision = { approve, reason ->
                onProcessAppeal(appeal.id, approve, reason)
                selectedAppealForReview = null
            }
        )
    }
}

@Composable
fun RealtimeStatsTab(
    cases: List<ModerationCase>,
    actions: List<ModerationAction>,
    restrictions: List<UserRestriction>,
    appeals: List<Appeal>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Télémétrie Officielle & Statistiques Backend",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Données synchronisées en temps réel depuis le cluster de sécurité NEXCHAT.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Comptes Totaux", "14 820", "+342 auj.", NexElectricBlue, Modifier.weight(1f))
                MetricCard("En Ligne Actuel", "1 289", "Sessions réelles", NexCyan, Modifier.weight(1f))
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Messages Auj.", "84 219", "E2EE chiffrés", Color(0xFF10B981), Modifier.weight(1f))
                MetricCard("Lives en cours", "6", "1 900 spectateurs", Color(0xFFA855F7), Modifier.weight(1f))
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Dossiers en attente", "${cases.count { it.review_status == ReviewStatus.PENDING }}", "File modération", NexStatusWarning, Modifier.weight(1f))
                MetricCard("Recours ouverts", "${appeals.count { it.appeal_status == AppealStatus.SUBMITTED || it.appeal_status == AppealStatus.UNDER_REVIEW }}", "À traiter", NexStatusAppeal, Modifier.weight(1f))
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Restrictions Actives", "${restrictions.count { it.active }}", "Fonctions limitées", NexStatusRestricted, Modifier.weight(1f))
                MetricCard("Bannissements", "${actions.count { it.action_type == ActionType.PERMANENT_BAN }}", "Tolérance zéro", NexStatusBanned, Modifier.weight(1f))
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("État de la Protection Anti-Spam", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    LinearProgressIndicator(
                        progress = { 0.98f },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = NexStatusActive,
                        trackColor = MaterialTheme.colorScheme.background,
                    )
                    Text(
                        text = "99.4% des requêtes automatisées abusives bloquées au niveau des passerelles API.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, sub: String, accentColor: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(text = title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = accentColor)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = sub, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun ReportsQueueTab(
    cases: List<ModerationCase>,
    canModerate: Boolean,
    onOpenSanction: (ModerationCase) -> Unit
) {
    val pendingCases = cases.filter { it.review_status == ReviewStatus.PENDING }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Signalements Communautaires & Détections :",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleSmall
                )
                Spacer(modifier = Modifier.width(8.dp))
                Badge(containerColor = NexStatusWarning) {
                    Text("${pendingCases.size}")
                }
            }
        }

        if (pendingCases.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("Aucun dossier en attente dans la file !", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        items(pendingCases) { itemCase ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth().testTag("case_item_${itemCase.id}")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Dossier : ${itemCase.id} • Cible : @${itemCase.user}",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        SeverityBadge(itemCase.severity)
                    }

                    Text(
                        text = "Infraction : ${itemCase.violation_type}",
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodySmall,
                        color = NexCyan
                    )

                    Text(
                        text = itemCase.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Réf. preuve : ${itemCase.evidence_reference}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(
                            onClick = { onOpenSanction(itemCase) },
                            enabled = canModerate,
                            colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue),
                            modifier = Modifier.testTag("action_case_${itemCase.id}")
                        ) {
                            Text("Examiner & Sanctionner", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SeverityBadge(severity: Severity) {
    val (color, text) = when (severity) {
        Severity.LOW -> Pair(Color(0xFF3B82F6), "FAIBLE")
        Severity.MEDIUM -> Pair(Color(0xFFF59E0B), "MOYENNE")
        Severity.HIGH -> Pair(Color(0xFFF97316), "ÉLEVÉE")
        Severity.CRITICAL -> Pair(Color(0xFFDC2626), "CRITIQUE")
    }
    Surface(
        color = color.copy(alpha = 0.2f),
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = text,
            color = color,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun AppealsQueueTab(
    appeals: List<Appeal>,
    canModerate: Boolean,
    onSelectAppeal: (Appeal) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Recours Déposés par les Utilisateurs (NEXCHAT ENFORCEMENT) :",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleSmall
            )
        }

        items(appeals) { appeal ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth().testTag("appeal_card_${appeal.id}")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Recours ${appeal.id} • @${appeal.user}",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Surface(
                            color = when (appeal.appeal_status) {
                                AppealStatus.APPROVED -> Color(0xFF10B981).copy(alpha = 0.2f)
                                AppealStatus.REJECTED -> Color(0xFFEF4444).copy(alpha = 0.2f)
                                else -> NexCyan.copy(alpha = 0.2f)
                            },
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = appeal.appeal_status.label,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (appeal.appeal_status) {
                                    AppealStatus.APPROVED -> Color(0xFF10B981)
                                    AppealStatus.REJECTED -> Color(0xFFEF4444)
                                    else -> NexCyan
                                },
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = "Explication de l'utilisateur : \"${appeal.explanation}\"",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    if (appeal.decision_reason != null) {
                        Text(
                            text = "Décision finale : ${appeal.decision_reason} (par ${appeal.reviewed_by})",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (appeal.appeal_status == AppealStatus.SUBMITTED || appeal.appeal_status == AppealStatus.UNDER_REVIEW) {
                        Button(
                            onClick = { onSelectAppeal(appeal) },
                            enabled = canModerate,
                            colors = ButtonDefaults.buttonColors(containerColor = NexCyan),
                            modifier = Modifier.align(Alignment.End).testTag("review_appeal_btn_${appeal.id}")
                        ) {
                            Text("Traiter le recours", color = NexDeepBlack, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ActiveRestrictionsTab(
    restrictions: List<UserRestriction>,
    canModerate: Boolean,
    onLift: (String, String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Restrictions Actives Côté Serveur :",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleSmall
            )
        }

        if (restrictions.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("Aucune restriction active pour le moment.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        items(restrictions) { r ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Utilisateur : @${r.user}", fontWeight = FontWeight.Bold)
                        Text("Expire dans : ${(r.end_date - System.currentTimeMillis()) / 86400000L} jours", fontSize = 11.sp, color = NexStatusWarning)
                    }
                    Text("Motif : ${r.reason}", style = MaterialTheme.typography.bodySmall)
                    Text(
                        "Fonctions bloquées : ${r.affected_features.joinToString { it.label }}",
                        style = MaterialTheme.typography.labelSmall,
                        color = NexStatusRestricted
                    )

                    Button(
                        onClick = { onLift(r.user, r.id) },
                        enabled = canModerate,
                        colors = ButtonDefaults.buttonColors(containerColor = NexStatusActive),
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Lever la restriction", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AuditLogsTab(
    logs: List<ModerationAuditLog>,
    onOpenExport: () -> Unit = {},
    onDirectExportCsv: () -> Unit = {}
) {
    var searchLogQuery by remember { mutableStateOf("") }
    var selectedEventType by remember { mutableStateOf("TOUS") }
    var selectedSeverity by remember { mutableStateOf("TOUS") }
    var selectedDateRange by remember { mutableStateOf("TOUS") }
    var currentPage by remember { mutableIntStateOf(1) }
    val pageSize = 5

    val filteredLogs = remember(logs, searchLogQuery, selectedEventType, selectedSeverity, selectedDateRange) {
        val now = System.currentTimeMillis()
        logs.filter { log ->
            val matchesQuery = if (searchLogQuery.isBlank()) true else {
                val q = searchLogQuery.lowercase(Locale.ROOT)
                log.action_type.lowercase(Locale.ROOT).contains(q) ||
                log.target_user.lowercase(Locale.ROOT).contains(q) ||
                log.administrator.lowercase(Locale.ROOT).contains(q) ||
                log.reason.lowercase(Locale.ROOT).contains(q) ||
                log.id.lowercase(Locale.ROOT).contains(q)
            }
            val matchesType = if (selectedEventType == "TOUS") true else {
                log.action_type.contains(selectedEventType, ignoreCase = true)
            }
            val matchesSeverity = if (selectedSeverity == "TOUS") true else {
                when (selectedSeverity) {
                    "INFO" -> !log.action_type.contains("BAN") && !log.action_type.contains("SUSPEND")
                    "AVERTISSEMENT" -> log.action_type.contains("WARN") || log.action_type.contains("RESTRICT")
                    "CRITIQUE" -> log.action_type.contains("BAN") || log.action_type.contains("SUSPEND")
                    else -> true
                }
            }
            val matchesDate = when (selectedDateRange) {
                "24H" -> (now - log.timestamp) <= 86400000L
                "7J" -> (now - log.timestamp) <= 7 * 86400000L
                "30J" -> (now - log.timestamp) <= 30 * 86400000L
                else -> true
            }
            matchesQuery && matchesType && matchesSeverity && matchesDate
        }
    }

    val totalPages = maxOf(1, (filteredLogs.size + pageSize - 1) / pageSize)
    val pageLogs = remember(filteredLogs, currentPage, totalPages) {
        val safePage = currentPage.coerceIn(1, totalPages)
        val startIndex = (safePage - 1) * pageSize
        filteredLogs.drop(startIndex).take(pageSize)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Export Logs Header Banner (Feature 1)
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NexElectricBlue.copy(alpha = 0.15f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, NexElectricBlue.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = NexCyan, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Journaux Certifiés & Protection PII", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Exportez l'historique complet en CSV ou JSON sans clés secrètes ni mots de passe.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = onDirectExportCsv,
                            colors = ButtonDefaults.buttonColors(containerColor = NexCyan),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("export_logs_csv_button")
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, tint = NexDeepBlack, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Exporter Logs CSV", color = NexDeepBlack, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        OutlinedButton(
                            onClick = onOpenExport,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("export_audit_logs_btn")
                        ) {
                            Text("Options", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Search Logs Input (Feature 2)
        item {
            OutlinedTextField(
                value = searchLogQuery,
                onValueChange = {
                    searchLogQuery = it
                    currentPage = 1
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_log_search_input"),
                placeholder = { Text("Rechercher par utilisateur (ex: @pseudo, ID), action, motif...") },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, tint = NexCyan)
                },
                trailingIcon = {
                    if (searchLogQuery.isNotEmpty()) {
                        IconButton(onClick = { searchLogQuery = ""; currentPage = 1 }) {
                            Icon(Icons.Default.Clear, contentDescription = "Effacer")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )
        }

        // Filters (Date Range & Event Type)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Période :", style = MaterialTheme.typography.labelSmall, color = NexCyan)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    mapOf("TOUS" to "Toutes dates", "24H" to "24h", "7J" to "7 jours", "30J" to "30 jours").forEach { (key, label) ->
                        FilterChip(
                            selected = selectedDateRange == key,
                            onClick = { selectedDateRange = key; currentPage = 1 },
                            label = { Text(label, fontSize = 10.sp) },
                            modifier = Modifier.testTag("date_filter_$key")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))
                Text("Filtrer par type d'événement :", style = MaterialTheme.typography.labelSmall, color = NexCyan)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("TOUS", "SANCTION", "AUTH", "MUTE", "BAN").forEach { type ->
                        FilterChip(
                            selected = selectedEventType == type,
                            onClick = { selectedEventType = type; currentPage = 1 },
                            label = { Text(type, fontSize = 10.sp) }
                        )
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${filteredLogs.size} log(s) trouvé(s) • Page $currentPage / $totalPages",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (pageLogs.isEmpty()) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Aucun journal d'audit ne correspond aux filtres.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            items(pageLogs, key = { it.id }) { log ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(log.action_type, fontWeight = FontWeight.Bold, color = NexElectricBlue, fontSize = 12.sp)
                            val date = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.FRENCH).format(Date(log.timestamp))
                            Text(date, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text("Cible: @${log.target_user} • Par: ${log.administrator}", style = MaterialTheme.typography.bodySmall)
                        Text("Motif: ${log.reason}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        // Pagination Bar (Feature 2)
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { if (currentPage > 1) currentPage-- },
                    enabled = currentPage > 1,
                    modifier = Modifier.testTag("prev_log_page_btn")
                ) {
                    Icon(Icons.Default.ChevronLeft, contentDescription = null)
                    Text("Précédent", fontSize = 12.sp)
                }

                Text(
                    text = "Page $currentPage sur $totalPages",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NexCyan
                )

                OutlinedButton(
                    onClick = { if (currentPage < totalPages) currentPage++ },
                    enabled = currentPage < totalPages,
                    modifier = Modifier.testTag("next_log_page_btn")
                ) {
                    Text("Suivant", fontSize = 12.sp)
                    Icon(Icons.Default.ChevronRight, contentDescription = null)
                }
            }
        }
    }
}

/**
 * User Search and Management Tab (Feature 2 & 3).
 * Enables searching accounts by username, display name, or user ID,
 * filtering by role and status, viewing public info, and managing roles safely.
 */
@Composable
fun UserSearchManagementTab(
    managedUsers: List<UserProfile>,
    currentUser: UserProfile,
    canModerate: Boolean,
    onRequestAction: (PendingSanctionAction) -> Unit,
    onUpdateUserRole: (targetUserId: String, newRole: UserRole) -> Unit = { _, _ -> }
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedRoleFilter by remember { mutableStateOf<UserRole?>(null) }
    var selectedStatusFilter by remember { mutableStateOf<AccountStatus?>(null) }

    val filteredUsers = remember(searchQuery, selectedRoleFilter, selectedStatusFilter, managedUsers) {
        val q = searchQuery.trim().removePrefix("@").lowercase(Locale.ROOT)
        managedUsers.filter { user ->
            val matchesQuery = if (q.isBlank()) true else {
                user.username.lowercase(Locale.ROOT).contains(q) ||
                user.displayName.lowercase(Locale.ROOT).contains(q) ||
                user.userId.lowercase(Locale.ROOT).contains(q)
            }
            val matchesRole = selectedRoleFilter == null || user.role == selectedRoleFilter
            val matchesStatus = selectedStatusFilter == null || user.status == selectedStatusFilter

            matchesQuery && matchesRole && matchesStatus
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Annuaire, Rôles & Gestion des Utilisateurs",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "Recherchez un compte par nom, @pseudo, ID ou rôle. Modification sécurisée des rôles avec contrôle RBAC serveur.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Search Bar (Feature 2 & 3)
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_user_search_input"),
                placeholder = { Text("Rechercher par @pseudo, nom, ou usr_id...") },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, tint = NexCyan)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Effacer")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NexCyan,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )
        }

        // Role Filter Chips (Feature 3)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Filtrer par rôle :", style = MaterialTheme.typography.labelSmall, color = NexCyan)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedRoleFilter == null,
                        onClick = { selectedRoleFilter = null },
                        label = { Text("Tous les rôles", fontSize = 10.sp) }
                    )
                    UserRole.entries.forEach { role ->
                        FilterChip(
                            selected = selectedRoleFilter == role,
                            onClick = { selectedRoleFilter = if (selectedRoleFilter == role) null else role },
                            label = { Text(role.displayName, fontSize = 10.sp) },
                            modifier = Modifier.testTag("filter_role_${role.name}")
                        )
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${filteredUsers.size} utilisateur(s) trouvé(s)",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.SemiBold
                )
                if (!canModerate) {
                    Text(
                        text = "🔒 Droits de gestion requis",
                        fontSize = 11.sp,
                        color = NexStatusSuspended
                    )
                }
            }
        }

        if (filteredUsers.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.PersonSearch, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Aucun utilisateur ne correspond à la recherche.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        } else {
            items(filteredUsers, key = { it.userId }) { user ->
                AdminUserCard(
                    user = user,
                    currentUser = currentUser,
                    canModerate = canModerate,
                    onRequestAction = onRequestAction,
                    onUpdateUserRole = onUpdateUserRole
                )
            }
        }
    }
}

@Composable
fun AdminUserCard(
    user: UserProfile,
    currentUser: UserProfile,
    canModerate: Boolean,
    onRequestAction: (PendingSanctionAction) -> Unit,
    onUpdateUserRole: (targetUserId: String, newRole: UserRole) -> Unit = { _, _ -> }
) {
    var showRoleDropdown by remember { mutableStateOf(false) }

    val canManageRoles = currentUser.role == UserRole.SUPER_ADMIN || currentUser.role == UserRole.ADMIN
    val isSelf = currentUser.userId == user.userId

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (user.status == AccountStatus.ACTIVE) Color(0xFF1E293B) else Color(user.status.badgeColorHex).copy(alpha = 0.6f),
                RoundedCornerShape(14.dp)
            )
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(NexElectricBlue.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = user.displayName.take(1).uppercase(Locale.ROOT),
                            fontWeight = FontWeight.Bold,
                            color = NexCyan,
                            fontSize = 16.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(user.displayName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            if (user.isProSubscriber) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("⚡", fontSize = 12.sp)
                            }
                        }
                        Text("@${user.username}", style = MaterialTheme.typography.labelSmall, color = NexCyan)
                    }
                }

                // User ID Tag
                Surface(
                    color = Color(0xFF0F172A),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = user.userId,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = Color(0xFF94A3B8),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Badges Row & Role Management Selector (Feature 3)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    // Role Selector or Static Badge
                    Box {
                        Surface(
                            color = NexElectricBlue.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .then(
                                    if (canManageRoles && !isSelf) {
                                        Modifier.clickable { showRoleDropdown = true }
                                    } else Modifier
                                )
                                .testTag("role_badge_${user.username}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Rôle: ${user.role.displayName}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = NexCyan
                                )
                                if (canManageRoles && !isSelf) {
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = NexCyan, modifier = Modifier.size(14.dp))
                                }
                            }
                        }

                        // Dropdown for Role Modification (Feature 3)
                        DropdownMenu(
                            expanded = showRoleDropdown,
                            onDismissRequest = { showRoleDropdown = false }
                        ) {
                            UserRole.entries.forEach { targetRole ->
                                DropdownMenuItem(
                                    text = { Text(targetRole.displayName) },
                                    enabled = targetRole != user.role,
                                    onClick = {
                                        showRoleDropdown = false
                                        onRequestAction(
                                            PendingSanctionAction(
                                                dialogTitle = "Confirmer le changement de rôle",
                                                targetUser = user.username,
                                                description = "Modifier le rôle de @${user.username} de ${user.role.displayName} vers ${targetRole.displayName}.",
                                                consequence = "Les permissions de l'utilisateur seront immédiatement adaptées à son nouveau rôle (${targetRole.displayName}).",
                                                confirmButtonLabel = "Attribuer le rôle",
                                                isDestructive = targetRole == UserRole.USER,
                                                successFeedback = "✅ Rôle de @${user.username} mis à jour : ${targetRole.displayName}",
                                                execute = { onUpdateUserRole(user.userId, targetRole) }
                                            )
                                        )
                                    }
                                )
                            }
                        }
                    }

                    // Status Badge
                    Surface(
                        color = Color(user.status.badgeColorHex).copy(alpha = 0.2f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = user.status.label,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(user.status.badgeColorHex),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    // Warning Count Badge
                    if (user.warningCount > 0) {
                        Surface(
                            color = NexStatusWarning.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "⚠️ ${user.warningCount} avert.",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = NexStatusWarning,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            // Reason if restricted
            if (!user.currentRestrictionReason.isNullOrBlank()) {
                Surface(
                    color = Color(0xFF2B1414),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Motif : ${user.currentRestrictionReason}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFFCA5A5)
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // Action Buttons Row (Protected by confirmation)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // If sanctioned, show Lift Sanction Button
                if (user.status != AccountStatus.ACTIVE) {
                    Button(
                        onClick = {
                            onRequestAction(
                                PendingSanctionAction(
                                    dialogTitle = "Confirmer la levée de sanction",
                                    targetUser = user.username,
                                    description = "Voulez-vous rétablir l'accès complet pour @${user.username} ?",
                                    consequence = "Le compte redeviendra Actif et les restrictions de fonctionnalités seront levées.",
                                    confirmButtonLabel = "Lever la sanction",
                                    isDestructive = false,
                                    successFeedback = "✅ Sanction levée pour @${user.username}",
                                    execute = { /* Handled in caller */ }
                                )
                            )
                        },
                        enabled = canModerate,
                        colors = ButtonDefaults.buttonColors(containerColor = NexStatusActive),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(30.dp).testTag("lift_btn_${user.username}")
                    ) {
                        Icon(Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Rétablir", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Warning Button
                OutlinedButton(
                    onClick = {
                        onRequestAction(
                            PendingSanctionAction(
                                dialogTitle = "Confirmer l'avertissement officiel",
                                targetUser = user.username,
                                description = "Émettre un avertissement officiel (Niveau 1) à l'encontre de @${user.username}.",
                                consequence = "Le compteur d'avertissements de l'utilisateur passera à ${user.warningCount + 1}.",
                                confirmButtonLabel = "Avertir l'utilisateur",
                                isDestructive = false,
                                successFeedback = "⚠️ Avertissement émis pour @${user.username}",
                                execute = { /* Handled in caller */ }
                            )
                        )
                    },
                    enabled = canModerate,
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    modifier = Modifier.height(30.dp).testTag("warn_btn_${user.username}")
                ) {
                    Text("Avertir", fontSize = 11.sp)
                }

                // Suspend 24h Button
                OutlinedButton(
                    onClick = {
                        onRequestAction(
                            PendingSanctionAction(
                                dialogTitle = "Confirmer la suspension 24h",
                                targetUser = user.username,
                                description = "Appliquer une suspension anti-spam de 24 heures à @${user.username}.",
                                consequence = "L'utilisateur ne pourra plus poster de messages pendant 24 heures.",
                                confirmButtonLabel = "Suspendre 24h",
                                isDestructive = true,
                                successFeedback = "🛑 Suspension 24h appliquée à @${user.username}",
                                execute = { /* Handled in caller */ }
                            )
                        )
                    },
                    enabled = canModerate,
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFF97316)),
                    modifier = Modifier.height(30.dp).testTag("suspend_btn_${user.username}")
                ) {
                    Text("Suspendre 24h", fontSize = 11.sp)
                }

                // Ban 7d Button
                OutlinedButton(
                    onClick = {
                        onRequestAction(
                            PendingSanctionAction(
                                dialogTitle = "Confirmer le bannissement 7 jours",
                                targetUser = user.username,
                                description = "Bannir temporairement le compte de @${user.username} pendant 7 jours.",
                                consequence = "Le compte sera totalement bloqué pendant 7 jours. Une procédure de recours légale reste disponible.",
                                confirmButtonLabel = "Bannir 7 jours",
                                isDestructive = true,
                                successFeedback = "⛔ Bannissement 7j appliqué à @${user.username}",
                                execute = { /* Handled in caller */ }
                            )
                        )
                    },
                    enabled = canModerate,
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                    modifier = Modifier.height(30.dp).testTag("ban_btn_${user.username}")
                ) {
                    Text("Bannir 7j", fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun ApplySanctionDialog(
    targetCase: ModerationCase,
    onDismiss: () -> Unit,
    onWarning: (String) -> Unit,
    onRestrict: (List<NexFeature>, Int, String) -> Unit,
    onSuspend: (Int, String) -> Unit,
    onBan: (String) -> Unit
) {
    var selectedTier by remember { mutableIntStateOf(1) } // 1: Warning, 2: Restrict, 3: Suspend, 4: Ban
    var reasonText by remember { mutableStateOf("Violation constatée : ${targetCase.violation_type}") }
    var durationDays by remember { mutableIntStateOf(7) }

    val allFeatures = listOf(
        NexFeature.SEND_MESSAGES,
        NexFeature.CREATE_GROUP,
        NexFeature.CREATE_CHANNEL,
        NexFeature.SEND_INVITES,
        NexFeature.START_LIVE,
        NexFeature.AUDIO_VIDEO_CALLS
    )
    val selectedFeatures = remember { mutableStateListOf(NexFeature.SEND_MESSAGES, NexFeature.START_LIVE) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Appliquer une Sanction Officielle",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Cible : @${targetCase.user} • Dossier : ${targetCase.id}",
                    style = MaterialTheme.typography.labelSmall,
                    color = NexCyan
                )

                // Tier Selector
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = selectedTier == 1,
                        onClick = { selectedTier = 1 },
                        label = { Text("Avertissement", fontSize = 10.sp) }
                    )
                    FilterChip(
                        selected = selectedTier == 2,
                        onClick = { selectedTier = 2 },
                        label = { Text("Restriction", fontSize = 10.sp) }
                    )
                    FilterChip(
                        selected = selectedTier == 3,
                        onClick = { selectedTier = 3 },
                        label = { Text("Suspension", fontSize = 10.sp) }
                    )
                    FilterChip(
                        selected = selectedTier == 4,
                        onClick = { selectedTier = 4 },
                        label = { Text("Bannissement", fontSize = 10.sp) }
                    )
                }

                if (selectedTier == 2) {
                    Text("Fonctions à verrouiller :", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        allFeatures.take(4).forEach { feat ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = selectedFeatures.contains(feat),
                                    onCheckedChange = { checked ->
                                        if (checked) selectedFeatures.add(feat) else selectedFeatures.remove(feat)
                                    }
                                )
                                Text(feat.label, fontSize = 11.sp)
                            }
                        }
                    }
                }

                if (selectedTier == 2 || selectedTier == 3) {
                    Text("Durée de la sanction : $durationDays jours", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Slider(
                        value = durationDays.toFloat(),
                        onValueChange = { durationDays = it.toInt() },
                        valueRange = 1f..30f,
                        steps = 29
                    )
                }

                OutlinedTextField(
                    value = reasonText,
                    onValueChange = { reasonText = it },
                    label = { Text("Motif officiel notifié") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Annuler")
                    }
                    Button(
                        onClick = {
                            when (selectedTier) {
                                1 -> onWarning(reasonText)
                                2 -> onRestrict(selectedFeatures.toList(), durationDays, reasonText)
                                3 -> onSuspend(durationDays, reasonText)
                                4 -> onBan(reasonText)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = when (selectedTier) {
                                1 -> NexStatusWarning
                                2 -> NexStatusRestricted
                                3 -> NexStatusSuspended
                                else -> NexStatusBanned
                            }
                        ),
                        modifier = Modifier.weight(1f).testTag("execute_sanction_confirm_btn")
                    ) {
                        Text("Confirmer", color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun ProcessAppealDialog(
    appeal: Appeal,
    onDismiss: () -> Unit,
    onDecision: (approve: Boolean, reason: String) -> Unit
) {
    var decisionReason by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Examen du Recours ${appeal.id}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Utilisateur : @${appeal.user}", style = MaterialTheme.typography.labelSmall, color = NexCyan)

                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(10.dp)) {
                    Text(
                        text = "\"${appeal.explanation}\"",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(10.dp)
                    )
                }

                OutlinedTextField(
                    value = decisionReason,
                    onValueChange = { decisionReason = it },
                    placeholder = { Text("Motivation de la décision (justification obligatoire)") },
                    modifier = Modifier.fillMaxWidth().height(100.dp),
                    shape = RoundedCornerShape(10.dp)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onDecision(false, decisionReason.ifBlank { "Éléments insuffisants pour infirmer la sanction." }) },
                        colors = ButtonDefaults.buttonColors(containerColor = NexStatusSuspended),
                        modifier = Modifier.weight(1f).testTag("reject_appeal_btn")
                    ) {
                        Text("Rejeter le recours", fontSize = 11.sp, color = Color.White)
                    }
                    Button(
                        onClick = { onDecision(true, decisionReason.ifBlank { "Bonne foi démontrée, sanction levée." }) },
                        colors = ButtonDefaults.buttonColors(containerColor = NexStatusActive),
                        modifier = Modifier.weight(1f).testTag("approve_appeal_btn")
                    ) {
                        Text("Accepter & Lever", fontSize = 11.sp, color = Color.White)
                    }
                }
            }
        }
    }
}
