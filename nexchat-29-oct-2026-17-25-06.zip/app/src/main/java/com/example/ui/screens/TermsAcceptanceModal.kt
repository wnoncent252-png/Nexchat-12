package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.NexChatOfficialRules
import com.example.ui.theme.NexCyan
import com.example.ui.theme.NexElectricBlue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TermsAcceptanceModal(
    userId: String,
    onAccept: () -> Unit,
    onDismiss: () -> Unit
) {
    var hasAgreedToRules by remember { mutableStateOf(false) }
    var hasAgreedToSafetyTerms by remember { mutableStateOf(false) }

    val formattedDate = remember {
        SimpleDateFormat("dd MMMM yyyy HH:mm", Locale.FRENCH).format(Date())
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(24.dp)),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
            ) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(NexElectricBlue.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Sécurité",
                            tint = NexCyan,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Règles & Conditions d'Utilisation",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "NEXCHAT Trust & Safety ${NexChatOfficialRules.CURRENT_VERSION}",
                            style = MaterialTheme.typography.bodySmall,
                            color = NexCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Metadata Registration Box
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "Enregistrement légal d'acceptation :",
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.labelMedium,
                            color = NexElectricBlue
                        )
                        Text(
                            text = "• Identifiant utilisateur : $userId",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "• Version des règles : ${NexChatOfficialRules.CURRENT_VERSION}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "• Horodatage d'acceptation : $formattedDate",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "• Dernière mise à jour officielle : ${NexChatOfficialRules.LAST_UPDATED_DATE}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable Summary of 14 Rules
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.background.copy(alpha = 0.5f))
                        .padding(12.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Engagement officiel de l'utilisateur :",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "En utilisant NEXCHAT, vous vous engagez à respecter strictement l'intégrité de la plateforme. Toute infraction aux 14 règles fondamentales fait l'objet de sanctions côté serveur (avertissement, restriction de fonctionnalités, suspension temporaire, ou bannissement définitif).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                        NexChatOfficialRules.rulesList.forEach { rule ->
                            Row(
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "${rule.articleNumber}.",
                                    fontWeight = FontWeight.Bold,
                                    color = NexElectricBlue,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Column {
                                    Text(
                                        text = rule.title,
                                        fontWeight = FontWeight.SemiBold,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = rule.summary,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Explicit Checkboxes
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Checkbox(
                        checked = hasAgreedToRules,
                        onCheckedChange = { hasAgreedToRules = it },
                        modifier = Modifier.testTag("checkbox_accept_rules")
                    )
                    Text(
                        text = "J'ai lu et j'accepte les 14 règles de NEXCHAT (v2.4.1).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Checkbox(
                        checked = hasAgreedToSafetyTerms,
                        onCheckedChange = { hasAgreedToSafetyTerms = it },
                        modifier = Modifier.testTag("checkbox_accept_safety")
                    )
                    Text(
                        text = "Je consens à la modération équitable et aux conditions d'utilisation.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f).testTag("cancel_terms_button")
                    ) {
                        Text("Plus tard")
                    }
                    Button(
                        onClick = onAccept,
                        enabled = hasAgreedToRules && hasAgreedToSafetyTerms,
                        colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue),
                        modifier = Modifier.weight(1f).testTag("accept_terms_button")
                    ) {
                        Text("Confirmer", color = Color.White)
                    }
                }
            }
        }
    }
}
