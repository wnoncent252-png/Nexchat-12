package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = NexElectricBlueBright,
    onPrimary = Color.White,
    primaryContainer = NexElectricBlue,
    onPrimaryContainer = Color.White,
    secondary = NexCyan,
    onSecondary = NexDeepBlack,
    secondaryContainer = Color(0xFF003830),
    onSecondaryContainer = NexCyanBright,
    tertiary = Color(0xFFA78BFA),
    onTertiary = Color.White,
    background = NexDeepBlack,
    onBackground = NexOnDark,
    surface = NexDarkSurface,
    onSurface = NexOnDark,
    surfaceVariant = NexDarkCard,
    onSurfaceVariant = NexOnDarkSecondary,
    outline = NexDarkCardBorder,
    error = NexStatusSuspended,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = NexElectricBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E4FF),
    onPrimaryContainer = Color(0xFF001C53),
    secondary = Color(0xFF00897B),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFB2DFDB),
    onSecondaryContainer = Color(0xFF004D40),
    tertiary = Color(0xFF6D28D9),
    onTertiary = Color.White,
    background = NexLightBackground,
    onBackground = NexOnLight,
    surface = NexLightSurface,
    onSurface = NexOnLight,
    surfaceVariant = NexLightCard,
    onSurfaceVariant = NexOnLightSecondary,
    outline = NexLightCardBorder,
    error = NexStatusSuspended,
    onError = Color.White
)

@Composable
fun NexChatTheme(
    darkTheme: Boolean = true, // Default to sleek deep black / electric blue theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
