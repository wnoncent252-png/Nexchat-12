package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AccountStatus
import com.example.model.ModerationAction
import com.example.model.UserProfile
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountStatusDetailScreen(
    user: UserProfile,
    actionHistory: List<ModerationAction>,
    onBack: () -> Unit,
    onOpenAppeal: () -> Unit
) {
    // Dynamic countdown timer updated every second
    var currentTime by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000L)
            currentTime = System.currentTimeMillis()
        }
    }

    val remainingMillis = user.restrictionEndDate?.let { (it - currentTime).coerceAtLeast(0L) } ?: 0L
    val hoursRemaining = remainingMillis / 3600000L
    val minutesRemaining = (remainingMillis % 3600000L) / 60000L
    val secondsRemaining = (remainingMillis % 60000L) / 1000L

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("État de mon compte", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Primary Status Card
                val (color, icon, badgeLabel) = when (user.status) {
                    AccountStatus.ACTIVE -> Triple(NexStatusActive, Icons.Default.CheckCircle, "NORMAL (ACTIF)")
                    AccountStatus.WARNING -> Triple(NexStatusWarning, Icons.Default.Warning, "AVERTISSEMENT")
                    AccountStatus.RESTRICTED -> Triple(NexStatusRestricted, Icons.Default.Block, "RESTRICTION ACTIVE")
                    AccountStatus.TEMPORARILY_SUSPENDED -> Triple(NexStatusSuspended, Icons.Default.PauseCircle, "SUSPENSION ANTI-SPAM 24H")
                    AccountStatus.PERMANENTLY_BANNED -> Triple(NexStatusBanned, Icons.Default.Cancel, "BANNISSEMENT 7 JOURS")
                    AccountStatus.APPEAL_PENDING -> Triple(NexCyan, Icons.Default.HourglassTop, "RECOURS EN EXAMEN")
                    AccountStatus.UNDER_REVIEW -> Triple(NexStatusReview, Icons.Default.Search, "EN RÉVISION")
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.15f)),
                    modifier = Modifier.fillMaxWidth().testTag("account_status_detail_card")
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(color.copy(alpha = 0.25f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(28.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Surface(
                                    color = color,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = badgeLabel,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("Compte: @${user.username}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            }
                        }

                        HorizontalDivider(color = color.copy(alpha = 0.3f))

                        // Details of Sanction
                        if (user.status != AccountStatus.ACTIVE) {
                            Text(
                                text = "Motif notifié par le serveur :",
                                fontWeight = FontWeight.SemiBold,
                                style = MaterialTheme.typography.labelMedium
                            )
                            Surface(
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = user.currentRestrictionReason ?: "Sanction automatique anti-spam / modération.",
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(12.dp),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            // Dates
                            if (user.restrictionStartDate != null) {
                                val startStr = SimpleDateFormat("dd/MM/yyyy 'à' HH:mm:ss", Locale.FRENCH).format(Date(user.restrictionStartDate))
                                Text("• Date de début : $startStr", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            if (user.restrictionEndDate != null) {
                                val endStr = SimpleDateFormat("dd/MM/yyyy 'à' HH:mm:ss", Locale.FRENCH).format(Date(user.restrictionEndDate))
                                Text("• Date de fin programmée : $endStr", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                                // Dynamic Live Countdown Box
                                Surface(
                                    color = NexDeepBlack,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "COMPTE À REBOURS AVANT RÉACTIVATION AUTOMATIQUE",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = NexCyan
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = String.format("%02dh %02dm %02ds", hoursRemaining, minutesRemaining, secondsRemaining),
                                            fontSize = 24.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color.White
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Le serveur rétablira automatiquement vos accès à l'expiration.",
                                            fontSize = 10.sp,
                                            color = Color.White.copy(alpha = 0.7f)
                                        )
                                    }
                                }
                            }

                            // Appeal Button
                            Button(
                                onClick = onOpenAppeal,
                                colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue),
                                modifier = Modifier.fillMaxWidth().testTag("contest_sanction_button")
                            ) {
                                Icon(Icons.Default.Gavel, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Contester cette décision (Recours)", color = Color.White)
                            }
                        } else {
                            Text(
                                text = "Votre compte est en règle. Toutes les fonctionnalités de communication, publication, diffusion et personnalisation sont accessibles.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Rights & Protections Guarantee
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Garanties NexChat Trust & Safety", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "• Un compte suspendu n'est jamais supprimé automatiquement.\n• Les fonctions non concernées (consultation des paramètres, téléchargement des données, recours) restent ouvertes.\n• Tout examen de recours est traité de manière impartiale sous 48h.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Sanction History
            item {
                Text(
                    text = "Historique des Sanctions & Décisions :",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleSmall
                )
            }

            items(actionHistory) { act ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(act.action_type.label, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = NexElectricBlue)
                            Text(SimpleDateFormat("dd/MM/yyyy", Locale.FRENCH).format(Date(act.created_at)), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(act.reason, style = MaterialTheme.typography.bodySmall)
                        Text("Émis par : ${act.issued_by}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
