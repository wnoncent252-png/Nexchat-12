package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NexChat Official Palette: Electric Blue, Cyan & Deep Black
val NexElectricBlue = Color(0xFF0066FF)
val NexElectricBlueBright = Color(0xFF388BFF)
val NexCyan = Color(0xFF00F5D4)
val NexCyanBright = Color(0xFF5CFFE7)
val NexDeepBlack = Color(0xFF0A0E17)
val NexDarkSurface = Color(0xFF111827)
val NexDarkCard = Color(0xFF1B2234)
val NexDarkCardBorder = Color(0xFF2B354C)
val NexOnDark = Color(0xFFF1F5F9)
val NexOnDarkSecondary = Color(0xFF94A3B8)

val NexLightBackground = Color(0xFFF8FAFC)
val NexLightSurface = Color(0xFFFFFFFF)
val NexLightCard = Color(0xFFF1F5F9)
val NexLightCardBorder = Color(0xFFCBD5E1)
val NexOnLight = Color(0xFF0F172A)
val NexOnLightSecondary = Color(0xFF64748B)

// Status & Enforcement Colors
val NexStatusActive = Color(0xFF10B981)
val NexStatusWarning = Color(0xFFF59E0B)
val NexStatusRestricted = Color(0xFFF97316)
val NexStatusSuspended = Color(0xFFEF4444)
val NexStatusBanned = Color(0xFFDC2626)
val NexStatusReview = Color(0xFF8B5CF6)
val NexStatusAppeal = Color(0xFF06B6D4)
