package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileSettingsScreen(
    currentUser: UserProfile,
    connectedSessions: List<ConnectedDeviceSession>,
    onOpenAppealDialog: () -> Unit,
    onNavigateToRules: () -> Unit,
    onNavigateToSupport: () -> Unit,
    onNavigateToModDashboard: () -> Unit,
    onDisconnectSession: (String) -> Unit,
    onTestAccountStatus: (AccountStatus, String?) -> Unit,
    onExportPersonalData: () -> Unit,
    onDeleteAccount: () -> Unit,
    onUpdateProfileDetails: (avatarUrl: String, bio: String) -> Unit = { _, _ -> }
) {
    var showExportSuccessDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showPhotoPickerModal by remember { mutableStateOf(false) }
    var showBioEditModal by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Profil & Paramètres", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Header Card (With Photo Access & Bio Description at the Bottom)
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // 1. Photo de Profil interactive
                        Box(
                            modifier = Modifier
                                .size(96.dp)
                                .clip(CircleShape)
                                .border(3.dp, NexCyan, CircleShape)
                                .clickable { showPhotoPickerModal = true }
                                .testTag("profile_photo_avatar"),
                            contentAlignment = Alignment.Center
                        ) {
                            if (currentUser.avatarUrl.isNotBlank()) {
                                AsyncImage(
                                    model = currentUser.avatarUrl,
                                    contentDescription = "Photo de profil",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize().clip(CircleShape)
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(NexElectricBlue),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = currentUser.displayName.take(1).uppercase(),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 38.sp
                                    )
                                }
                            }

                            // Dynamic Camera Edit Badge
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .align(Alignment.BottomEnd)
                                    .clip(CircleShape)
                                    .background(NexCyan),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = "Changer la photo",
                                    tint = Color.Black,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        TextButton(
                            onClick = { showPhotoPickerModal = true },
                            modifier = Modifier.testTag("change_photo_button")
                        ) {
                            Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp), tint = NexCyan)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Changer la photo de profil", color = NexCyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(currentUser.displayName, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(Icons.Default.Verified, contentDescription = "Certifié", tint = NexCyan, modifier = Modifier.size(18.dp))
                        }

                        Text("@${currentUser.username} • ${currentUser.email}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                        Spacer(modifier = Modifier.height(14.dp))

                        // 2. Section Description / Biographie du Profil (en bas de la carte)
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showBioEditModal = true }
                                .testTag("profile_bio_section")
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Notes, contentDescription = null, tint = NexCyan, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Description du Profil",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = NexCyan
                                        )
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Edit, contentDescription = "Modifier", tint = NexCyan, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Modifier", fontSize = 11.sp, color = NexCyan, fontWeight = FontWeight.SemiBold)
                                    }
                                }

                                Text(
                                    text = if (currentUser.bio.isNotBlank()) currentUser.bio else "Aucune description renseignée. Appuyez ici pour ajouter votre bio.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (currentUser.bio.isNotBlank()) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // Trust & Safety Account Status Banner
            item {
                val (bannerBg, icon, title, desc) = when (currentUser.status) {
                    AccountStatus.ACTIVE -> Quadruple(
                        NexStatusActive.copy(alpha = 0.15f),
                        Icons.Default.CheckCircle,
                        "Compte Certifié Conforme (ACTIF)",
                        "Aucune restriction. Toutes les fonctionnalités de communication sont pleinement autorisées."
                    )
                    AccountStatus.WARNING -> Quadruple(
                        NexStatusWarning.copy(alpha = 0.2f),
                        Icons.Default.Warning,
                        "Avertissement Officiel Actif (${currentUser.warningCount})",
                        currentUser.currentRestrictionReason ?: "Veuillez respecter scrupuleusement la charte NEXCHAT."
                    )
                    AccountStatus.RESTRICTED -> Quadruple(
                        NexStatusRestricted.copy(alpha = 0.2f),
                        Icons.Default.Block,
                        "Fonctionnalités Restreintes (RESTRICTED)",
                        currentUser.currentRestrictionReason ?: "L'envoi de messages ou de diffusions est temporairement verrouillé."
                    )
                    AccountStatus.TEMPORARILY_SUSPENDED -> Quadruple(
                        NexStatusSuspended.copy(alpha = 0.2f),
                        Icons.Default.PauseCircleFilled,
                        "Compte Suspendu Temporairement",
                        currentUser.currentRestrictionReason ?: "Votre accès sortant est suspendu pendant la durée d'examen."
                    )
                    AccountStatus.PERMANENTLY_BANNED -> Quadruple(
                        NexStatusBanned.copy(alpha = 0.25f),
                        Icons.Default.Cancel,
                        "Compte Banni Définitivement (BANNED)",
                        currentUser.currentRestrictionReason ?: "Violation grave et répétée des règles de NEXCHAT."
                    )
                    AccountStatus.APPEAL_PENDING -> Quadruple(
                        NexCyan.copy(alpha = 0.2f),
                        Icons.Default.Pending,
                        "Recours en Cours d'Examen Humain",
                        "Votre recours a été transmitted à l'équipe Trust & Safety. Réponse garantie sous 48h."
                    )
                    AccountStatus.UNDER_REVIEW -> Quadruple(
                        NexStatusReview.copy(alpha = 0.2f),
                        Icons.Default.Search,
                        "Dossier en Cours de Révision",
                        "L'équipe vérifie les éléments probants avant décision finale."
                    )
                }

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = bannerBg),
                    modifier = Modifier.fillMaxWidth().testTag("account_status_banner")
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        }

                        Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)

                        if (currentUser.status == AccountStatus.RESTRICTED ||
                            currentUser.status == AccountStatus.TEMPORARILY_SUSPENDED ||
                            currentUser.status == AccountStatus.PERMANENTLY_BANNED ||
                            currentUser.status == AccountStatus.WARNING
                        ) {
                            Button(
                                onClick = onOpenAppealDialog,
                                colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue),
                                modifier = Modifier.align(Alignment.End).testTag("profile_appeal_button")
                            ) {
                                Icon(Icons.Default.Gavel, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Déposer un recours", color = Color.White)
                            }
                        }
                    }
                }
            }

            // Quick Status Simulation Bar (For Interactive Verification)
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Simulateur Interactif de Statuts (Vérification directe) :",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelMedium,
                            color = NexElectricBlue
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            item {
                                FilterChip(
                                    selected = currentUser.status == AccountStatus.ACTIVE,
                                    onClick = { onTestAccountStatus(AccountStatus.ACTIVE, null) },
                                    label = { Text("Actif (Normal)") }
                                )
                            }
                            item {
                                FilterChip(
                                    selected = currentUser.status == AccountStatus.WARNING,
                                    onClick = { onTestAccountStatus(AccountStatus.WARNING, "Article 1 : Premier avertissement pour envoi rapide.") },
                                    label = { Text("Avertissement") }
                                )
                            }
                            item {
                                FilterChip(
                                    selected = currentUser.status == AccountStatus.RESTRICTED,
                                    onClick = { onTestAccountStatus(AccountStatus.RESTRICTED, "Article 1 : Envois temporairement limités pour 7 jours.") },
                                    label = { Text("Restreint") }
                                )
                            }
                            item {
                                FilterChip(
                                    selected = currentUser.status == AccountStatus.TEMPORARILY_SUSPENDED,
                                    onClick = { onTestAccountStatus(AccountStatus.TEMPORARILY_SUSPENDED, "Article 2 : Suspension préventive pour vérification.") },
                                    label = { Text("Suspendu") }
                                )
                            }
                            item {
                                FilterChip(
                                    selected = currentUser.status == AccountStatus.PERMANENTLY_BANNED,
                                    onClick = { onTestAccountStatus(AccountStatus.PERMANENTLY_BANNED, "Article 4 : Fraude manifeste constatée.") },
                                    label = { Text("Banni") }
                                )
                            }
                        }
                    }
                }
            }

            // Official Navigation Items
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column {
                        SettingsNavigationRow(
                            title = "Règles officielles de NEXCHAT",
                            subtitle = "Consulter les 14 articles et conditions v2.4.1",
                            icon = Icons.Default.Gavel,
                            onClick = onNavigateToRules
                        )
                    }
                }
            }

            // Privacy & Data Governance (RGPD)
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Gestion des Données Personnelles (RGPD)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)

                        Button(
                            onClick = {
                                onExportPersonalData()
                                showExportSuccessDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue),
                            modifier = Modifier.fillMaxWidth().testTag("export_data_button")
                        ) {
                            Icon(Icons.Default.Download, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Télécharger mes données personnelles (.json)")
                        }

                        OutlinedButton(
                            onClick = { showDeleteConfirmDialog = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.fillMaxWidth().testTag("delete_account_button")
                        ) {
                            Icon(Icons.Default.DeleteForever, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Demander la suppression définitive du compte")
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Modal 1: Photo de Profil Picker & Gallery Presets
    if (showPhotoPickerModal) {
        ProfilePhotoPickerModal(
            currentPhotoUrl = currentUser.avatarUrl,
            onDismiss = { showPhotoPickerModal = false },
            onSavePhoto = { newUrl ->
                onUpdateProfileDetails(newUrl, currentUser.bio)
                showPhotoPickerModal = false
            }
        )
    }

    // Modal 2: Description / Bio Editor
    if (showBioEditModal) {
        BioEditModalDialog(
            currentBio = currentUser.bio,
            onDismiss = { showBioEditModal = false },
            onSaveBio = { newBio ->
                onUpdateProfileDetails(currentUser.avatarUrl, newBio)
                showBioEditModal = false
            }
        )
    }

    if (showExportSuccessDialog) {
        AlertDialog(
            onDismissRequest = { showExportSuccessDialog = false },
            title = { Text("Export des Données Prêt") },
            text = { Text("Votre archive chiffrée (identifiant, historique des consentements v2.4.1, journaux de session et discussions) a été générée avec succès.") },
            confirmButton = {
                Button(onClick = { showExportSuccessDialog = false }) {
                    Text("OK")
                }
            }
        )
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Confirmer la suppression du compte ?") },
            text = { Text("Attention : cette action est irréversible. Toutes vos sessions seront révoquées et vos clés de chiffrement effacées.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteAccount()
                        showDeleteConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Supprimer définitivement")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("Annuler")
                }
            }
        )
    }
}

// Modal Component: Profile Photo Picker & Presets
@Composable
fun ProfilePhotoPickerModal(
    currentPhotoUrl: String,
    onDismiss: () -> Unit,
    onSavePhoto: (String) -> Unit
) {
    var photoUrlInput by remember { mutableStateOf(currentPhotoUrl) }

    val presetAvatars = listOf(
        "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300",
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300",
        "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300",
        "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300",
        "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=300",
        "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PhotoCamera, contentDescription = null, tint = NexCyan)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Changer la Photo de Profil", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Choisissez un avatar prédéfini ou entrez le lien d'une image personnalisée :", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                // Presets Gallery
                Text("Avatars officiels NEXCHAT :", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = NexCyan)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    presetAvatars.forEach { url ->
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .border(
                                    width = if (photoUrlInput == url) 3.dp else 1.dp,
                                    color = if (photoUrlInput == url) NexCyan else Color.Gray,
                                    shape = CircleShape
                                )
                                .clickable { photoUrlInput = url },
                            contentAlignment = Alignment.Center
                        ) {
                            AsyncImage(
                                model = url,
                                contentDescription = "Avatar",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize().clip(CircleShape)
                            )
                        }
                    }
                }

                HorizontalDivider()

                // Custom URL Input
                OutlinedTextField(
                    value = photoUrlInput,
                    onValueChange = { photoUrlInput = it },
                    label = { Text("Lien HTTPS de l'image") },
                    placeholder = { Text("https://exemple.com/ma-photo.jpg") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        if (photoUrlInput.isNotBlank()) {
                            IconButton(onClick = { photoUrlInput = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Effacer")
                            }
                        }
                    }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSavePhoto(photoUrlInput) },
                colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue)
            ) {
                Text("Enregistrer")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Annuler")
            }
        }
    )
}

// Modal Component: Bio / Description Editor
@Composable
fun BioEditModalDialog(
    currentBio: String,
    onDismiss: () -> Unit,
    onSaveBio: (String) -> Unit
) {
    var bioInput by remember { mutableStateOf(currentBio) }
    val maxBioLength = 250

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.EditNote, contentDescription = null, tint = NexCyan)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Modifier la Description", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Rédigez une courte présentation visible par vos contacts et dans les chaînes :", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                OutlinedTextField(
                    value = bioInput,
                    onValueChange = { if (it.length <= maxBioLength) bioInput = it },
                    label = { Text("Description / Bio du Profil") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth(),
                    supportingText = {
                        Text(
                            text = "${bioInput.length} / $maxBioLength caractères",
                            modifier = Modifier.fillMaxWidth(),
                            color = if (bioInput.length >= maxBioLength) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSaveBio(bioInput.trim()) },
                colors = ButtonDefaults.buttonColors(containerColor = NexElectricBlue)
            ) {
                Text("Enregistrer la Bio")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Annuler")
            }
        }
    )
}

@Composable
fun SettingsNavigationRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = NexCyan)
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
