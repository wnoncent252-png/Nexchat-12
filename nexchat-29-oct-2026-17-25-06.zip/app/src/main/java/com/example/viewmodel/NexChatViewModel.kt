package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiMessage
import com.example.ai.AiProvider
import com.example.ai.NexChatAiService
import com.example.model.*
import com.example.security.AdminOperationResult
import com.example.repository.NexChatRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppScreen(val title: String, val iconName: String) {
    DISCUSSIONS("Chats", "Chat"),
    VIDEOS("Vidéos", "PlayCircle"),
    STATUS("Statuts", "Schedule"),
    LIVES("Lives", "LiveTv"),
    AI_ASSISTANT("NexChat AI", "SmartToy"),
    CHANNELS("Chaînes", "RssFeed"),

    // Sub-screens directly opened from the (⋮) menu:
    SETTINGS_GENERAL("Paramètres", "Settings"),
    ACCOUNT_DETAILS("Mon compte", "AccountCircle"),
    PRIVACY_SECURITY("Confidentialité et sécurité", "Security"),
    NOTIFICATIONS_SETTINGS("Notifications", "Notifications"),
    PERSONALIZATION_SETTINGS("Personnalisation", "Palette"),
    DISCUSSIONS_SETTINGS("Discussions et messages", "Forum"),
    RULES("Règles de NexChat", "Gavel"),
    ACCOUNT_STATUS_DETAIL("État de mon compte", "Badge"),
    NEXCHAT_PRO("NexChat Pro", "Star"),
    SUPPORT_CENTER("Aide et assistance", "ContactSupport"),
    REPORT_PROBLEM("Signaler un problème", "ReportProblem"),
    ABOUT_NEXCHAT("À propos de NexChat", "Info"),
    SUPER_ADMIN_PANEL("Espace Super Admin", "AdminPanelSettings"),
    MODERATOR_DASHBOARD("Modération & Admin", "AdminPanelSettings"),
    CALLS("Appels", "Call"),
    COMMUNITIES("Communautés", "Groups"),
    PROFILE_SETTINGS("Profil & Paramètres", "Person")
}

data class ActiveCallState(
    val contactName: String,
    val callType: CallType,
    val isMuted: Boolean = false,
    val isVideoOff: Boolean = false,
    val isConnected: Boolean = true,
    val durationSeconds: Int = 0
)

class NexChatViewModel(application: Application) : AndroidViewModel(application) {

    val repository = NexChatRepository()
    private val aiService = NexChatAiService(application.applicationContext)

    // Current Screen
    private val _currentScreen = MutableStateFlow(AppScreen.DISCUSSIONS)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val screenBackStack = mutableListOf(AppScreen.DISCUSSIONS)

    private val _selectedConversationId = MutableStateFlow<String?>(null)
    val selectedConversationId: StateFlow<String?> = _selectedConversationId.asStateFlow()

    private val _selectedLiveId = MutableStateFlow<String?>(null)
    val selectedLiveId: StateFlow<String?> = _selectedLiveId.asStateFlow()

    private val _selectedStoryId = MutableStateFlow<String?>(null)
    val selectedStoryId: StateFlow<String?> = _selectedStoryId.asStateFlow()

    private val _activeCall = MutableStateFlow<ActiveCallState?>(null)
    val activeCall: StateFlow<ActiveCallState?> = _activeCall.asStateFlow()

    private val _reportTarget = MutableStateFlow<Pair<ReportEntityType, String>?>(null)
    val reportTarget: StateFlow<Pair<ReportEntityType, String>?> = _reportTarget.asStateFlow()

    private val _isAppealDialogOpen = MutableStateFlow(false)
    val isAppealDialogOpen: StateFlow<Boolean> = _isAppealDialogOpen.asStateFlow()

    private val _moderatorActionTarget = MutableStateFlow<Pair<String, String>?>(null)
    val moderatorActionTarget: StateFlow<Pair<String, String>?> = _moderatorActionTarget.asStateFlow()

    private val _showTermsModal = MutableStateFlow(false)
    val showTermsModal: StateFlow<Boolean> = _showTermsModal.asStateFlow()

    private val _eventNotification = MutableSharedFlow<String>()
    val eventNotification: SharedFlow<String> = _eventNotification.asSharedFlow()

    // NexChat AI Conversation State
    private val _aiMessages = MutableStateFlow<List<AiMessage>>(
        listOf(
            AiMessage(
                id = "ai_welcome",
                sender = "NEXCHAT_AI",
                content = "Bonjour Hector ! Je suis NexChat AI, votre assistant officiel. Je peux vous expliquer les règles de notre charte, clarifier les sanctions et restrictions anti-spam, vous guider pour déposer un recours, vous aider à rédiger ou traduire vos messages, ou vous présenter les avantages exclusifs de NexChat Pro ⚡",
                timestamp = System.currentTimeMillis()
            )
        )
    )
    val aiMessages: StateFlow<List<AiMessage>> = _aiMessages.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    private val _currentStreamingAiText = MutableStateFlow("")
    val currentStreamingAiText: StateFlow<String> = _currentStreamingAiText.asStateFlow()

    val aiProvider: AiProvider get() = aiService.currentProvider

    fun setAiProvider(provider: AiProvider) {
        aiService.currentProvider = provider
        viewModelScope.launch {
            _eventNotification.emit("Fournisseur IA mis à jour : ${provider.displayName}")
        }
    }

    fun navigateTo(screen: AppScreen) {
        val user = repository.currentUser.value
        if (screen == AppScreen.SUPER_ADMIN_PANEL && !user.role.canEditConfig) {
            repository.logAudit("UNAUTHORIZED_ROUTE_ATTEMPT", "GLOBAL", user.username, "Tentative d'accès non autorisée à la console Super Admin (Code 403)", null)
            viewModelScope.launch {
                _eventNotification.emit("Accès refusé (403) : Votre rôle ${user.role.displayName} ne permet pas d'accéder à la console Super Admin.")
            }
            return
        }
        if (screen == AppScreen.MODERATOR_DASHBOARD && !user.role.canModerate) {
            repository.logAudit("UNAUTHORIZED_ROUTE_ATTEMPT", "GLOBAL", user.username, "Tentative d'accès non autorisée au tableau de modération (Code 403)", null)
            viewModelScope.launch {
                _eventNotification.emit("Accès refusé (403) : Vos privilèges de compte sont insuffisants pour la modération.")
            }
            return
        }
        if (_currentScreen.value != screen) {
            screenBackStack.add(screen)
            _currentScreen.value = screen
        }
    }

    fun handleBack(): Boolean {
        if (_selectedConversationId.value != null) {
            _selectedConversationId.value = null
            return true
        }
        if (_selectedLiveId.value != null) {
            _selectedLiveId.value = null
            return true
        }
        if (_selectedStoryId.value != null) {
            _selectedStoryId.value = null
            return true
        }
        if (screenBackStack.size > 1) {
            screenBackStack.removeAt(screenBackStack.lastIndex)
            _currentScreen.value = screenBackStack.last()
            return true
        }
        return false
    }

    fun openConversation(id: String) { _selectedConversationId.value = id }
    fun closeConversation() { _selectedConversationId.value = null }
    fun openLive(liveId: String) { _selectedLiveId.value = liveId }
    fun closeLive() { _selectedLiveId.value = null }
    fun openStory(storyId: String) { _selectedStoryId.value = storyId }
    fun closeStory() { _selectedStoryId.value = null }
    fun openReportDialog(entityType: ReportEntityType, entityId: String) { _reportTarget.value = Pair(entityType, entityId) }
    fun closeReportDialog() { _reportTarget.value = null }
    fun openAppealDialog() { _isAppealDialogOpen.value = true }
    fun closeAppealDialog() { _isAppealDialogOpen.value = false }
    fun setShowTermsModal(show: Boolean) { _showTermsModal.value = show }

    // --- Terms Acceptance ---
    fun acceptTerms() {
        repository.acceptTerms(repository.currentUser.value.userId)
        _showTermsModal.value = false
        viewModelScope.launch {
            _eventNotification.emit("Règles officielles et conditions de NexChat acceptées (v2.4.1).")
        }
    }

    // --- Role Switching for Testing / Admin Access ---
    fun switchUserRole(role: UserRole) {
        repository.setUserRole(role)
        viewModelScope.launch {
            _eventNotification.emit("Rôle changé en : ${role.displayName}")
        }
    }

    fun testAccountStatus(status: AccountStatus, reason: String? = null, durationMillis: Long? = null) {
        repository.setUserAccountStatus(status, reason, durationMillis)
        viewModelScope.launch {
            _eventNotification.emit("Statut du compte configuré sur : ${status.label}")
        }
    }

    // --- Messaging & Anti-Spam ---
    fun sendChatMessage(conversationId: String, text: String, isViewOnce: Boolean = false) {
        val (success, errorMsg) = repository.sendMessage(conversationId, text, isViewOnce)
        if (!success) {
            viewModelScope.launch {
                _eventNotification.emit(errorMsg ?: "Message bloqué.")
            }
        }
    }

    fun sendMediaMessage(
        conversationId: String,
        text: String,
        mediaType: String,
        mediaUrl: String,
        mediaName: String,
        mediaSize: String,
        isViewOnce: Boolean
    ) {
        val (success, errorMsg) = repository.sendMediaMessage(
            conversationId, text, mediaType, mediaUrl, mediaName, mediaSize, isViewOnce
        )
        if (!success) {
            viewModelScope.launch {
                _eventNotification.emit(errorMsg ?: "Envoi du média bloqué.")
            }
        } else {
            viewModelScope.launch {
                val typeLabel = when (mediaType) {
                    "IMAGE" -> "Photo"
                    "VIDEO" -> "Vidéo"
                    else -> "Document"
                }
                val modeLabel = if (isViewOnce) "vue unique" else "chiffré(e)"
                _eventNotification.emit("✅ $typeLabel $modeLabel envoyé(e) avec succès.")
            }
        }
    }

    fun markMessageViewed(messageId: String) {
        repository.markMessageViewed(messageId)
    }

    // --- Videos & Likes Actions (Separate from Lives) ---
    fun toggleLikeVideo(videoId: String) {
        val (isLiked, count) = repository.toggleLikeVideo(videoId)
        viewModelScope.launch {
            val text = if (isLiked) "J'aime ajouté ($count likes)" else "J'aime retiré ($count likes)"
            _eventNotification.emit(text)
        }
    }

    fun addVideoComment(videoId: String, comment: String) {
        if (comment.isNotBlank()) {
            repository.addVideoComment(videoId, comment)
            viewModelScope.launch {
                _eventNotification.emit("Commentaire publié.")
            }
        }
    }

    fun publishVideo(caption: String) {
        if (caption.isNotBlank()) {
            val video = repository.publishVideo(caption)
            viewModelScope.launch {
                _eventNotification.emit("Vidéo publiée avec succès !")
            }
        }
    }

    fun sendLiveComment(liveId: String, text: String) {
        val success = repository.addLiveComment(liveId, text)
        if (!success) {
            viewModelScope.launch {
                _eventNotification.emit("Envoi bloqué : Votre compte fait l'objet d'une suspension ou restriction active.")
            }
        }
    }

    // --- NexChat Pro Actions ---
    fun subscribeToPro(planId: String) {
        val tx = repository.subscribeToPro(planId)
        viewModelScope.launch {
            _eventNotification.emit("Abonnement activé avec succès ! Facture : ${tx.invoiceNumber}")
        }
    }

    fun toggleProAutoRenew() {
        repository.toggleProAutoRenew()
        val newState = repository.currentUser.value.proAutoRenew
        viewModelScope.launch {
            _eventNotification.emit(if (newState) "Renouvellement automatique activé." else "Renouvellement automatique désactivé.")
        }
    }

    // --- Super Admin Direct Modification Without Rebuilding APK ---
    fun updateProPlanPrice(planId: String, newPrice: Double, newFormattedPrice: String) {
        val result = repository.updateProPlanPrice(planId, newPrice, newFormattedPrice)
        viewModelScope.launch {
            when (result) {
                is AdminOperationResult.Success -> _eventNotification.emit("Tarif mis à jour sur le serveur ($newFormattedPrice)")
                is AdminOperationResult.Unauthorized -> _eventNotification.emit(result.message)
                is AdminOperationResult.ValidationError -> _eventNotification.emit("Erreur : ${result.message}")
            }
        }
    }

    fun updateAntiSpamThresholds(maxIdentical: Int, timeWindowSeconds: Int, tempHours: Int, burst: Int = 5) {
        val result = repository.updateAntiSpamThresholds(maxIdentical, timeWindowSeconds, tempHours, burst)
        viewModelScope.launch {
            when (result) {
                is AdminOperationResult.Success -> _eventNotification.emit("Seuils anti-spam sauvegardés sur le serveur !")
                is AdminOperationResult.Unauthorized -> _eventNotification.emit(result.message)
                is AdminOperationResult.ValidationError -> _eventNotification.emit("Erreur : ${result.message}")
            }
        }
    }

    fun updateAnnouncement(announcement: String, isBannerEnabled: Boolean) {
        val result = repository.updateAnnouncement(announcement, isBannerEnabled)
        viewModelScope.launch {
            when (result) {
                is AdminOperationResult.Success -> _eventNotification.emit("Annonce globale mise à jour.")
                is AdminOperationResult.Unauthorized -> _eventNotification.emit(result.message)
                is AdminOperationResult.ValidationError -> _eventNotification.emit("Erreur : ${result.message}")
            }
        }
    }

    fun updateGeneralSettings(supportEmail: String, maxAttachmentMb: Int, e2eeEnforced: Boolean, maintenanceMode: Boolean) {
        val result = repository.updateGeneralSettings(supportEmail, maxAttachmentMb, e2eeEnforced, maintenanceMode)
        viewModelScope.launch {
            when (result) {
                is AdminOperationResult.Success -> _eventNotification.emit("Paramètres généraux sauvegardés sur le serveur.")
                is AdminOperationResult.Unauthorized -> _eventNotification.emit(result.message)
                is AdminOperationResult.ValidationError -> _eventNotification.emit("Erreur : ${result.message}")
            }
        }
    }

    // --- Reports & Appeals ---
    fun submitReport(reason: String, details: String) {
        val target = _reportTarget.value ?: return
        val report = repository.submitReport(
            reporterId = repository.currentUser.value.username,
            entityType = target.first,
            entityId = target.second,
            targetUser = target.second,
            reason = reason,
            comment = details
        )
        _reportTarget.value = null
        viewModelScope.launch {
            val urgentNotice = if (report.isAutoUrgent) " [URGENT]" else ""
            _eventNotification.emit("Signalement transmis à Trust & Safety (Dossier : ${report.relatedCaseId})$urgentNotice")
        }
    }

    fun submitAppeal(explanation: String) {
        val actionId = repository.moderationActions.value.firstOrNull()?.id ?: "act_general"
        val appeal = repository.submitAppeal(actionId, explanation)
        _isAppealDialogOpen.value = false
        viewModelScope.launch {
            _eventNotification.emit("Recours n° ${appeal.id} déposé. Examen humain impartial en cours.")
        }
    }

    // --- Voice Notes, Reactions & Replies ---
    fun sendVoiceNote(conversationId: String, durationSeconds: Int) {
        val (success, errorMsg) = repository.sendVoiceNote(conversationId, durationSeconds)
        if (!success) {
            viewModelScope.launch {
                _eventNotification.emit(errorMsg ?: "Impossible d'envoyer la note vocale.")
            }
        }
    }

    fun sendMessageWithReply(conversationId: String, text: String, repliedSnippet: String) {
        val (success, errorMsg) = repository.sendMessageWithReply(conversationId, text, repliedSnippet)
        if (!success) {
            viewModelScope.launch {
                _eventNotification.emit(errorMsg ?: "Message bloqué.")
            }
        }
    }

    fun toggleMessageReaction(messageId: String, emoji: String) {
        repository.toggleMessageReaction(messageId, emoji)
    }

    // --- Calls ---
    fun startCall(contactName: String, type: CallType) {
        val (allowed, err) = repository.isFeatureAllowed(repository.currentUser.value, NexFeature.AUDIO_VIDEO_CALLS)
        if (!allowed) {
            viewModelScope.launch {
                _eventNotification.emit(err ?: "Appels désactivés pour ce compte.")
            }
            return
        }
        _activeCall.value = ActiveCallState(contactName = contactName, callType = type, durationSeconds = 1)
    }

    fun updateCallDuration(seconds: Int) {
        _activeCall.value = _activeCall.value?.copy(durationSeconds = seconds)
    }

    fun toggleCallMute() {
        _activeCall.value = _activeCall.value?.let { it.copy(isMuted = !it.isMuted) }
    }

    fun toggleCallVideo() {
        _activeCall.value = _activeCall.value?.let { it.copy(isVideoOff = !it.isVideoOff) }
    }

    fun endCall() {
        val call = _activeCall.value
        if (call != null) {
            repository.recordCallLog(
                contactName = call.contactName,
                type = call.callType,
                durationSeconds = call.durationSeconds
            )
            val durationText = String.format(java.util.Locale.FRENCH, "%02d:%02d", call.durationSeconds / 60, call.durationSeconds % 60)
            viewModelScope.launch {
                _eventNotification.emit("Appel terminé ($durationText) — Enregistré dans le journal d'appels.")
            }
        }
        _activeCall.value = null
    }


    // --- AI Assistant ---
    fun sendAiPrompt(prompt: String) {
        if (prompt.isBlank() || _isAiLoading.value) return

        val userMsg = AiMessage(
            id = "usr_" + UUID.randomUUID().toString().take(6),
            sender = "USER",
            content = prompt,
            timestamp = System.currentTimeMillis()
        )
        _aiMessages.value = _aiMessages.value + userMsg
        _isAiLoading.value = true
        _currentStreamingAiText.value = ""

        viewModelScope.launch {
            try {
                val fullAnswer = aiService.sendMessage(
                    userPrompt = prompt,
                    currentUser = repository.currentUser.value,
                    onChunk = { chunk -> _currentStreamingAiText.value = chunk }
                )

                val isImage = fullAnswer.contains("Image Générée") || fullAnswer.contains("Image URL:") ||
                        prompt.contains("image", ignoreCase = true) || prompt.contains("dessine", ignoreCase = true) || prompt.contains("photo", ignoreCase = true)
                val imgUrl = if (isImage) aiService.pickFastImageUrl(prompt) else null

                val isCode = fullAnswer.contains("```")
                val codeSnippet = if (isCode) {
                    val codeStart = fullAnswer.indexOf("```")
                    val afterFirst = fullAnswer.substring(codeStart + 3)
                    val langLineEnd = afterFirst.indexOf("\n")
                    val codeEnd = afterFirst.indexOf("```")
                    if (langLineEnd != -1 && codeEnd != -1 && codeEnd > langLineEnd) {
                        afterFirst.substring(langLineEnd + 1, codeEnd).trim()
                    } else null
                } else null

                val codeLang = if (isCode) {
                    if (prompt.contains("python", ignoreCase = true)) "PYTHON"
                    else if (prompt.contains("javascript", ignoreCase = true) || prompt.contains("js", ignoreCase = true)) "JAVASCRIPT"
                    else "KOTLIN"
                } else null

                val aiMsg = AiMessage(
                    id = "ai_" + UUID.randomUUID().toString().take(6),
                    sender = "NEXCHAT_AI",
                    content = fullAnswer,
                    timestamp = System.currentTimeMillis(),
                    isCodeBlock = isCode,
                    codeSnippet = codeSnippet,
                    codeLanguage = codeLang,
                    generatedImageUrl = imgUrl,
                    isFastImage = isImage
                )
                _aiMessages.value = _aiMessages.value + aiMsg
            } catch (e: Exception) {
                val errorMsg = AiMessage(
                    id = "ai_err_" + UUID.randomUUID().toString().take(6),
                    sender = "NEXCHAT_AI",
                    content = "Erreur de connexion à l'assistant : ${e.localizedMessage ?: "Service momentanément indisponible"}.",
                    timestamp = System.currentTimeMillis()
                )
                _aiMessages.value = _aiMessages.value + errorMsg
            } finally {
                _isAiLoading.value = false
                _currentStreamingAiText.value = ""
            }
        }
    }

    fun clearAiHistory() {
        _aiMessages.value = listOf(
            AiMessage(
                id = "ai_reset",
                sender = "NEXCHAT_AI",
                content = "Historique de discussion réinitialisé.",
                timestamp = System.currentTimeMillis()
            )
        )
        viewModelScope.launch {
            _eventNotification.emit("Historique de l'assistant effacé.")
        }
    }

    fun submitSupportTicket(email: String, category: TicketCategory, deviceType: String, description: String) {
        val ticket = repository.submitSupportTicket(
            email = email,
            nexchatId = repository.currentUser.value.username,
            category = category,
            deviceType = deviceType,
            description = description
        )
        viewModelScope.launch {
            _eventNotification.emit("Dossier ${ticket.ticketNumber} créé ! Transmis à l'assistance Gmail.")
        }
    }

    fun emitNotification(message: String) {
        viewModelScope.launch {
            _eventNotification.emit(message)
        }
    }

    fun searchUsers(query: String): AdminOperationResult<List<UserProfile>> {
        return repository.searchUsers(query, repository.currentUser.value)
    }

    fun searchUsersByRole(
        query: String = "",
        roleFilter: String = "ALL",
        statusFilter: String = "ALL"
    ): AdminOperationResult<List<UserProfile>> {
        return repository.searchUsersByRole(
            query = query,
            roleFilter = roleFilter,
            statusFilter = statusFilter,
            caller = repository.currentUser.value
        )
    }

    fun updateUserRole(
        targetUserId: String,
        newRole: UserRole
    ): AdminOperationResult<UserProfile> {
        val result = repository.updateUserRole(
            targetUserId = targetUserId,
            newRole = newRole,
            caller = repository.currentUser.value
        )
        when (result) {
            is AdminOperationResult.Success -> emitNotification("✅ Rôle de @${result.data.username} mis à jour : ${newRole.displayName}")
            is AdminOperationResult.Unauthorized -> emitNotification("❌ " + result.message)
            is AdminOperationResult.ValidationError -> emitNotification("⚠️ " + result.message)
        }
        return result
    }

    fun updateProfileDetails(avatarUrl: String, bio: String, displayName: String = repository.currentUser.value.displayName) {
        repository.updateProfileDetails(avatarUrl, bio, displayName)
        emitNotification("✅ Profil mis à jour avec succès")
    }

    fun searchAuditLogs(
        query: String = "",
        eventTypeFilter: String = "ALL",
        severityFilter: String = "ALL",
        userFilter: String = "",
        page: Int = 1,
        pageSize: Int = 10
    ): AdminOperationResult<PaginatedAuditLogsResult> {
        return repository.searchAuditLogs(
            query = query,
            eventTypeFilter = eventTypeFilter,
            severityFilter = severityFilter,
            userFilter = userFilter,
            page = page,
            pageSize = pageSize,
            caller = repository.currentUser.value
        )
    }

    fun exportAuditLogs(format: String): AdminOperationResult<String> {
        val result = repository.exportAuditLogs(format, repository.currentUser.value)
        if (result is AdminOperationResult.Success) {
            emitNotification("✅ Journaux d'audit générés (${format})")
        } else if (result is AdminOperationResult.Unauthorized) {
            emitNotification("❌ " + result.message)
        }
        return result
    }

    fun issueWarningWithFeedback(targetUser: String, caseId: String, reason: String) {
        val res = repository.issueWarning(targetUser, caseId, reason, repository.currentUser.value.username, repository.currentUser.value)
        when (res) {
            is AdminOperationResult.Success -> emitNotification("⚠️ Avertissement émis à l'encontre de @$targetUser")
            is AdminOperationResult.Unauthorized -> emitNotification("❌ " + res.message)
            is AdminOperationResult.ValidationError -> emitNotification("❌ " + res.message)
        }
    }

    fun applySuspensionWithFeedback(targetUser: String, caseId: String, days: Int, reason: String) {
        val res = repository.applySuspension(targetUser, caseId, days, reason, repository.currentUser.value.username, repository.currentUser.value)
        when (res) {
            is AdminOperationResult.Success -> emitNotification("🛑 Suspension ${days}j appliquée avec succès à @$targetUser")
            is AdminOperationResult.Unauthorized -> emitNotification("❌ " + res.message)
            is AdminOperationResult.ValidationError -> emitNotification("❌ " + res.message)
        }
    }

    fun applyPermanentBanWithFeedback(targetUser: String, caseId: String, reason: String) {
        val res = repository.applyPermanentBan(targetUser, caseId, reason, repository.currentUser.value.username, repository.currentUser.value)
        when (res) {
            is AdminOperationResult.Success -> emitNotification("⛔ Bannissement 7j appliqué à @$targetUser")
            is AdminOperationResult.Unauthorized -> emitNotification("❌ " + res.message)
            is AdminOperationResult.ValidationError -> emitNotification("❌ " + res.message)
        }
    }

    fun liftSanctionWithFeedback(targetUser: String, actionId: String, reason: String) {
        val res = repository.liftSanction(targetUser, actionId, reason, repository.currentUser.value.username, repository.currentUser.value)
        when (res) {
            is AdminOperationResult.Success -> emitNotification("✅ Sanction levée pour @$targetUser (Compte réactivé)")
            is AdminOperationResult.Unauthorized -> emitNotification("❌ " + res.message)
            is AdminOperationResult.ValidationError -> emitNotification("❌ " + res.message)
        }
    }

    fun toggleBlockUser(usernameOrId: String) {
        val isBlockedNow = repository.toggleBlockUser(usernameOrId)
        viewModelScope.launch {
            if (isBlockedNow) {
                _eventNotification.emit("Utilisateur @$usernameOrId bloqué.")
            } else {
                _eventNotification.emit("Utilisateur @$usernameOrId débloqué.")
            }
        }
    }

    fun updateThemeMode(themeMode: String) {
        repository.updateThemeMode(themeMode)
        viewModelScope.launch {
            val label = when (themeMode) {
                "LIGHT" -> "Mode Clair"
                "DARK" -> "Mode Sombre"
                else -> "Thème Système"
            }
            _eventNotification.emit("Thème appliqué : $label")
        }
    }

    fun updatePersonalization(accentColorHex: Long, secondaryColorHex: Long, wallpaperIndex: Int, themeMode: String = repository.currentUser.value.personalization.themeMode) {
        repository.updatePersonalization(accentColorHex, secondaryColorHex, wallpaperIndex, themeMode)
    }

    fun login(email: String, name: String, username: String) {
        repository.login(email, name, username)
        viewModelScope.launch {
            _eventNotification.emit("Connexion réussie ! Bienvenue sur NexChat, $name.")
        }
    }

    fun logout() {
        repository.logout()
        viewModelScope.launch {
            _eventNotification.emit("Déconnexion réussie.")
        }
    }
}
