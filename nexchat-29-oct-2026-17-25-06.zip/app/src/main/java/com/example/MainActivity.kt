package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.util.configureAppCheck
import com.example.viewmodel.AppScreen
import com.example.viewmodel.NexChatViewModel
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {

    private val viewModel: NexChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: App Check Foundation with launch intent
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        setContent {
            val currentUser by viewModel.repository.currentUser.collectAsStateWithLifecycle()
            val isSystemDark = androidx.compose.foundation.isSystemInDarkTheme()
            val isDark = when (currentUser.personalization.themeMode) {
                "LIGHT" -> false
                "DARK" -> true
                else -> isSystemDark
            }
            NexChatTheme(darkTheme = isDark) {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent(viewModel: NexChatViewModel) {
    val isUserLoggedIn by viewModel.repository.isUserLoggedIn.collectAsStateWithLifecycle()
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val currentUser by viewModel.repository.currentUser.collectAsStateWithLifecycle()
    val dynamicConfig by viewModel.repository.dynamicConfig.collectAsStateWithLifecycle()
    val conversations by viewModel.repository.conversations.collectAsStateWithLifecycle()
    val messages by viewModel.repository.messages.collectAsStateWithLifecycle()
    val videoPosts by viewModel.repository.videoPosts.collectAsStateWithLifecycle()
    val stories by viewModel.repository.stories.collectAsStateWithLifecycle()
    val lives by viewModel.repository.lives.collectAsStateWithLifecycle()
    val liveComments by viewModel.repository.liveComments.collectAsStateWithLifecycle()
    val callLogs by viewModel.repository.callLogs.collectAsStateWithLifecycle()
    val communities by viewModel.repository.communities.collectAsStateWithLifecycle()
    val moderationCases by viewModel.repository.moderationCases.collectAsStateWithLifecycle()
    val moderationActions by viewModel.repository.moderationActions.collectAsStateWithLifecycle()
    val activeRestrictions by viewModel.repository.activeRestrictions.collectAsStateWithLifecycle()
    val appeals by viewModel.repository.appeals.collectAsStateWithLifecycle()
    val auditLogs by viewModel.repository.auditLogs.collectAsStateWithLifecycle()
    val managedUsers by viewModel.repository.managedUsers.collectAsStateWithLifecycle()
    val supportTickets by viewModel.repository.supportTickets.collectAsStateWithLifecycle()
    val connectedSessions by viewModel.repository.connectedSessions.collectAsStateWithLifecycle()
    val proTransactions by viewModel.repository.proTransactions.collectAsStateWithLifecycle()

    val selectedConversationId by viewModel.selectedConversationId.collectAsStateWithLifecycle()
    val selectedLiveId by viewModel.selectedLiveId.collectAsStateWithLifecycle()
    val activeCall by viewModel.activeCall.collectAsStateWithLifecycle()
    val reportTarget by viewModel.reportTarget.collectAsStateWithLifecycle()
    val isAppealDialogOpen by viewModel.isAppealDialogOpen.collectAsStateWithLifecycle()
    val showTermsModal by viewModel.showTermsModal.collectAsStateWithLifecycle()

    val aiMessages by viewModel.aiMessages.collectAsStateWithLifecycle()
    val isAiLoading by viewModel.isAiLoading.collectAsStateWithLifecycle()
    val streamingAiText by viewModel.currentStreamingAiText.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var showThreeDotsMenu by remember { mutableStateOf(false) }

    // Intercept hardware Back button
    BackHandler(enabled = true) {
        viewModel.handleBack()
    }

    LaunchedEffect(Unit) {
        viewModel.eventNotification.collectLatest { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    if (!isUserLoggedIn) {
        AuthScreen(
            onLoginSuccess = { email, name, uname -> viewModel.login(email, name, uname) },
            onViewRules = { viewModel.navigateTo(AppScreen.RULES) }
        )
        return
    }

    val isMainTab = currentScreen == AppScreen.DISCUSSIONS ||
            currentScreen == AppScreen.VIDEOS ||
            currentScreen == AppScreen.STATUS ||
            currentScreen == AppScreen.LIVES ||
            currentScreen == AppScreen.AI_ASSISTANT ||
            currentScreen == AppScreen.CHANNELS

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (selectedConversationId == null && selectedLiveId == null && activeCall == null && isMainTab) {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(id = R.drawable.nexchat_brand_logo),
                                contentDescription = "Logo",
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "NexChat",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 18.sp,
                                        color = NexCyan
                                    )
                                    if (currentUser.isProSubscriber) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            color = Color(0xFFFFD700),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = "PRO",
                                                color = Color.Black,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                                Text(
                                    text = dynamicConfig.appAnnouncement,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        }
                    },
                    actions = {
                        // NexChat Pro Quick Access Action
                        if (!currentUser.isProSubscriber) {
                            TextButton(
                                onClick = { viewModel.navigateTo(AppScreen.NEXCHAT_PRO) },
                                modifier = Modifier.testTag("top_bar_pro_badge")
                            ) {
                                Text("PRO ⚡", fontWeight = FontWeight.Bold, color = NexCyan, fontSize = 12.sp)
                            }
                        }

                        // The 3 Dots (⋮) Menu Button
                        Box {
                            IconButton(
                                onClick = { showThreeDotsMenu = true },
                                modifier = Modifier.testTag("three_dots_menu_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "Menu des paramètres",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            // The 8 Organized Menu Items according to spec
                            DropdownMenu(
                                expanded = showThreeDotsMenu,
                                onDismissRequest = { showThreeDotsMenu = false },
                                modifier = Modifier.widthIn(min = 230.dp)
                            ) {
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Chat, null, tint = NexCyan) },
                                    text = { Text("1. Nouvelle discussion") },
                                    onClick = {
                                        showThreeDotsMenu = false
                                        viewModel.navigateTo(AppScreen.DISCUSSIONS)
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.GroupAdd, null, tint = NexCyan) },
                                    text = { Text("2. Nouveau groupe") },
                                    onClick = {
                                        showThreeDotsMenu = false
                                        viewModel.navigateTo(AppScreen.COMMUNITIES)
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Devices, null, tint = NexCyan) },
                                    text = { Text("3. Appareils connectés") },
                                    onClick = {
                                        showThreeDotsMenu = false
                                        viewModel.navigateTo(AppScreen.CALLS)
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Star, null, tint = NexCyan) },
                                    text = { Text("4. Messages importants") },
                                    onClick = {
                                        showThreeDotsMenu = false
                                        viewModel.navigateTo(AppScreen.DISCUSSIONS)
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Settings, null, tint = NexCyan) },
                                    text = { Text("5. Paramètres") },
                                    onClick = {
                                        showThreeDotsMenu = false
                                        viewModel.navigateTo(AppScreen.SETTINGS_GENERAL)
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.ContactSupport, null, tint = NexCyan) },
                                    text = { Text("6. Aide et assistance") },
                                    onClick = {
                                        showThreeDotsMenu = false
                                        viewModel.navigateTo(AppScreen.SUPPORT_CENTER)
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.ReportProblem, null, tint = NexCyan) },
                                    text = { Text("7. Signaler un problème") },
                                    onClick = {
                                        showThreeDotsMenu = false
                                        viewModel.openReportDialog(ReportEntityType.USER_ACCOUNT, "problem_report")
                                    }
                                )


                                HorizontalDivider()
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Default.Logout, null, tint = MaterialTheme.colorScheme.error) },
                                    text = { Text("Déconnexion", color = MaterialTheme.colorScheme.error) },
                                    onClick = {
                                        showThreeDotsMenu = false
                                        viewModel.logout()
                                    }
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                )
            }
        },
        bottomBar = {
            // Lower navigation bar with 6 core tabs: Chats, Vidéos, Statuts, Lives, AI, Profil
            if (selectedConversationId == null && selectedLiveId == null && activeCall == null && isMainTab) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    windowInsets = WindowInsets.navigationBars
                ) {
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.DISCUSSIONS,
                        onClick = { viewModel.navigateTo(AppScreen.DISCUSSIONS) },
                        icon = { Icon(Icons.Default.Chat, contentDescription = "Chats") },
                        label = { Text("Chats", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NexCyan,
                            indicatorColor = NexElectricBlue.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("nav_discussions")
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppScreen.VIDEOS,
                        onClick = { viewModel.navigateTo(AppScreen.VIDEOS) },
                        icon = { Icon(Icons.Default.PlayCircle, contentDescription = "Vidéos") },
                        label = { Text("Vidéos", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NexCyan,
                            indicatorColor = NexElectricBlue.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("nav_videos")
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppScreen.STATUS,
                        onClick = { viewModel.navigateTo(AppScreen.STATUS) },
                        icon = { Icon(Icons.Default.Schedule, contentDescription = "Statuts") },
                        label = { Text("Statuts", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NexCyan,
                            indicatorColor = NexElectricBlue.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("nav_status")
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppScreen.LIVES,
                        onClick = { viewModel.navigateTo(AppScreen.LIVES) },
                        icon = { Icon(Icons.Default.LiveTv, contentDescription = "Lives") },
                        label = { Text("Lives", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NexCyan,
                            indicatorColor = NexElectricBlue.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("nav_lives")
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppScreen.AI_ASSISTANT,
                        onClick = { viewModel.navigateTo(AppScreen.AI_ASSISTANT) },
                        icon = { Icon(Icons.Default.SmartToy, contentDescription = "NexChat AI") },
                        label = { Text("AI", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NexCyan,
                            indicatorColor = NexElectricBlue.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("nav_ai")
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppScreen.CHANNELS,
                        onClick = { viewModel.navigateTo(AppScreen.CHANNELS) },
                        icon = { Icon(Icons.Default.RssFeed, contentDescription = "Chaînes") },
                        label = { Text("Chaînes", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NexCyan,
                            indicatorColor = NexElectricBlue.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("nav_channels")
                    )
                }
            }
        },
        floatingActionButton = {}
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.DISCUSSIONS -> DiscussionsScreen(
                    conversations = conversations,
                    messages = messages,
                    currentUser = currentUser,
                    selectedConversationId = selectedConversationId,
                    managedUsers = managedUsers,
                    onSelectConversation = { viewModel.openConversation(it) },
                    onBackToList = { viewModel.closeConversation() },
                    onSendMessage = { convId, text -> viewModel.sendChatMessage(convId, text) },
                    onSendVoiceNote = { convId, duration -> viewModel.sendVoiceNote(convId, duration) },
                    onSendMessageWithReply = { convId, text, snippet -> viewModel.sendMessageWithReply(convId, text, snippet) },
                    onToggleReaction = { msgId, emoji -> viewModel.toggleMessageReaction(msgId, emoji) },
                    onStartCall = { contactName, type -> viewModel.startCall(contactName, type) },
                    onReportTarget = { entityType, entityId -> viewModel.openReportDialog(entityType, entityId) },
                    onOpenAiAssistant = { viewModel.navigateTo(AppScreen.AI_ASSISTANT) },
                    onStartNewChatWithUser = { user -> viewModel.openConversation("conv_" + user.username) },
                    onSendMediaMessage = { convId, text, type, url, name, size, isViewOnce ->
                        viewModel.sendMediaMessage(convId, text, type, url, name, size, isViewOnce)
                    },
                    onMarkMessageViewed = { msgId -> viewModel.markMessageViewed(msgId) },
                    onToggleBlockUser = { targetUser -> viewModel.toggleBlockUser(targetUser) }
                )

                AppScreen.VIDEOS -> VideosScreen(
                    videos = videoPosts,
                    currentUser = currentUser,
                    onToggleLike = { vidId -> viewModel.toggleLikeVideo(vidId) },
                    onAddComment = { vidId, text -> viewModel.addVideoComment(vidId, text) },
                    onPublishVideo = { caption -> viewModel.publishVideo(caption) },
                    onReportVideo = { vidId -> viewModel.openReportDialog(ReportEntityType.SHARED_CONTENT, vidId) }
                )

                AppScreen.STATUS -> StatusScreen(
                    stories = stories,
                    currentUser = currentUser,
                    onPostStory = { caption, gradIdx, mediaType, mediaUrl -> viewModel.repository.postStory(caption, gradIdx, mediaType, mediaUrl) },
                    onReportStory = { id -> viewModel.openReportDialog(ReportEntityType.STATUS_STORY, id) }
                )

                AppScreen.LIVES -> LiveScreen(
                    lives = lives,
                    comments = liveComments,
                    currentUser = currentUser,
                    selectedLiveId = selectedLiveId,
                    onSelectLive = { viewModel.openLive(it) },
                    onBackToList = { viewModel.closeLive() },
                    onSendComment = { liveId, comment -> viewModel.sendLiveComment(liveId, comment) },
                    onReportLive = { liveId -> viewModel.openReportDialog(ReportEntityType.SHARED_CONTENT, liveId) }
                )

                AppScreen.AI_ASSISTANT -> NexChatAiScreen(
                    messages = aiMessages,
                    isLoading = isAiLoading,
                    streamingText = streamingAiText,
                    currentProvider = viewModel.aiProvider,
                    onSendMessage = { prompt -> viewModel.sendAiPrompt(prompt) },
                    onClearHistory = { viewModel.clearAiHistory() },
                    onSelectProvider = { p -> viewModel.setAiProvider(p) },
                    onNavigateToRules = { viewModel.navigateTo(AppScreen.RULES) },
                    onNavigateToAppeal = { viewModel.openAppealDialog() },
                    onNavigateToSupport = { viewModel.navigateTo(AppScreen.SUPPORT_CENTER) }
                )

                AppScreen.CHANNELS -> ChannelsScreen(
                    currentUser = currentUser,
                    onReportChannel = { id -> viewModel.openReportDialog(ReportEntityType.GROUP, id) }
                )

                // Sub-screens opened directly from the 3 dots (⋮) menu & Settings hub:
                AppScreen.SETTINGS_GENERAL -> SettingsMainScreen(
                    user = currentUser,
                    connectedSessions = connectedSessions,
                    onNavigateToAccount = { viewModel.navigateTo(AppScreen.ACCOUNT_DETAILS) },
                    onNavigateToPrivacy = { viewModel.navigateTo(AppScreen.PRIVACY_SECURITY) },
                    onNavigateToNotifications = { viewModel.navigateTo(AppScreen.NOTIFICATIONS_SETTINGS) },
                    onNavigateToPersonalization = { viewModel.navigateTo(AppScreen.PERSONALIZATION_SETTINGS) },
                    onNavigateToDiscussions = { viewModel.navigateTo(AppScreen.DISCUSSIONS_SETTINGS) },
                    onNavigateToConnectedDevices = { viewModel.navigateTo(AppScreen.CALLS) },
                    onNavigateToSupport = { viewModel.navigateTo(AppScreen.SUPPORT_CENTER) },
                    onBack = { viewModel.handleBack() }
                )

                AppScreen.ACCOUNT_DETAILS -> AccountDetailsScreen(
                    user = currentUser,
                    onBack = { viewModel.handleBack() },
                    onUpdateProfileDetails = { avatarUrl, bio ->
                        viewModel.updateProfileDetails(avatarUrl, bio)
                    }
                )

                AppScreen.PROFILE_SETTINGS -> ProfileSettingsScreen(
                    currentUser = currentUser,
                    connectedSessions = connectedSessions,
                    onOpenAppealDialog = { viewModel.openAppealDialog() },
                    onNavigateToRules = { viewModel.navigateTo(AppScreen.RULES) },
                    onNavigateToSupport = { viewModel.navigateTo(AppScreen.SUPPORT_CENTER) },
                    onNavigateToModDashboard = { viewModel.navigateTo(AppScreen.MODERATOR_DASHBOARD) },
                    onDisconnectSession = { sessionId -> viewModel.repository.disconnectSession(sessionId) },
                    onTestAccountStatus = { status, reason -> viewModel.testAccountStatus(status, reason) },
                    onExportPersonalData = { viewModel.repository.exportPersonalData() },
                    onDeleteAccount = { viewModel.repository.requestAccountDeletion() },
                    onUpdateProfileDetails = { avatarUrl, bio ->
                        viewModel.updateProfileDetails(avatarUrl, bio)
                    }
                )

                AppScreen.PRIVACY_SECURITY -> PrivacySecurityScreen(
                    user = currentUser,
                    onBack = { viewModel.handleBack() },
                    onToggleBlockUser = { targetUser -> viewModel.toggleBlockUser(targetUser) }
                )

                AppScreen.NOTIFICATIONS_SETTINGS -> NotificationsSettingsScreen(
                    onBack = { viewModel.handleBack() }
                )

                AppScreen.PERSONALIZATION_SETTINGS -> PersonalizationSettingsScreen(
                    user = currentUser,
                    onBack = { viewModel.handleBack() },
                    onUpdateTheme = { a, s, w -> viewModel.repository.updatePersonalization(a, s, w) },
                    onUpdateThemeMode = { mode -> viewModel.updateThemeMode(mode) }
                )

                AppScreen.DISCUSSIONS_SETTINGS -> DiscussionsSettingsScreen(
                    onBack = { viewModel.handleBack() }
                )

                AppScreen.RULES -> RulesScreen(
                    user = currentUser,
                    onAcceptTermsClick = { viewModel.setShowTermsModal(true) }
                )

                AppScreen.ACCOUNT_STATUS_DETAIL -> AccountStatusDetailScreen(
                    user = currentUser,
                    actionHistory = moderationActions,
                    onBack = { viewModel.handleBack() },
                    onOpenAppeal = { viewModel.openAppealDialog() }
                )

                AppScreen.NEXCHAT_PRO -> NexChatProScreen(
                    user = currentUser,
                    plans = dynamicConfig.proPlans,
                    transactions = proTransactions,
                    onBack = { viewModel.handleBack() },
                    onSubscribe = { planId -> viewModel.subscribeToPro(planId) },
                    onToggleAutoRenew = { viewModel.toggleProAutoRenew() }
                )

                AppScreen.SUPPORT_CENTER -> SupportCenterScreen(
                    currentUser = currentUser,
                    tickets = supportTickets,
                    onSubmitTicket = { email, cat, dev, desc ->
                        viewModel.submitSupportTicket(email, cat, dev, desc)
                    }
                )

                AppScreen.REPORT_PROBLEM -> SupportCenterScreen(
                    currentUser = currentUser,
                    tickets = supportTickets,
                    onSubmitTicket = { email, cat, dev, desc ->
                        viewModel.submitSupportTicket(email, cat, dev, desc)
                    }
                )

                AppScreen.ABOUT_NEXCHAT -> AboutNexChatScreen(
                    currentUserRole = currentUser.role,
                    onBack = { viewModel.handleBack() }
                )

                AppScreen.SUPER_ADMIN_PANEL -> {
                    if (!currentUser.role.canEditConfig) {
                        AccessDeniedScreen(
                            requiredRole = "Super Administrateur / Administrateur",
                            currentUser = currentUser,
                            onBack = { viewModel.handleBack() },
                            onSwitchRole = { role -> viewModel.switchUserRole(role) }
                        )
                    } else {
                        SuperAdminPanelScreen(
                            currentUser = currentUser,
                            dynamicConfig = dynamicConfig,
                            moderationCases = moderationCases,
                            moderationActions = moderationActions,
                            auditLogs = auditLogs,
                            managedUsers = managedUsers,
                            connectedSessions = connectedSessions,
                            onDisconnectSession = { sessionId -> viewModel.repository.disconnectSession(sessionId) },
                            onExportLogs = { format -> viewModel.exportAuditLogs(format) },
                            onFeedback = { msg -> viewModel.emitNotification(msg) },
                            onBack = { viewModel.handleBack() },
                            onUpdateAntiSpam = { maxI, win, hours -> viewModel.updateAntiSpamThresholds(maxI, win, hours) },
                            onUpdateAnnouncement = { text, banner -> viewModel.updateAnnouncement(text, banner) },
                            onUpdateGeneralSettings = { email, maxMb, e2ee, maint -> viewModel.updateGeneralSettings(email, maxMb, e2ee, maint) },
                            onUpdateProPrice = { planId, p, fmt -> viewModel.updateProPlanPrice(planId, p, fmt) },
                            onIssueWarning = { target, reason -> viewModel.issueWarningWithFeedback(target, "super_admin_manual", reason) },
                            onApplySuspension = { target, days, reason -> viewModel.applySuspensionWithFeedback(target, "super_admin_manual", days, reason) },
                            onApplyPermanentBan = { target, reason -> viewModel.applyPermanentBanWithFeedback(target, "super_admin_manual", reason) },
                            onLiftSanction = { target, reason -> viewModel.liftSanctionWithFeedback(target, "direct", reason) }
                        )
                    }
                }

                AppScreen.CALLS -> CallsScreen(
                    callLogs = callLogs,
                    onStartCall = { name, type -> viewModel.startCall(name, type) }
                )

                AppScreen.COMMUNITIES -> CommunitiesScreen(
                    communities = communities,
                    currentUser = currentUser,
                    onReportCommunity = { comId -> viewModel.openReportDialog(ReportEntityType.GROUP, comId) },
                    onStartChatWithUser = { user -> viewModel.openConversation("conv_" + user.username) }
                )

                AppScreen.MODERATOR_DASHBOARD -> {
                    if (!currentUser.role.canModerate) {
                        AccessDeniedScreen(
                            requiredRole = "Modérateur / Administrateur",
                            currentUser = currentUser,
                            onBack = { viewModel.handleBack() },
                            onSwitchRole = { role -> viewModel.switchUserRole(role) }
                        )
                    } else {
                        ModeratorDashboardScreen(
                            currentUser = currentUser,
                            cases = moderationCases,
                            actions = moderationActions,
                            restrictions = activeRestrictions,
                            appeals = appeals,
                            auditLogs = auditLogs,
                            managedUsers = managedUsers,
                            onExportLogs = { format -> viewModel.exportAuditLogs(format) },
                            onFeedback = { msg -> viewModel.emitNotification(msg) },
                            onIssueWarning = { targetUser, caseId, reason ->
                                viewModel.issueWarningWithFeedback(targetUser, caseId, reason)
                            },
                            onApplyRestriction = { targetUser, caseId, features, days, reason ->
                                viewModel.repository.applyRestriction(targetUser, caseId, features, days, reason, currentUser.username)
                            },
                            onApplySuspension = { targetUser, caseId, days, reason ->
                                viewModel.applySuspensionWithFeedback(targetUser, caseId, days, reason)
                            },
                            onApplyPermanentBan = { targetUser, caseId, reason ->
                                viewModel.applyPermanentBanWithFeedback(targetUser, caseId, reason)
                            },
                            onLiftSanction = { targetUser, actionId, reason ->
                                viewModel.liftSanctionWithFeedback(targetUser, actionId, reason)
                            },
                            onProcessAppeal = { appealId, approve, reason ->
                                viewModel.repository.processAppeal(appealId, approve, reason, currentUser.username)
                            },
                            onSwitchRole = { role -> viewModel.switchUserRole(role) },
                            onUpdateUserRole = { targetUserId, newRole ->
                                viewModel.updateUserRole(targetUserId, newRole)
                            }
                        )
                    }
                }
            }
        }
    }

    // Modal: Terms Acceptance
    if (showTermsModal) {
        TermsAcceptanceModal(
            userId = currentUser.userId,
            onAccept = { viewModel.acceptTerms() },
            onDismiss = { viewModel.setShowTermsModal(false) }
        )
    }

    // Modal: Content / User Report
    if (reportTarget != null) {
        val (entityType, entityId) = reportTarget!!
        ReportDialog(
            targetType = entityType,
            targetId = entityId,
            onSubmitReport = { reason, comment -> viewModel.submitReport(reason, comment) },
            onDismiss = { viewModel.closeReportDialog() }
        )
    }

    // Modal: Appeal Submission
    if (isAppealDialogOpen) {
        AppealDialog(
            user = currentUser,
            onSubmitAppeal = { explanation -> viewModel.submitAppeal(explanation) },
            onDismiss = { viewModel.closeAppealDialog() }
        )
    }

    // Overlay: Active Call
    if (activeCall != null) {
        ActiveCallOverlay(
            activeCall = activeCall!!,
            onToggleMute = { viewModel.toggleCallMute() },
            onToggleVideo = { viewModel.toggleCallVideo() },
            onUpdateDuration = { duration -> viewModel.updateCallDuration(duration) },
            onEndCall = { viewModel.endCall() }
        )
    }
}
