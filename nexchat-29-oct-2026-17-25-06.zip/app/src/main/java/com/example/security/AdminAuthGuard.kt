package com.example.security

import com.example.model.UserProfile
import com.example.model.UserRole

/**
 * Result wrapper for administrative operations executed by the backend/repository.
 * Enforces server-side authorization and validation.
 */
sealed class AdminOperationResult<out T> {
    data class Success<out T>(
        val data: T,
        val message: String = "Opération exécutée avec succès"
    ) : AdminOperationResult<T>()

    data class Unauthorized(
        val errorCode: String = "ERR_403_FORBIDDEN",
        val message: String,
        val requiredPermission: String,
        val callerRole: UserRole
    ) : AdminOperationResult<Nothing>()

    data class ValidationError(
        val field: String,
        val message: String
    ) : AdminOperationResult<Nothing>()

    fun isSuccess(): Boolean = this is Success
}

/**
 * Server-Side Admin Authentication and Authorization Guard.
 * Protects all administrative endpoints, routes, and mutations.
 */
object AdminAuthGuard {

    /**
     * Verifies whether the specified caller has the required permission for the administrative task.
     * Evaluated server-side in the repository layer, preventing bypass via UI.
     */
    fun hasPermission(user: UserProfile, requiredPermission: String): Boolean {
        return when (requiredPermission) {
            "canModerate" -> user.role.canModerate
            "canManageUsers" -> user.role.canManageUsers
            "canEditConfig" -> user.role.canEditConfig
            "canManageBilling" -> user.role.canManageBilling
            "canViewAuditLogs" -> user.role.canViewAuditLogs
            else -> false
        }
    }

    /**
     * Enforces the permission check, returning a typed Unauthorized result if the check fails.
     */
    fun <T> guard(
        caller: UserProfile,
        requiredPermission: String,
        actionName: String,
        onUnauthorizedLog: () -> Unit = {},
        block: () -> AdminOperationResult<T>
    ): AdminOperationResult<T> {
        if (!hasPermission(caller, requiredPermission)) {
            onUnauthorizedLog()
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé : Le rôle ${caller.role.displayName} ne dispose pas de la permission requise '$requiredPermission' pour exécuter l'action '$actionName'.",
                requiredPermission = requiredPermission,
                callerRole = caller.role
            )
        }
        return block()
    }

    /**
     * Sanitizes secret keys, tokens, or credentials so they are never exposed in UI or logs.
     */
    fun maskSecret(secret: String?): String {
        if (secret.isNullOrBlank()) return "[AUCUN]"
        if (secret.length <= 6) return "******"
        return secret.take(3) + "••••••••" + secret.takeLast(3)
    }
}
