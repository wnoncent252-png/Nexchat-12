package com.example.security

import com.example.model.AccountStatus
import com.example.model.ServerAntiSpamConfig
import com.example.model.UserProfile
import java.util.concurrent.ConcurrentHashMap

data class RateLimitDecision(
    val allowed: Boolean,
    val isSpamDetected: Boolean = false,
    val sanctionApplied: AccountStatus? = null,
    val durationMillis: Long? = null,
    val reason: String? = null,
    val userNotice: String? = null
)

/**
 * Server-Side Rate Limiter & Anti-Spam Detection Engine.
 * Implements sliding window burst tracking, repeated content hash analysis,
 * and progressive sanction tier escalation (Avertissement -> Suspension 24h -> Suspension 7j).
 */
class NexChatRateLimiter {

    // History of sent messages per user: (timestamp, normalized text)
    private val userMessageHistory = ConcurrentHashMap<String, MutableList<Pair<Long, String>>>()

    // History of generic API requests per user: timestamp list
    private val userRequestHistory = ConcurrentHashMap<String, MutableList<Long>>()

    /**
     * Evaluates message dispatch against anti-spam and burst limits.
     * Enforces the 3-tier progressive sanction model:
     * - 1ère infraction : Avertissement officiel
     * - 2ème infraction (récidive rapide) : Restriction / Suspension 24 heures
     * - 3ème infraction ou récidive après vérification : Suspension 7 jours
     */
    fun evaluateMessage(
        user: UserProfile,
        text: String,
        config: ServerAntiSpamConfig
    ): RateLimitDecision {
        val now = System.currentTimeMillis()
        val userId = user.userId
        val windowLimit = now - (config.timeWindowSeconds * 1000L)

        val history = userMessageHistory.computeIfAbsent(userId) { mutableListOf() }
        synchronized(history) {
            history.removeAll { it.first < windowLimit }
            history.add(Pair(now, text.trim()))

            val identicalCount = history.count { it.second.equals(text.trim(), ignoreCase = true) }
            val burstCount = history.size

            val isIdenticalSpam = identicalCount >= config.maxIdenticalMessages
            val isBurstFlood = burstCount > config.burstMessageThreshold

            if (!isIdenticalSpam && !isBurstFlood) {
                return RateLimitDecision(allowed = true)
            }

            // Spam or excessive rate detected! Determine progressive tier:
            val currentWarnings = user.warningCount

            return when {
                // Tier 3/4: Récidive grave après suspension 24h préalable -> Suspension 7 jours
                currentWarnings >= 2 -> {
                    val duration7Days = 7 * 86400 * 1000L
                    RateLimitDecision(
                        allowed = false,
                        isSpamDetected = true,
                        sanctionApplied = AccountStatus.PERMANENTLY_BANNED,
                        durationMillis = duration7Days,
                        reason = "Violations répétées des règles anti-spam après suspension 24h préalable (Seuils: $identicalCount msg identiques / $burstCount en rafale).",
                        userNotice = "Protection Anti-Spam (Niveau 4) : Votre compte fait l'objet d'une suspension de 7 jours suite à des envois massifs répétés. Vous pouvez déposer un recours depuis l'état de votre compte."
                    )
                }

                // Tier 2: Deuxième infraction -> Suspension temporaire de 24 heures
                currentWarnings == 1 -> {
                    val duration24Hours = 24 * 3600 * 1000L
                    RateLimitDecision(
                        allowed = false,
                        isSpamDetected = true,
                        sanctionApplied = AccountStatus.TEMPORARILY_SUSPENDED,
                        durationMillis = duration24Hours,
                        reason = "Envoi excessif de messages répétés ou spam en rafale dans une fenêtre de ${config.timeWindowSeconds}s.",
                        userNotice = "Protection Anti-Spam (Niveau 3) : Suspension temporaire de 24 heures appliquée. Les fonctionnalités d'envoi sont suspendues jusqu'à expiration du délai ou décision sur recours."
                    )
                }

                // Tier 1: Première infraction -> Avertissement officiel
                else -> {
                    RateLimitDecision(
                        allowed = false,
                        isSpamDetected = true,
                        sanctionApplied = AccountStatus.WARNING,
                        durationMillis = null,
                        reason = "Détection d'envois rapprochés ou identiques non conformes au règlement NEXCHAT.",
                        userNotice = "Avertissement Anti-Spam (Niveau 1) : Vous envoyez des messages trop rapidement ou de manière répétitive. Veuillez espacer vos envois. En cas de récidive, une suspension de 24 heures sera appliquée."
                    )
                }
            }
        }
    }

    /**
     * General API request rate limiter (Sliding Window per Minute).
     */
    fun evaluateApiRequest(
        userId: String,
        maxPerMinute: Int
    ): Boolean {
        val now = System.currentTimeMillis()
        val oneMinuteAgo = now - 60000L

        val reqs = userRequestHistory.computeIfAbsent(userId) { mutableListOf() }
        synchronized(reqs) {
            reqs.removeAll { it < oneMinuteAgo }
            if (reqs.size >= maxPerMinute) {
                return false
            }
            reqs.add(now)
            return true
        }
    }

    /**
     * Resets rate limiter memory for a specific user upon administrator pardon or sanction lift.
     */
    fun clearUserHistory(userId: String) {
        userMessageHistory.remove(userId)
        userRequestHistory.remove(userId)
    }
}
