package com.example.repository

import com.example.model.*
import com.example.security.AdminAuthGuard
import com.example.security.AdminOperationResult
import com.example.security.NexChatRateLimiter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.random.Random

class NexChatRepository {

    // Server-Side Rate Limiter & Anti-Spam Engine
    val rateLimiter = NexChatRateLimiter()

    // Current User Profile State
    private val _currentUser = MutableStateFlow(
        UserProfile(
            userId = "usr_948291",
            username = "hector_sec",
            displayName = "Hector Gilberson",
            email = "hectorgilberson7@gmail.com",
            phone = "+33 6 82 91 00 12",
            bio = "Ingénieur passionné de sécurité et d'écosystèmes temps réel ⚡",
            status = AccountStatus.ACTIVE,
            role = UserRole.SUPER_ADMIN,
            warningCount = 0,
            termsAcceptance = TermsAcceptanceRecord(
                userId = "usr_948291",
                rulesVersion = NexChatOfficialRules.CURRENT_VERSION,
                acceptedAt = System.currentTimeMillis() - 86400000L * 30,
                lastUpdated = System.currentTimeMillis() - 86400000L * 30
            ),
            isProSubscriber = true,
            proBadge = "VIP PRO ⚡"
        )
    )
    val currentUser: StateFlow<UserProfile> = _currentUser.asStateFlow()

    // Directory of Managed Users in the Platform (Search & Administration)
    private val _managedUsers = MutableStateFlow<List<UserProfile>>(createInitialManagedUsers())
    val managedUsers: StateFlow<List<UserProfile>> = _managedUsers.asStateFlow()

    // Login status
    private val _isUserLoggedIn = MutableStateFlow(true)
    val isUserLoggedIn: StateFlow<Boolean> = _isUserLoggedIn.asStateFlow()

    // Dynamic Remote Configuration (modifié par le Super Admin sans casser l'APK)
    private val _dynamicConfig = MutableStateFlow(RemoteDynamicConfig())
    val dynamicConfig: StateFlow<RemoteDynamicConfig> = _dynamicConfig.asStateFlow()

    // Pro Transactions History
    private val _proTransactions = MutableStateFlow<List<ProTransactionRecord>>(
        listOf(
            ProTransactionRecord(
                transactionId = "tx_918290",
                planId = "pro_annual",
                planName = "NexChat Pro Annuel",
                amountFormatted = "39,99 €",
                timestamp = System.currentTimeMillis() - 86400000L * 15,
                status = "CONFIRMED",
                invoiceNumber = "INV-NEX-2026-9182"
            )
        )
    )
    val proTransactions: StateFlow<List<ProTransactionRecord>> = _proTransactions.asStateFlow()

    // Active Restrictions on Users
    private val _activeRestrictions = MutableStateFlow<List<UserRestriction>>(emptyList())
    val activeRestrictions: StateFlow<List<UserRestriction>> = _activeRestrictions.asStateFlow()

    // Moderation Cases (The Queue for Trust & Safety)
    private val _moderationCases = MutableStateFlow<List<ModerationCase>>(createInitialCases())
    val moderationCases: StateFlow<List<ModerationCase>> = _moderationCases.asStateFlow()

    // Moderation Actions Applied
    private val _moderationActions = MutableStateFlow<List<ModerationAction>>(createInitialActions())
    val moderationActions: StateFlow<List<ModerationAction>> = _moderationActions.asStateFlow()

    // Appeals
    private val _appeals = MutableStateFlow<List<Appeal>>(createInitialAppeals())
    val appeals: StateFlow<List<Appeal>> = _appeals.asStateFlow()

    // Moderation Audit Logs
    private val _auditLogs = MutableStateFlow<List<ModerationAuditLog>>(createInitialAuditLogs())
    val auditLogs: StateFlow<List<ModerationAuditLog>> = _auditLogs.asStateFlow()

    // Reports submitted by users
    private val _userReports = MutableStateFlow<List<UserReport>>(emptyList())
    val userReports: StateFlow<List<UserReport>> = _userReports.asStateFlow()

    // Connected Sessions
    private val _connectedSessions = MutableStateFlow(
        listOf(
            ConnectedDeviceSession("sess_01", "Pixel 9 Pro (Cet appareil)", "Android 15", "Paris, France", "194.254.12.98", System.currentTimeMillis(), isCurrent = true),
            ConnectedDeviceSession("sess_02", "NexChat Web Client (Chrome)", "Web", "Lyon, France", "82.64.110.22", System.currentTimeMillis() - 3600000L * 4),
            ConnectedDeviceSession("sess_03", "MacBook Pro M3 Desktop", "Desktop", "Paris, France", "194.254.12.98", System.currentTimeMillis() - 86400000L * 2)
        )
    )
    val connectedSessions: StateFlow<List<ConnectedDeviceSession>> = _connectedSessions.asStateFlow()

    // Support Tickets
    private val _supportTickets = MutableStateFlow<List<SupportTicket>>(createInitialTickets())
    val supportTickets: StateFlow<List<SupportTicket>> = _supportTickets.asStateFlow()

    // Messaging & Social Data
    private val _conversations = MutableStateFlow(createInitialConversations())
    val conversations: StateFlow<List<Conversation>> = _conversations.asStateFlow()

    private val _messages = MutableStateFlow(createInitialMessages())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    // Video Posts (Separate from Lives)
    private val _videoPosts = MutableStateFlow(createInitialVideoPosts())
    val videoPosts: StateFlow<List<VideoPost>> = _videoPosts.asStateFlow()

    private val _stories = MutableStateFlow(createInitialStories())
    val stories: StateFlow<List<StatusStory>> = _stories.asStateFlow()

    private val _lives = MutableStateFlow(createInitialLives())
    val lives: StateFlow<List<LiveStream>> = _lives.asStateFlow()

    private val _liveComments = MutableStateFlow(createInitialLiveComments())
    val liveComments: StateFlow<List<LiveComment>> = _liveComments.asStateFlow()

    private val _callLogs = MutableStateFlow(createInitialCallLogs())
    val callLogs: StateFlow<List<CallRecord>> = _callLogs.asStateFlow()

    private val _communities = MutableStateFlow(createInitialCommunities())
    val communities: StateFlow<List<CommunityItem>> = _communities.asStateFlow()

    // In-memory anti-spam tracker (Timestamp, Content)
    private val sentMessageHistory = mutableListOf<Pair<Long, String>>()

    init {
        checkAndAutoExpireSanctions()
    }

    // --- Auto Expiration of 24h Suspensions and 7-Day Bans ---
    fun checkAndAutoExpireSanctions() {
        val user = _currentUser.value
        val now = System.currentTimeMillis()
        if (user.restrictionEndDate != null && now >= user.restrictionEndDate) {
            // Sanction has naturally expired!
            _currentUser.value = user.copy(
                status = AccountStatus.ACTIVE,
                currentRestrictionReason = null,
                restrictionStartDate = null,
                restrictionEndDate = null
            )
            _activeRestrictions.value = _activeRestrictions.value.filterNot { it.user == user.username }
            logAudit(
                actionType = "AUTO_EXPIRED_SANCTION_LIFTED",
                targetUser = user.username,
                admin = "SYSTEM_SERVER_TIMER",
                reason = "Durée de sanction écoulée. Rétablissement automatique de l'accès.",
                caseId = null
            )
        }
    }

    // --- Terms Acceptance ---
    fun acceptTerms(userId: String) {
        val now = System.currentTimeMillis()
        val record = TermsAcceptanceRecord(
            userId = userId,
            rulesVersion = NexChatOfficialRules.CURRENT_VERSION,
            acceptedAt = now,
            lastUpdated = now
        )
        _currentUser.value = _currentUser.value.copy(termsAcceptance = record)
    }

    // --- Auth & User State ---
    fun login(email: String, displayName: String, username: String) {
        _currentUser.value = _currentUser.value.copy(
            email = email,
            displayName = displayName,
            username = username,
            status = AccountStatus.ACTIVE
        )
        _isUserLoggedIn.value = true
    }

    fun logout() {
        _isUserLoggedIn.value = false
    }

    fun setUserRole(role: UserRole) {
        _currentUser.value = _currentUser.value.copy(role = role)
    }

    fun setUserAccountStatus(status: AccountStatus, reason: String? = null, durationMillis: Long? = null) {
        val now = System.currentTimeMillis()
        val endDate = if (durationMillis != null) now + durationMillis else null
        _currentUser.value = _currentUser.value.copy(
            status = status,
            currentRestrictionReason = reason,
            restrictionStartDate = if (durationMillis != null) now else null,
            restrictionEndDate = endDate
        )
    }

    // --- Feature Permission Checks (Server-Side Enforcement) ---
    fun isFeatureAllowed(user: UserProfile, feature: NexFeature): Pair<Boolean, String?> {
        checkAndAutoExpireSanctions()
        val freshUser = _currentUser.value

        if (freshUser.status == AccountStatus.PERMANENTLY_BANNED) {
            val remaining = freshUser.restrictionEndDate?.let { it - System.currentTimeMillis() } ?: 0L
            val hours = (remaining / 3600000L).coerceAtLeast(0)
            return Pair(false, "Niveau 4 — Bannissement actif ($hours h restantes). Raison : ${freshUser.currentRestrictionReason ?: "Violation grave"}")
        }
        if (freshUser.status == AccountStatus.TEMPORARILY_SUSPENDED) {
            val remaining = freshUser.restrictionEndDate?.let { it - System.currentTimeMillis() } ?: 0L
            val hours = (remaining / 3600000L).coerceAtLeast(0)
            return Pair(false, "Niveau 3 — Suspension anti-spam 24h ($hours h restantes). Raison : ${freshUser.currentRestrictionReason ?: "Spam détecté"}")
        }
        val activeRes = _activeRestrictions.value.filter {
            it.user == freshUser.username || it.user == freshUser.userId
        }
        for (restriction in activeRes) {
            if (restriction.affected_features.contains(feature)) {
                return Pair(false, "Fonctionnalité restreinte : ${restriction.reason}")
            }
        }
        return Pair(true, null)
    }

    // --- Message Sending with Anti-Spam Detection ---
    fun sendMessage(conversationId: String, text: String, isViewOnce: Boolean = false): Pair<Boolean, String?> {
        checkAndAutoExpireSanctions()
        val user = _currentUser.value
        val (allowed, errorMsg) = isFeatureAllowed(user, NexFeature.SEND_MESSAGES)
        if (!allowed) return Pair(false, errorMsg)

        val conv = _conversations.value.find { it.id == conversationId }
        if (conv != null && isUserBlocked(conv.title)) {
            return Pair(false, "Cet utilisateur est bloqué. Débloquez-le pour lui envoyer un message.")
        }

        // Run Anti-Spam Detection Engine
        val spamResult = runAntiSpamCheck(text)
        if (spamResult != null) {
            return Pair(false, spamResult)
        }

        val msg = ChatMessage(
            id = "msg_" + UUID.randomUUID().toString().take(8),
            conversationId = conversationId,
            senderId = user.userId,
            senderName = user.displayName,
            text = text,
            timestamp = System.currentTimeMillis(),
            isFromMe = true,
            status = MessageStatus.SENT,
            isEncrypted = true,
            isViewOnce = isViewOnce,
            isViewed = false
        )
        _messages.value = _messages.value + msg

        val displayPreview = if (isViewOnce) "① Message vue unique" else text
        _conversations.value = _conversations.value.map {
            if (it.id == conversationId) it.copy(lastMessage = displayPreview, lastMessageTime = "À l'instant") else it
        }
        return Pair(true, null)
    }

    fun sendMediaMessage(
        conversationId: String,
        text: String,
        mediaType: String, // "IMAGE", "VIDEO", "DOCUMENT"
        mediaUrl: String,
        mediaName: String,
        mediaSize: String,
        isViewOnce: Boolean
    ): Pair<Boolean, String?> {
        checkAndAutoExpireSanctions()
        val user = _currentUser.value
        val (allowed, errorMsg) = isFeatureAllowed(user, NexFeature.SEND_MESSAGES)
        val conv = _conversations.value.find { it.id == conversationId }
        if (conv != null && isUserBlocked(conv.title)) {
            return Pair(false, "Cet utilisateur est bloqué. Débloquez-le pour lui envoyer un média.")
        }

        val previewPrefix = when (mediaType) {
            "IMAGE" -> if (isViewOnce) "① Photo (Vue unique)" else "📷 Photo"
            "VIDEO" -> if (isViewOnce) "① Vidéo (Vue unique)" else "🎥 Vidéo"
            else -> if (isViewOnce) "① Fichier (Vue unique)" else "📁 $mediaName"
        }

        val msg = ChatMessage(
            id = "msg_m_" + UUID.randomUUID().toString().take(8),
            conversationId = conversationId,
            senderId = user.userId,
            senderName = user.displayName,
            text = if (text.isNotBlank()) text else previewPrefix,
            timestamp = System.currentTimeMillis(),
            isFromMe = true,
            status = MessageStatus.SENT,
            mediaType = mediaType,
            mediaUrl = mediaUrl,
            mediaName = mediaName,
            mediaDurationOrSize = mediaSize,
            isEncrypted = true,
            isViewOnce = isViewOnce,
            isViewed = false
        )
        _messages.value = _messages.value + msg

        _conversations.value = _conversations.value.map {
            if (it.id == conversationId) it.copy(lastMessage = previewPrefix, lastMessageTime = "À l'instant") else it
        }
        return Pair(true, null)
    }

    fun markMessageViewed(messageId: String) {
        _messages.value = _messages.value.map { msg ->
            if (msg.id == messageId) {
                msg.copy(isViewed = true)
            } else msg
        }
    }

    fun sendVoiceNote(conversationId: String, durationSeconds: Int): Pair<Boolean, String?> {
        checkAndAutoExpireSanctions()
        val user = _currentUser.value
        val (allowed, errorMsg) = isFeatureAllowed(user, NexFeature.SEND_MESSAGES)
        if (!allowed) return Pair(false, errorMsg)

        val conv = _conversations.value.find { it.id == conversationId }
        if (conv != null && isUserBlocked(conv.title)) {
            return Pair(false, "Cet utilisateur est bloqué. Débloquez-le pour lui envoyer une note vocale.")
        }

        val durationFormatted = String.format(Locale.FRENCH, "%02d:%02d", durationSeconds / 60, durationSeconds % 60)
        val msg = ChatMessage(
            id = "msg_v_" + UUID.randomUUID().toString().take(8),
            conversationId = conversationId,
            senderId = user.userId,
            senderName = user.displayName,
            text = "🎤 Message vocal",
            timestamp = System.currentTimeMillis(),
            isFromMe = true,
            status = MessageStatus.SENT,
            mediaType = "AUDIO",
            mediaDurationOrSize = durationFormatted,
            isEncrypted = true
        )
        _messages.value = _messages.value + msg
        _conversations.value = _conversations.value.map {
            if (it.id == conversationId) it.copy(lastMessage = "🎤 Message vocal ($durationFormatted)", lastMessageTime = "À l'instant") else it
        }
        return Pair(true, null)
    }

    fun sendMessageWithReply(conversationId: String, text: String, repliedSnippet: String): Pair<Boolean, String?> {
        checkAndAutoExpireSanctions()
        val user = _currentUser.value
        val (allowed, errorMsg) = isFeatureAllowed(user, NexFeature.SEND_MESSAGES)
        if (!allowed) return Pair(false, errorMsg)

        val conv = _conversations.value.find { it.id == conversationId }
        if (conv != null && isUserBlocked(conv.title)) {
            return Pair(false, "Cet utilisateur est bloqué. Débloquez-le pour lui envoyer un message.")
        }

        val spamResult = runAntiSpamCheck(text)
        if (spamResult != null) return Pair(false, spamResult)

        val msg = ChatMessage(
            id = "msg_" + UUID.randomUUID().toString().take(8),
            conversationId = conversationId,
            senderId = user.userId,
            senderName = user.displayName,
            text = text,
            timestamp = System.currentTimeMillis(),
            isFromMe = true,
            status = MessageStatus.SENT,
            repliedToSnippet = repliedSnippet,
            isEncrypted = true
        )
        _messages.value = _messages.value + msg
        _conversations.value = _conversations.value.map {
            if (it.id == conversationId) it.copy(lastMessage = text, lastMessageTime = "À l'instant") else it
        }
        return Pair(true, null)
    }

    fun toggleMessageReaction(messageId: String, emoji: String) {
        _messages.value = _messages.value.map { msg ->
            if (msg.id == messageId) {
                val newEmoji = if (msg.reactionEmoji == emoji) null else emoji
                msg.copy(reactionEmoji = newEmoji)
            } else msg
        }
    }

    fun recordCallLog(contactName: String, type: CallType, durationSeconds: Int) {
        val durationFormatted = if (durationSeconds <= 0) "Manqué" else String.format(Locale.FRENCH, "%02d:%02d min", durationSeconds / 60, durationSeconds % 60)
        val newRecord = CallRecord(
            id = "call_" + UUID.randomUUID().toString().take(8),
            contactName = contactName,
            contactId = "user_" + contactName.lowercase(Locale.ROOT).replace(" ", "_"),
            type = type,
            direction = if (durationSeconds > 0) CallDirection.OUTGOING else CallDirection.MISSED,
            durationText = durationFormatted,
            timestamp = System.currentTimeMillis()
        )
        _callLogs.value = listOf(newRecord) + _callLogs.value
    }


    private fun runAntiSpamCheck(text: String): String? {
        val user = _currentUser.value
        val config = _dynamicConfig.value.antiSpamConfig
        val decision = rateLimiter.evaluateMessage(user, text, config)

        if (!decision.allowed) {
            when (decision.sanctionApplied) {
                AccountStatus.WARNING -> {
                    val count = user.warningCount + 1
                    _currentUser.value = user.copy(
                        status = AccountStatus.WARNING,
                        warningCount = count,
                        currentRestrictionReason = decision.reason
                    )
                    logAudit("RATE_LIMIT_WARNING_ISSUED", user.username, "SYSTEM_RATE_LIMITER", decision.reason ?: "Avertissement Anti-Spam", null)
                }
                AccountStatus.TEMPORARILY_SUSPENDED -> {
                    val suspDuration = decision.durationMillis ?: (24 * 3600000L)
                    setUserAccountStatus(
                        status = AccountStatus.TEMPORARILY_SUSPENDED,
                        reason = decision.reason,
                        durationMillis = suspDuration
                    )
                    logAudit("RATE_LIMIT_24H_SUSPENSION", user.username, "SYSTEM_RATE_LIMITER", decision.reason ?: "Suspension 24h", null)
                }
                AccountStatus.PERMANENTLY_BANNED -> {
                    val banDuration = decision.durationMillis ?: (7 * 86400000L)
                    setUserAccountStatus(
                        status = AccountStatus.PERMANENTLY_BANNED,
                        reason = decision.reason,
                        durationMillis = banDuration
                    )
                    logAudit("RATE_LIMIT_7D_SUSPENSION", user.username, "SYSTEM_RATE_LIMITER", decision.reason ?: "Suspension 7 jours", null)
                }
                else -> {
                    _currentUser.value = user.copy(currentRestrictionReason = decision.reason)
                }
            }
            return decision.userNotice
        }
        return null
    }

    // --- Video Posts & Likes Section (Separate from Lives) ---
    fun toggleLikeVideo(videoId: String): Pair<Boolean, Int> {
        val currentUserId = _currentUser.value.userId
        var isNowLiked = false
        var updatedLikesCount = 0

        _videoPosts.value = _videoPosts.value.map { post ->
            if (post.id == videoId) {
                val alreadyLiked = post.likedByUsers.contains(currentUserId)
                val newLikedUsers = if (alreadyLiked) {
                    post.likedByUsers - currentUserId
                } else {
                    post.likedByUsers + currentUserId
                }
                isNowLiked = !alreadyLiked
                updatedLikesCount = if (alreadyLiked) (post.likesCount - 1).coerceAtLeast(0) else post.likesCount + 1
                post.copy(
                    likesCount = updatedLikesCount,
                    likedByUsers = newLikedUsers
                )
            } else {
                post
            }
        }
        return Pair(isNowLiked, updatedLikesCount)
    }

    fun addVideoComment(videoId: String, commentText: String) {
        val user = _currentUser.value
        val comment = VideoComment(
            id = "vc_" + UUID.randomUUID().toString().take(6),
            authorName = user.displayName,
            authorUsername = user.username,
            text = commentText,
            timestamp = System.currentTimeMillis()
        )
        _videoPosts.value = _videoPosts.value.map { post ->
            if (post.id == videoId) {
                post.copy(
                    commentsCount = post.commentsCount + 1,
                    comments = post.comments + comment
                )
            } else {
                post
            }
        }
    }

    fun publishVideo(caption: String, durationText: String = "0:30"): VideoPost {
        val user = _currentUser.value
        val newVideo = VideoPost(
            id = "vid_" + UUID.randomUUID().toString().take(8),
            authorId = user.userId,
            authorName = user.displayName,
            authorUsername = user.username,
            caption = caption,
            videoDurationText = durationText,
            timestamp = System.currentTimeMillis(),
            likesCount = 0,
            likedByUsers = emptySet(),
            commentsCount = 0,
            sharesCount = 0
        )
        _videoPosts.value = listOf(newVideo) + _videoPosts.value
        return newVideo
    }

    // --- NexChat Pro Premium Subscriptions ---
    fun subscribeToPro(planId: String): ProTransactionRecord {
        val plan = _dynamicConfig.value.proPlans.find { it.id == planId }
            ?: _dynamicConfig.value.proPlans.first()
        val now = System.currentTimeMillis()
        val expiry = now + (plan.periodMonths * 30L * 86400000L)
        val invoiceNo = "INV-NEX-" + Random.nextInt(1000, 9999)
        val txId = "tx_" + UUID.randomUUID().toString().take(8)

        val tx = ProTransactionRecord(
            transactionId = txId,
            planId = plan.id,
            planName = plan.name,
            amountFormatted = plan.priceFormatted,
            timestamp = now,
            status = "CONFIRMED",
            invoiceNumber = invoiceNo
        )
        _proTransactions.value = listOf(tx) + _proTransactions.value

        _currentUser.value = _currentUser.value.copy(
            isProSubscriber = true,
            proPlanId = plan.id,
            proExpiryDate = expiry,
            proBadge = "VIP PRO ⚡",
            proAutoRenew = true
        )

        logAudit("PRO_SUBSCRIPTION_ACTIVATED", _currentUser.value.username, "STRIPE_SERVER_PAYMENT", "Abonnement ${plan.name} confirmé", null)
        return tx
    }

    fun toggleProAutoRenew() {
        val current = _currentUser.value.proAutoRenew
        _currentUser.value = _currentUser.value.copy(proAutoRenew = !current)
    }

    fun recordConfigChange(settingKey: String, settingName: String, oldValue: String, newValue: String, modifiedBy: String) {
        val historyItem = DynamicConfigHistoryItem(
            id = "cfg_" + UUID.randomUUID().toString().take(8),
            settingKey = settingKey,
            settingName = settingName,
            oldValue = oldValue,
            newValue = newValue,
            modifiedBy = modifiedBy,
            timestamp = System.currentTimeMillis()
        )
        _dynamicConfig.value = _dynamicConfig.value.copy(
            configHistory = listOf(historyItem) + _dynamicConfig.value.configHistory
        )
    }

    // --- Dynamic Configuration Update (Super Admin without APK rebuild) ---
    fun updateProPlanPrice(
        planId: String,
        newPrice: Double,
        newFormattedPrice: String,
        caller: UserProfile = _currentUser.value
    ): AdminOperationResult<List<NexChatProPlan>> {
        if (!AdminAuthGuard.hasPermission(caller, "canManageBilling") && !AdminAuthGuard.hasPermission(caller, "canEditConfig")) {
            logAudit("UNAUTHORIZED_CONFIG_ATTEMPT", "GLOBAL", caller.username, "Tentative de modification tarifaire non autorisée (Rôle: ${caller.role.name})", null)
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé : Le rôle ${caller.role.displayName} ne dispose pas des privilèges financiers ou d'administration.",
                requiredPermission = "canManageBilling",
                callerRole = caller.role
            )
        }
        if (newPrice < 0.0) {
            return AdminOperationResult.ValidationError("price", "Le tarif ne peut pas être négatif.")
        }

        val currentPlans = _dynamicConfig.value.proPlans
        val targetPlan = currentPlans.find { it.id == planId }
        val oldPriceFormatted = targetPlan?.priceFormatted ?: "N/A"

        val updatedPlans = currentPlans.map {
            if (it.id == planId) it.copy(price = newPrice, priceFormatted = newFormattedPrice) else it
        }
        _dynamicConfig.value = _dynamicConfig.value.copy(
            proPlans = updatedPlans,
            lastUpdatedTimestamp = System.currentTimeMillis()
        )
        logAudit("CONFIG_PRO_PRICE_UPDATED", "GLOBAL", caller.username, "Prix modifié pour $planId : $newFormattedPrice (précédent: $oldPriceFormatted)", null)
        recordConfigChange("pro_plan_$planId", "Tarif $planId", oldPriceFormatted, newFormattedPrice, caller.username)
        return AdminOperationResult.Success(updatedPlans, "Tarif mis à jour sur le serveur.")
    }

    fun updateAntiSpamThresholds(
        maxIdentical: Int,
        timeWindowSeconds: Int,
        tempHours: Int,
        burstThreshold: Int = 5,
        caller: UserProfile = _currentUser.value
    ): AdminOperationResult<ServerAntiSpamConfig> {
        if (!AdminAuthGuard.hasPermission(caller, "canEditConfig")) {
            logAudit("UNAUTHORIZED_CONFIG_ATTEMPT", "GLOBAL", caller.username, "Tentative de modification des seuils anti-spam non autorisée (Rôle: ${caller.role.name})", null)
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé : Le rôle ${caller.role.displayName} ne dispose pas de la permission 'canEditConfig'.",
                requiredPermission = "canEditConfig",
                callerRole = caller.role
            )
        }
        if (maxIdentical < 1 || maxIdentical > 20) {
            return AdminOperationResult.ValidationError("maxIdentical", "Le nombre max de messages identiques doit être compris entre 1 et 20.")
        }
        if (timeWindowSeconds < 5 || timeWindowSeconds > 300) {
            return AdminOperationResult.ValidationError("timeWindowSeconds", "La fenêtre temporelle doit être comprise entre 5 et 300 secondes.")
        }
        if (tempHours < 1 || tempHours > 72) {
            return AdminOperationResult.ValidationError("tempHours", "La durée de restriction temporaire doit être comprise entre 1 et 72 heures.")
        }

        val previous = _dynamicConfig.value.antiSpamConfig
        val updated = previous.copy(
            maxIdenticalMessages = maxIdentical,
            timeWindowSeconds = timeWindowSeconds,
            temporaryRestrictionHours = tempHours,
            burstMessageThreshold = burstThreshold
        )
        _dynamicConfig.value = _dynamicConfig.value.copy(
            antiSpamConfig = updated,
            lastUpdatedTimestamp = System.currentTimeMillis()
        )
        logAudit("CONFIG_ANTI_SPAM_UPDATED", "GLOBAL", caller.username, "Seuils anti-spam mis à jour : max=$maxIdentical en ${timeWindowSeconds}s, restriction=${tempHours}h", null)
        recordConfigChange("antiSpamConfig", "Seuils Anti-Spam", "max=${previous.maxIdenticalMessages}, win=${previous.timeWindowSeconds}s", "max=$maxIdentical, win=${timeWindowSeconds}s", caller.username)
        return AdminOperationResult.Success(updated, "Seuils anti-spam sauvegardés sur le serveur.")
    }

    fun updateAnnouncement(
        announcement: String,
        isBannerEnabled: Boolean,
        caller: UserProfile = _currentUser.value
    ): AdminOperationResult<RemoteDynamicConfig> {
        if (!AdminAuthGuard.hasPermission(caller, "canEditConfig")) {
            logAudit("UNAUTHORIZED_CONFIG_ATTEMPT", "GLOBAL", caller.username, "Tentative de modification de l'annonce non autorisée", null)
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé : Seuls les administrateurs peuvent modifier les annonces globales.",
                requiredPermission = "canEditConfig",
                callerRole = caller.role
            )
        }
        if (announcement.isBlank()) {
            return AdminOperationResult.ValidationError("announcement", "Le texte de l'annonce ne peut pas être vide.")
        }

        val old = _dynamicConfig.value.appAnnouncement
        _dynamicConfig.value = _dynamicConfig.value.copy(
            appAnnouncement = announcement.trim(),
            announcementBannerEnabled = isBannerEnabled,
            lastUpdatedTimestamp = System.currentTimeMillis()
        )
        logAudit("CONFIG_ANNOUNCEMENT_UPDATED", "GLOBAL", caller.username, "Annonce globale mise à jour : ${announcement.take(40)}...", null)
        recordConfigChange("appAnnouncement", "Annonce globale", old, announcement, caller.username)
        return AdminOperationResult.Success(_dynamicConfig.value, "Annonce mise à jour avec succès.")
    }

    fun updateGeneralSettings(
        supportEmail: String,
        maxAttachmentMb: Int,
        e2eeEnforced: Boolean,
        maintenanceMode: Boolean,
        caller: UserProfile = _currentUser.value
    ): AdminOperationResult<RemoteDynamicConfig> {
        if (!AdminAuthGuard.hasPermission(caller, "canEditConfig")) {
            logAudit("UNAUTHORIZED_CONFIG_ATTEMPT", "GLOBAL", caller.username, "Tentative de modification des paramètres généraux non autorisée", null)
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé pour les paramètres généraux.",
                requiredPermission = "canEditConfig",
                callerRole = caller.role
            )
        }
        if (!supportEmail.contains("@") || !supportEmail.contains(".")) {
            return AdminOperationResult.ValidationError("supportEmail", "Format d'adresse e-mail de support invalide.")
        }
        if (maxAttachmentMb !in 10..2000) {
            return AdminOperationResult.ValidationError("maxAttachmentMb", "La taille max de pièce jointe doit être entre 10 et 2000 Mo.")
        }

        val old = "email=${_dynamicConfig.value.supportEmail}, maxMb=${_dynamicConfig.value.maxAttachmentSizeMb}"
        val newConf = _dynamicConfig.value.copy(
            supportEmail = supportEmail.trim(),
            maxAttachmentSizeMb = maxAttachmentMb,
            e2eeEnforced = e2eeEnforced,
            maintenanceMode = maintenanceMode,
            lastUpdatedTimestamp = System.currentTimeMillis()
        )
        _dynamicConfig.value = newConf
        val newStr = "email=$supportEmail, maxMb=$maxAttachmentMb"
        logAudit("CONFIG_GENERAL_UPDATED", "GLOBAL", caller.username, "Paramètres généraux modifiés : $newStr", null)
        recordConfigChange("generalSettings", "Paramètres Généraux", old, newStr, caller.username)
        return AdminOperationResult.Success(newConf, "Paramètres généraux mis à jour.")
    }

    fun updatePersonalization(accentColorHex: Long, secondaryColorHex: Long, wallpaperIndex: Int, themeMode: String = _currentUser.value.personalization.themeMode) {
        val current = _currentUser.value.personalization
        _currentUser.value = _currentUser.value.copy(
            personalization = current.copy(
                primaryAccentColorHex = accentColorHex,
                secondaryNeonColorHex = secondaryColorHex,
                chatWallpaperIndex = wallpaperIndex,
                themeMode = themeMode,
                isDarkTheme = themeMode != "LIGHT"
            )
        )
    }

    fun updateThemeMode(themeMode: String) {
        val current = _currentUser.value.personalization
        _currentUser.value = _currentUser.value.copy(
            personalization = current.copy(
                themeMode = themeMode,
                isDarkTheme = themeMode != "LIGHT"
            )
        )
    }

    fun toggleBlockUser(usernameOrId: String): Boolean {
        val current = _currentUser.value
        val blocked = current.privacySettings.blockedUsers
        val isBlockedNow = blocked.contains(usernameOrId)
        val newBlocked = if (isBlockedNow) blocked - usernameOrId else blocked + usernameOrId
        _currentUser.value = current.copy(
            privacySettings = current.privacySettings.copy(blockedUsers = newBlocked)
        )
        logAudit(
            actionType = if (isBlockedNow) "USER_UNBLOCKED" else "USER_BLOCKED",
            targetUser = usernameOrId,
            admin = current.username,
            reason = if (isBlockedNow) "Utilisateur débloqué" else "Utilisateur bloqué",
            caseId = null
        )
        return !isBlockedNow
    }

    fun isUserBlocked(usernameOrId: String): Boolean {
        return _currentUser.value.privacySettings.blockedUsers.contains(usernameOrId)
    }

    fun updateProfileDetails(avatarUrl: String, bio: String, displayName: String = _currentUser.value.displayName) {
        val updated = _currentUser.value.copy(
            avatarUrl = avatarUrl,
            bio = bio,
            displayName = displayName
        )
        _currentUser.value = updated
        _managedUsers.value = _managedUsers.value.map {
            if (it.userId == updated.userId) updated else it
        }
        logAudit("PROFILE_UPDATED", "USER", updated.username, "Photo de profil et biographie mises à jour.", null)
    }

    // --- Reporting System ---
    fun submitReport(
        reporterId: String,
        entityType: ReportEntityType,
        entityId: String,
        targetUser: String,
        reason: String,
        comment: String
    ): UserReport {
        val riskScore = when (reason) {
            "Menaces", "Contenu interdit" -> 95
            "Fraude", "Usurpation d'identité" -> 88
            "Harcèlement" -> 80
            "Spam" -> 45
            else -> 60
        }
        val isAutoUrgent = riskScore >= 90
        val reportId = "rep_" + UUID.randomUUID().toString().take(8)
        val caseId = "case_" + UUID.randomUUID().toString().take(8)

        val report = UserReport(
            id = reportId,
            reporterId = reporterId,
            entityType = entityType,
            entityId = entityId,
            targetUser = targetUser,
            reason = reason,
            detailedComment = comment,
            riskScore = riskScore,
            isAutoUrgent = isAutoUrgent,
            createdAt = System.currentTimeMillis(),
            relatedCaseId = caseId
        )
        _userReports.value = listOf(report) + _userReports.value

        val newCase = ModerationCase(
            id = caseId,
            user = targetUser,
            violation_type = reason,
            description = "$comment (Signalement sur ${entityType.label})",
            severity = if (isAutoUrgent) Severity.CRITICAL else if (riskScore > 75) Severity.HIGH else Severity.MEDIUM,
            evidence_reference = "ref_evidence_${reportId}",
            detection_source = "SIGNALEMENT_COMMUNAUTAIRE",
            review_status = ReviewStatus.PENDING,
            created_at = System.currentTimeMillis(),
            reporter_user = reporterId
        )
        _moderationCases.value = listOf(newCase) + _moderationCases.value

        logAudit(
            actionType = "REPORT_FILED",
            targetUser = targetUser,
            admin = "SYSTEM_WATCHDOG",
            reason = "Signalement pour $reason (Score de risque: $riskScore)",
            caseId = caseId
        )
        return report
    }

    // --- Moderation Operations with Server-Side Admin Auth Guard ---
    fun issueWarning(
        targetUser: String,
        caseId: String,
        reason: String,
        adminName: String,
        caller: UserProfile = _currentUser.value
    ): AdminOperationResult<ModerationAction> {
        if (!AdminAuthGuard.hasPermission(caller, "canModerate")) {
            logAudit("UNAUTHORIZED_MODERATION_ATTEMPT", targetUser, caller.username, "Tentative d'émission d'avertissement non autorisée", caseId)
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé : Privilège de modération requis.",
                requiredPermission = "canModerate",
                callerRole = caller.role
            )
        }
        val actionId = "act_" + UUID.randomUUID().toString().take(8)
        val action = ModerationAction(
            id = actionId,
            user = targetUser,
            moderation_case = caseId,
            action_type = ActionType.WARNING,
            reason = reason,
            start_date = System.currentTimeMillis(),
            end_date = null,
            issued_by = adminName,
            created_at = System.currentTimeMillis()
        )
        _moderationActions.value = listOf(action) + _moderationActions.value

        updateManagedUserSanction(
            targetUser = targetUser,
            newStatus = AccountStatus.WARNING,
            reason = reason,
            incrementWarning = true,
            durationDays = null
        )

        markCaseResolved(caseId)
        logAudit("WARNING_ISSUED", targetUser, adminName, reason, caseId)
        return AdminOperationResult.Success(action, "Avertissement officiel émis.")
    }

    fun applyRestriction(
        targetUser: String,
        caseId: String,
        features: List<NexFeature>,
        durationDays: Int,
        reason: String,
        adminName: String,
        caller: UserProfile = _currentUser.value
    ): AdminOperationResult<UserRestriction> {
        if (!AdminAuthGuard.hasPermission(caller, "canModerate")) {
            logAudit("UNAUTHORIZED_MODERATION_ATTEMPT", targetUser, caller.username, "Tentative de restriction non autorisée", caseId)
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé : Privilège de modération requis.",
                requiredPermission = "canModerate",
                callerRole = caller.role
            )
        }
        val now = System.currentTimeMillis()
        val endDate = now + (durationDays * 86400000L)
        val restrictionId = "rst_" + UUID.randomUUID().toString().take(8)

        val restriction = UserRestriction(
            id = restrictionId,
            user = targetUser,
            restriction_type = "FEATURE_LIMIT",
            affected_features = features,
            start_date = now,
            end_date = endDate,
            active = true,
            reason = reason
        )
        _activeRestrictions.value = listOf(restriction) + _activeRestrictions.value

        val actionId = "act_" + UUID.randomUUID().toString().take(8)
        val action = ModerationAction(
            id = actionId,
            user = targetUser,
            moderation_case = caseId,
            action_type = ActionType.RESTRICTION,
            reason = "$reason (${features.joinToString { it.label }})",
            start_date = now,
            end_date = endDate,
            issued_by = adminName,
            created_at = now
        )
        _moderationActions.value = listOf(action) + _moderationActions.value

        updateManagedUserSanction(
            targetUser = targetUser,
            newStatus = AccountStatus.RESTRICTED,
            reason = reason,
            incrementWarning = false,
            durationDays = durationDays
        )

        markCaseResolved(caseId)
        logAudit("RESTRICTION_APPLIED", targetUser, adminName, reason, caseId)
        return AdminOperationResult.Success(restriction, "Restriction appliquée avec succès.")
    }

    fun applySuspension(
        targetUser: String,
        caseId: String,
        durationDays: Int,
        reason: String,
        adminName: String,
        caller: UserProfile = _currentUser.value
    ): AdminOperationResult<ModerationAction> {
        if (!AdminAuthGuard.hasPermission(caller, "canModerate")) {
            logAudit("UNAUTHORIZED_MODERATION_ATTEMPT", targetUser, caller.username, "Tentative de suspension non autorisée", caseId)
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé : Privilège de modération requis.",
                requiredPermission = "canModerate",
                callerRole = caller.role
            )
        }
        val now = System.currentTimeMillis()
        val endDate = now + (durationDays * 86400000L)
        val actionId = "act_" + UUID.randomUUID().toString().take(8)

        val action = ModerationAction(
            id = actionId,
            user = targetUser,
            moderation_case = caseId,
            action_type = ActionType.TEMPORARY_SUSPENSION,
            reason = reason,
            start_date = now,
            end_date = endDate,
            issued_by = adminName,
            created_at = now
        )
        _moderationActions.value = listOf(action) + _moderationActions.value

        updateManagedUserSanction(
            targetUser = targetUser,
            newStatus = AccountStatus.TEMPORARILY_SUSPENDED,
            reason = reason,
            incrementWarning = false,
            durationDays = durationDays
        )

        markCaseResolved(caseId)
        logAudit("SUSPENSION_APPLIED", targetUser, adminName, reason, caseId)
        return AdminOperationResult.Success(action, "Suspension appliquée.")
    }

    fun applyPermanentBan(
        targetUser: String,
        caseId: String,
        reason: String,
        adminName: String,
        caller: UserProfile = _currentUser.value
    ): AdminOperationResult<ModerationAction> {
        if (!AdminAuthGuard.hasPermission(caller, "canModerate")) {
            logAudit("UNAUTHORIZED_MODERATION_ATTEMPT", targetUser, caller.username, "Tentative de bannissement non autorisée", caseId)
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé : Privilège de modération requis.",
                requiredPermission = "canModerate",
                callerRole = caller.role
            )
        }
        val now = System.currentTimeMillis()
        val endDate = now + (7 * 86400000L) // 7 days ban per user specification
        val actionId = "act_" + UUID.randomUUID().toString().take(8)

        val action = ModerationAction(
            id = actionId,
            user = targetUser,
            moderation_case = caseId,
            action_type = ActionType.PERMANENT_BAN,
            reason = reason,
            start_date = now,
            end_date = endDate,
            issued_by = adminName,
            created_at = now
        )
        _moderationActions.value = listOf(action) + _moderationActions.value

        updateManagedUserSanction(
            targetUser = targetUser,
            newStatus = AccountStatus.PERMANENTLY_BANNED,
            reason = reason,
            incrementWarning = false,
            durationDays = 7
        )

        markCaseResolved(caseId)
        logAudit("BAN_7D_EXECUTED", targetUser, adminName, reason, caseId)
        return AdminOperationResult.Success(action, "Bannissement appliqué.")
    }

    fun liftSanction(
        targetUser: String,
        actionId: String,
        reason: String,
        adminName: String,
        caller: UserProfile = _currentUser.value
    ): AdminOperationResult<Boolean> {
        if (!AdminAuthGuard.hasPermission(caller, "canModerate")) {
            logAudit("UNAUTHORIZED_MODERATION_ATTEMPT", targetUser, caller.username, "Tentative de levée de sanction non autorisée", null)
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé : Seuls les modérateurs ou administrateurs peuvent lever une sanction.",
                requiredPermission = "canModerate",
                callerRole = caller.role
            )
        }
        _activeRestrictions.value = _activeRestrictions.value.filterNot { it.user == targetUser }
        
        // Restore user to ACTIVE in directory
        _managedUsers.value = _managedUsers.value.map { user ->
            if (user.username == targetUser || user.userId == targetUser) {
                user.copy(
                    status = AccountStatus.ACTIVE,
                    currentRestrictionReason = null,
                    restrictionStartDate = null,
                    restrictionEndDate = null
                )
            } else user
        }

        if (_currentUser.value.username == targetUser || _currentUser.value.userId == targetUser) {
            _currentUser.value = _currentUser.value.copy(
                status = AccountStatus.ACTIVE,
                currentRestrictionReason = null,
                restrictionStartDate = null,
                restrictionEndDate = null
            )
        }
        rateLimiter.clearUserHistory(targetUser)

        val liftAction = ModerationAction(
            id = "act_" + UUID.randomUUID().toString().take(8),
            user = targetUser,
            moderation_case = "case_lift",
            action_type = ActionType.SANCTION_LIFTED,
            reason = "Sanction levée : $reason",
            start_date = System.currentTimeMillis(),
            end_date = null,
            issued_by = adminName,
            created_at = System.currentTimeMillis()
        )
        _moderationActions.value = listOf(liftAction) + _moderationActions.value
        logAudit("SANCTION_LIFTED", targetUser, adminName, reason, null)
        return AdminOperationResult.Success(true, "Sanction levée et compte réactivé.")
    }

    private fun updateManagedUserSanction(
        targetUser: String,
        newStatus: AccountStatus,
        reason: String,
        incrementWarning: Boolean,
        durationDays: Int?
    ) {
        val now = System.currentTimeMillis()
        val end = durationDays?.let { now + (it * 86400000L) }

        _managedUsers.value = _managedUsers.value.map { user ->
            if (user.username == targetUser || user.userId == targetUser) {
                user.copy(
                    status = newStatus,
                    warningCount = if (incrementWarning) user.warningCount + 1 else user.warningCount,
                    currentRestrictionReason = reason,
                    restrictionStartDate = now,
                    restrictionEndDate = end
                )
            } else user
        }

        if (_currentUser.value.username == targetUser || _currentUser.value.userId == targetUser) {
            _currentUser.value = _currentUser.value.copy(
                status = newStatus,
                warningCount = if (incrementWarning) _currentUser.value.warningCount + 1 else _currentUser.value.warningCount,
                currentRestrictionReason = reason,
                restrictionStartDate = now,
                restrictionEndDate = end
            )
        }
    }

    // --- User Search & Management (Feature 2) ---
    fun searchUsers(
        query: String,
        caller: UserProfile = _currentUser.value
    ): AdminOperationResult<List<UserProfile>> {
        if (!AdminAuthGuard.hasPermission(caller, "canModerate") && !AdminAuthGuard.hasPermission(caller, "canManageUsers")) {
            logAudit("UNAUTHORIZED_USER_SEARCH", "GLOBAL_USERS", caller.username, "Tentative de recherche d'utilisateurs non autorisée", null)
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé : La recherche et la gestion des comptes sont réservées aux modérateurs et administrateurs.",
                requiredPermission = "canModerate",
                callerRole = caller.role
            )
        }
        val q = query.trim().removePrefix("@").lowercase()
        val all = _managedUsers.value
        val result = if (q.isBlank()) {
            all
        } else {
            all.filter { user ->
                user.username.lowercase().contains(q) ||
                user.displayName.lowercase().contains(q) ||
                user.userId.lowercase().contains(q)
            }
        }
        return AdminOperationResult.Success(result)
    }

    // --- Search Users by Role & Status (Feature 3) ---
    fun searchUsersByRole(
        query: String = "",
        roleFilter: String = "ALL",
        statusFilter: String = "ALL",
        caller: UserProfile = _currentUser.value
    ): AdminOperationResult<List<UserProfile>> {
        if (!AdminAuthGuard.hasPermission(caller, "canModerate") && !AdminAuthGuard.hasPermission(caller, "canManageUsers")) {
            logAudit("UNAUTHORIZED_USER_SEARCH", "GLOBAL_USERS", caller.username, "Tentative de recherche d'utilisateurs non autorisée", null)
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé : La recherche et la gestion des comptes sont réservées aux modérateurs et administrateurs.",
                requiredPermission = "canModerate",
                callerRole = caller.role
            )
        }
        val q = query.trim().removePrefix("@").lowercase(Locale.ROOT)
        val all = _managedUsers.value
        val result = all.filter { user ->
            val matchesQuery = q.isBlank() ||
                user.username.lowercase(Locale.ROOT).contains(q) ||
                user.displayName.lowercase(Locale.ROOT).contains(q) ||
                user.userId.lowercase(Locale.ROOT).contains(q) ||
                user.email.lowercase(Locale.ROOT).contains(q)

            val matchesRole = if (roleFilter.equals("ALL", ignoreCase = true)) true else user.role.name.equals(roleFilter, ignoreCase = true)
            val matchesStatus = if (statusFilter.equals("ALL", ignoreCase = true)) true else user.status.name.equals(statusFilter, ignoreCase = true)

            matchesQuery && matchesRole && matchesStatus
        }
        return AdminOperationResult.Success(result)
    }

    // --- User Role Management with Zero-Self-Elevation Protection (Feature 3) ---
    fun updateUserRole(
        targetUserId: String,
        newRole: UserRole,
        caller: UserProfile = _currentUser.value
    ): AdminOperationResult<UserProfile> {
        if (!AdminAuthGuard.hasPermission(caller, "canManageUsers") && !AdminAuthGuard.hasPermission(caller, "canEditConfig")) {
            logAudit("UNAUTHORIZED_ROLE_CHANGE_ATTEMPT", targetUserId, caller.username, "Tentative de modification de rôle non autorisée (Rôle: ${caller.role.name})", null)
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé : Privilèges de gestion des utilisateurs ou de configuration requis.",
                requiredPermission = "canManageUsers",
                callerRole = caller.role
            )
        }

        // Prevent self-role modification / self-elevation
        if (targetUserId == caller.userId || targetUserId == caller.username) {
            logAudit("SELF_ELEVATION_PREVENTED", targetUserId, caller.username, "Empêchement automatique d'auto-élévation de privilèges", null)
            return AdminOperationResult.Unauthorized(
                message = "Sécurité Serveur : Un utilisateur ne peut pas modifier son propre rôle ou auto-élever ses privilèges.",
                requiredPermission = "canManageUsers",
                callerRole = caller.role
            )
        }

        // Only SUPER_ADMIN can grant SUPER_ADMIN or ADMIN roles
        if (caller.role != UserRole.SUPER_ADMIN && (newRole == UserRole.SUPER_ADMIN || newRole == UserRole.ADMIN)) {
            logAudit("UNAUTHORIZED_PRIVILEGE_GRANT", targetUserId, caller.username, "Tentative d'attribution du rôle ${newRole.name} sans droits Super Admin", null)
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé : Seul un Super Administrateur peut attribuer le rôle ${newRole.displayName}.",
                requiredPermission = "SUPER_ADMIN",
                callerRole = caller.role
            )
        }

        var updatedUser: UserProfile? = null
        val oldRole = _managedUsers.value.find { it.userId == targetUserId || it.username == targetUserId }?.role?.displayName ?: "Inconnu"

        _managedUsers.value = _managedUsers.value.map { user ->
            if (user.userId == targetUserId || user.username == targetUserId) {
                val modified = user.copy(role = newRole)
                updatedUser = modified
                modified
            } else user
        }

        if (updatedUser == null) {
            return AdminOperationResult.ValidationError("targetUserId", "Utilisateur non trouvé dans l'annuaire.")
        }

        logAudit(
            actionType = "USER_ROLE_UPDATED",
            targetUser = updatedUser!!.username,
            admin = caller.username,
            reason = "Rôle de l'utilisateur modifié de '$oldRole' vers '${newRole.displayName}'.",
            caseId = null
        )

        return AdminOperationResult.Success(updatedUser!!, "Rôle de @${updatedUser!!.username} mis à jour avec succès : ${newRole.displayName}")
    }

    // --- Log Search & Filtering with Pagination (Feature 2) ---
    fun searchAuditLogs(
        query: String = "",
        eventTypeFilter: String = "ALL",
        severityFilter: String = "ALL",
        userFilter: String = "",
        page: Int = 1,
        pageSize: Int = 10,
        caller: UserProfile = _currentUser.value
    ): AdminOperationResult<PaginatedAuditLogsResult> {
        if (!AdminAuthGuard.hasPermission(caller, "canViewAuditLogs") && !AdminAuthGuard.hasPermission(caller, "canEditConfig")) {
            logAudit("UNAUTHORIZED_LOG_SEARCH_ATTEMPT", "SYSTEM", caller.username, "Tentative de recherche des journaux non autorisée", null)
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé : Seuls les auditeurs et administrateurs autorisés peuvent effectuer des recherches dans les journaux.",
                requiredPermission = "canViewAuditLogs",
                callerRole = caller.role
            )
        }

        val allLogs = _auditLogs.value
        val q = query.trim().lowercase(Locale.ROOT)
        val u = userFilter.trim().lowercase(Locale.ROOT)

        val filtered = allLogs.filter { log ->
            val matchesQuery = q.isEmpty() ||
                log.action_type.lowercase(Locale.ROOT).contains(q) ||
                log.reason.lowercase(Locale.ROOT).contains(q) ||
                log.target_user.lowercase(Locale.ROOT).contains(q) ||
                log.administrator.lowercase(Locale.ROOT).contains(q) ||
                (log.related_case?.lowercase(Locale.ROOT)?.contains(q) == true)

            val matchesType = when (eventTypeFilter.uppercase(Locale.ROOT)) {
                "ALL" -> true
                "BAN_SUSPENSION" -> log.action_type.contains("BAN") || log.action_type.contains("SUSPENSION")
                "WARNING" -> log.action_type.contains("WARNING")
                "CONFIG" -> log.action_type.contains("CONFIG")
                "UNAUTHORIZED" -> log.action_type.contains("UNAUTHORIZED")
                "PRO" -> log.action_type.contains("PRO")
                else -> log.action_type.equals(eventTypeFilter, ignoreCase = true)
            }

            val matchesSeverity = when (severityFilter.uppercase(Locale.ROOT)) {
                "ALL" -> true
                "SECURITY" -> log.action_type.contains("UNAUTHORIZED") || log.action_type.contains("BAN")
                "ERROR" -> log.reason.contains("Erreur", ignoreCase = true) || log.reason.contains("Échec", ignoreCase = true)
                "WARNING" -> log.action_type.contains("WARNING")
                "INFO" -> true
                else -> true
            }

            val matchesUser = u.isEmpty() ||
                log.target_user.lowercase(Locale.ROOT).contains(u) ||
                log.administrator.lowercase(Locale.ROOT).contains(u)

            matchesQuery && matchesType && matchesSeverity && matchesUser
        }

        val totalCount = filtered.size
        val totalPages = maxOf(1, (totalCount + pageSize - 1) / pageSize)
        val validPage = page.coerceIn(1, totalPages)
        val fromIndex = ((validPage - 1) * pageSize).coerceIn(0, maxOf(0, totalCount))
        val toIndex = minOf(fromIndex + pageSize, totalCount)
        val pagedList = if (fromIndex < totalCount) filtered.subList(fromIndex, toIndex) else emptyList()

        // PII & Secret Sanitization
        val sanitizedPagedList = pagedList.map { log ->
            log.copy(reason = sanitizeLogText(log.reason))
        }

        return AdminOperationResult.Success(
            PaginatedAuditLogsResult(
                logs = sanitizedPagedList,
                totalCount = totalCount,
                currentPage = validPage,
                totalPages = totalPages,
                pageSize = pageSize
            )
        )
    }


    // --- Secure Audit Logs Export (Feature 1) ---
    fun exportAuditLogs(
        format: String = "JSON",
        caller: UserProfile = _currentUser.value
    ): AdminOperationResult<String> {
        if (!AdminAuthGuard.hasPermission(caller, "canViewAuditLogs") && !AdminAuthGuard.hasPermission(caller, "canEditConfig")) {
            logAudit("UNAUTHORIZED_LOG_EXPORT_ATTEMPT", "SYSTEM", caller.username, "Tentative d'export des journaux d'audit non autorisée", null)
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé : La consultation et l'exportation des journaux d'audit sont strictement réservées aux auditeurs et administrateurs autorisés.",
                requiredPermission = "canViewAuditLogs",
                callerRole = caller.role
            )
        }

        val logs = _auditLogs.value
        val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        dateFormat.timeZone = TimeZone.getTimeZone("UTC")

        // Zero-Trust PII and Secrets Sanitization
        val sanitizedLogs = logs.map { log ->
            val cleanReason = sanitizeLogText(log.reason)
            val cleanTarget = if (log.target_user.contains("@") && !log.target_user.startsWith("@")) {
                val parts = log.target_user.split("@")
                parts[0].take(2) + "•••@" + parts.getOrElse(1) { "nexchat.internal" }
            } else {
                log.target_user
            }
            log.copy(
                reason = cleanReason,
                target_user = cleanTarget
            )
        }

        val exportedContent = when (format.uppercase(Locale.ROOT)) {
            "CSV" -> buildCsvLogExport(sanitizedLogs, dateFormat, caller)
            else -> buildJsonLogExport(sanitizedLogs, dateFormat, caller)
        }

        logAudit(
            actionType = "AUDIT_LOGS_EXPORTED",
            targetUser = "SYSTEM",
            admin = caller.username,
            reason = "Export certifié des journaux d'audit (format: $format, ${sanitizedLogs.size} enregistrements). Données PII et secrets protégés.",
            caseId = null
        )

        return AdminOperationResult.Success(
            data = exportedContent,
            message = "Journaux d'audit exportés avec succès au format $format (${sanitizedLogs.size} événements protégés)."
        )
    }

    private fun sanitizeLogText(text: String): String {
        var clean = text
        // Mask passwords, tokens, API keys, session hashes, bearer tokens
        val secretPatterns = listOf(
            Regex("(?i)(password|motdepasse|pass|pwd)\\s*[:=]\\s*[^,\\s]+"),
            Regex("(?i)(token|bearer|jwt)\\s*[:=]\\s*[^,\\s]+"),
            Regex("(?i)(key|secret|api_key|apiKey)\\s*[:=]\\s*[^,\\s]+"),
            Regex("(?i)bearer\\s+[A-Za-z0-9\\-_=.]+"),
            Regex("\\b[A-Fa-f0-9]{32,64}\\b") // raw SHA-256 or MD5 hashes
        )
        for (pattern in secretPatterns) {
            clean = clean.replace(pattern) { match ->
                val prefix = match.value.split(":", "=", " ").firstOrNull() ?: "credential"
                "$prefix=[SECRET_PROTÉGÉ]"
            }
        }
        return clean
    }

    private fun buildJsonLogExport(
        logs: List<ModerationAuditLog>,
        dateFormat: SimpleDateFormat,
        caller: UserProfile
    ): String {
        val nowIso = dateFormat.format(Date())
        val sb = StringBuilder()
        sb.append("{\n")
        sb.append("  \"exportMetadata\": {\n")
        sb.append("    \"system\": \"NEXCHAT Trust & Safety Enterprise\",\n")
        sb.append("    \"exportedAt\": \"$nowIso\",\n")
        sb.append("    \"exportedBy\": \"${caller.username}\",\n")
        sb.append("    \"callerRole\": \"${caller.role.displayName}\",\n")
        sb.append("    \"totalEntries\": ${logs.size},\n")
        sb.append("    \"dataProtectionLevel\": \"ISO/IEC 27001 - PII & Secrets Zero-Trust Sanitized\",\n")
        sb.append("    \"integrityStatus\": \"VERIFIED_SECURE\"\n")
        sb.append("  },\n")
        sb.append("  \"securityEvents\": [\n")
        logs.forEachIndexed { index, log ->
            val dateStr = dateFormat.format(Date(log.timestamp))
            val escapedReason = log.reason.replace("\"", "\\\"").replace("\n", " ")
            sb.append("    {\n")
            sb.append("      \"id\": \"${log.id}\",\n")
            sb.append("      \"timestamp\": ${log.timestamp},\n")
            sb.append("      \"dateTimeUtc\": \"$dateStr\",\n")
            sb.append("      \"actionType\": \"${log.action_type}\",\n")
            sb.append("      \"targetUser\": \"${log.target_user}\",\n")
            sb.append("      \"administrator\": \"${log.administrator}\",\n")
            sb.append("      \"reason\": \"$escapedReason\",\n")
            sb.append("      \"relatedCase\": ${if (log.related_case != null) "\"${log.related_case}\"" else "null"}\n")
            sb.append("    }${if (index < logs.size - 1) "," else ""}\n")
        }
        sb.append("  ]\n")
        sb.append("}")
        return sb.toString()
    }

    private fun buildCsvLogExport(
        logs: List<ModerationAuditLog>,
        dateFormat: SimpleDateFormat,
        caller: UserProfile
    ): String {
        val sb = StringBuilder()
        sb.append("# NEXCHAT SECURE AUDIT LOG EXPORT\n")
        sb.append("# Exported By: ${caller.username} (${caller.role.displayName})\n")
        sb.append("# Exported At: ${dateFormat.format(Date())}\n")
        sb.append("# Protection: Zero-Trust Sanitized (No Passwords, Tokens or Secret Keys)\n")
        sb.append("ID,TIMESTAMP,DATETIME_UTC,ACTION_TYPE,TARGET_USER,ADMINISTRATOR,REASON,RELATED_CASE\n")
        logs.forEach { log ->
            val dateStr = dateFormat.format(Date(log.timestamp))
            val safeReason = "\"" + log.reason.replace("\"", "\"\"").replace("\n", " ") + "\""
            val safeTarget = "\"" + log.target_user.replace("\"", "\"\"") + "\""
            val safeCase = log.related_case ?: ""
            sb.append("${log.id},${log.timestamp},$dateStr,${log.action_type},$safeTarget,${log.administrator},$safeReason,$safeCase\n")
        }
        return sb.toString()
    }

    // --- Appeals Workflow ---
    fun submitAppeal(actionId: String, explanation: String): Appeal {
        val appealId = "apl_" + UUID.randomUUID().toString().take(8)
        val appeal = Appeal(
            id = appealId,
            user = _currentUser.value.username,
            moderation_action = actionId,
            explanation = explanation,
            created_at = System.currentTimeMillis(),
            appeal_status = AppealStatus.SUBMITTED
        )
        _appeals.value = listOf(appeal) + _appeals.value
        _currentUser.value = _currentUser.value.copy(status = AccountStatus.APPEAL_PENDING)
        logAudit("APPEAL_SUBMITTED", _currentUser.value.username, "USER", "Recours déposé : $explanation", null)
        return appeal
    }

    fun processAppeal(
        appealId: String,
        approve: Boolean,
        decisionReason: String,
        adminName: String,
        caller: UserProfile = _currentUser.value
    ): AdminOperationResult<Appeal> {
        if (!AdminAuthGuard.hasPermission(caller, "canModerate")) {
            logAudit("UNAUTHORIZED_MODERATION_ATTEMPT", "APPEAL", caller.username, "Tentative d'examen de recours non autorisée", null)
            return AdminOperationResult.Unauthorized(
                message = "Accès refusé : L'examen des recours est réservé aux modérateurs.",
                requiredPermission = "canModerate",
                callerRole = caller.role
            )
        }
        val appeal = _appeals.value.find { it.id == appealId }
            ?: return AdminOperationResult.ValidationError("appealId", "Dossier de recours introuvable.")

        val newStatus = if (approve) AppealStatus.APPROVED else AppealStatus.REJECTED

        val updated = appeal.copy(
            appeal_status = newStatus,
            reviewed_by = adminName,
            decision_reason = decisionReason,
            decision_date = System.currentTimeMillis()
        )
        _appeals.value = _appeals.value.map { if (it.id == appealId) updated else it }

        if (approve) {
            liftSanction(appeal.user, appeal.moderation_action, "Recours accepté : $decisionReason", adminName, caller)
        } else {
            if (_currentUser.value.username == appeal.user) {
                _currentUser.value = _currentUser.value.copy(status = AccountStatus.RESTRICTED)
            }
        }
        logAudit(
            actionType = if (approve) "APPEAL_APPROVED" else "APPEAL_REJECTED",
            targetUser = appeal.user,
            admin = adminName,
            reason = decisionReason,
            caseId = null
        )
        return AdminOperationResult.Success(updated, if (approve) "Recours accepté, sanction levée." else "Recours rejeté.")
    }

    private fun markCaseResolved(caseId: String) {
        _moderationCases.value = _moderationCases.value.map {
            if (it.id == caseId) it.copy(review_status = ReviewStatus.RESOLVED, reviewed_at = System.currentTimeMillis()) else it
        }
    }

    fun logAudit(actionType: String, targetUser: String, admin: String, reason: String, caseId: String?) {
        val entry = ModerationAuditLog(
            id = "log_" + UUID.randomUUID().toString().take(8),
            action_type = actionType,
            target_user = targetUser,
            administrator = admin,
            timestamp = System.currentTimeMillis(),
            reason = reason,
            related_case = caseId
        )
        _auditLogs.value = listOf(entry) + _auditLogs.value
    }

    fun addLiveComment(liveId: String, comment: String): Boolean {
        if (_currentUser.value.status == AccountStatus.PERMANENTLY_BANNED || _currentUser.value.status == AccountStatus.TEMPORARILY_SUSPENDED) {
            return false
        }
        val item = LiveComment(
            id = "lc_" + UUID.randomUUID().toString().take(8),
            liveId = liveId,
            authorName = _currentUser.value.displayName,
            comment = comment,
            timestamp = System.currentTimeMillis()
        )
        _liveComments.value = _liveComments.value + item
        return true
    }

    fun postStory(caption: String, gradientIndex: Int, mediaType: String = "TEXT", mediaUrl: String? = null): Boolean {
        val (allowed, _) = isFeatureAllowed(_currentUser.value, NexFeature.SEND_MESSAGES)
        if (!allowed) return false

        val story = StatusStory(
            id = "sty_" + UUID.randomUUID().toString().take(8),
            authorId = _currentUser.value.userId,
            authorName = _currentUser.value.displayName,
            textCaption = caption,
            backgroundGradientIndex = gradientIndex,
            mediaType = mediaType,
            mediaUrl = mediaUrl,
            timestamp = System.currentTimeMillis(),
            viewsCount = 1,
            viewersList = listOf("Vous-même")
        )
        _stories.value = listOf(story) + _stories.value
        return true
    }

    fun submitSupportTicket(
        email: String,
        nexchatId: String,
        category: TicketCategory,
        deviceType: String,
        description: String
    ): SupportTicket {
        val number = "NEX-" + Random.nextInt(10000, 99999)
        val ticket = SupportTicket(
            ticketNumber = number,
            userEmail = email,
            nexchatId = nexchatId,
            category = category,
            deviceType = deviceType,
            appVersion = "v2.5.0 (Build 2026.11)",
            description = description,
            status = TicketStatus.OPEN,
            createdAt = System.currentTimeMillis(),
            gmailEscalated = true,
            messages = listOf(
                TicketMessage(
                    sender = "Équipe Support NEXCHAT (Gmail)",
                    text = "Bonjour. Votre demande n° $number a bien été prise en charge. Notre équipe technique basée en Europe traite votre dossier avec la plus haute attention. Un accusé de réception a été envoyé à $email.",
                    timestamp = System.currentTimeMillis(),
                    isSupportStaff = true
                )
            )
        )
        _supportTickets.value = listOf(ticket) + _supportTickets.value
        return ticket
    }

    fun disconnectSession(sessionId: String) {
        _connectedSessions.value = _connectedSessions.value.filterNot { it.sessionId == sessionId }
        logAudit("SESSION_REVOKED", _currentUser.value.username, "USER", "Révocation de session $sessionId", null)
    }

    fun exportPersonalData() {
        logAudit("RGPD_DATA_EXPORTED", _currentUser.value.username, "USER", "Téléchargement de l'archive de données chiffrée.", null)
    }

    fun requestAccountDeletion() {
        logAudit("ACCOUNT_DELETION_REQUESTED", _currentUser.value.username, "USER", "Demande de suppression définitive du compte enregistrée.", null)
    }

    private fun createInitialVideoPosts(): List<VideoPost> {
        return listOf(
            VideoPost(
                id = "vid_01",
                authorId = "alex_tech",
                authorName = "Alexandre Dev",
                authorUsername = "alex_dev",
                caption = "⚡ Démonstration du protocole anti-spam intelligent de NexChat. Détection instantanée côté serveur !",
                videoDurationText = "0:45",
                timestamp = System.currentTimeMillis() - 3600000L * 3,
                likesCount = 142,
                likedByUsers = setOf("usr_user1", "usr_user2"),
                commentsCount = 18,
                comments = listOf(
                    VideoComment("vc_1", "Sarah", "sarah_mod", "Excellent travail sur la réduction de latence !", System.currentTimeMillis() - 3600000L),
                    VideoComment("vc_2", "Marc", "marc_dev", "Le toggle des likes est ultra fluide.", System.currentTimeMillis() - 1800000L)
                ),
                sharesCount = 24
            ),
            VideoPost(
                id = "vid_02",
                authorId = "nexchat_hq",
                authorName = "NexChat Officiel",
                authorUsername = "nexchat_hq",
                caption = "🚀 NexChat Pro est disponible ! Personnalisez votre thème néon, obtenez le badge VIP et débloquez les statuts 60s.",
                videoDurationText = "1:15",
                timestamp = System.currentTimeMillis() - 86400000L,
                likesCount = 589,
                likedByUsers = setOf("usr_user3"),
                commentsCount = 42,
                sharesCount = 89
            ),
            VideoPost(
                id = "vid_03",
                authorId = "elena_design",
                authorName = "Elena Design",
                authorUsername = "elena_ui",
                caption = "Aperçu de la nouvelle palette électrique Cyan & Deep Black pour l'application mobile 📱✨",
                videoDurationText = "0:25",
                timestamp = System.currentTimeMillis() - 86400000L * 2,
                likesCount = 312,
                likedByUsers = emptySet(),
                commentsCount = 9,
                sharesCount = 15
            )
        )
    }

    private fun createInitialCases(): List<ModerationCase> {
        return listOf(
            ModerationCase(
                id = "case_8412",
                user = "crypto_king_99",
                violation_type = "Fraude et escroquerie",
                description = "Envoi automatisé de liens vers un faux portefeuille prétendant doubler les fonds.",
                severity = Severity.CRITICAL,
                evidence_reference = "ref_hash_link_phish_09",
                detection_source = "FILTRE_AUTOMATIQUE",
                review_status = ReviewStatus.PENDING,
                created_at = System.currentTimeMillis() - 1800000L,
                reporter_user = "alice_martin"
            ),
            ModerationCase(
                id = "case_7291",
                user = "dark_shadow_x",
                violation_type = "Harcèlement et intimidation",
                description = "Menaces répétées et insultes ciblées en message privé.",
                severity = Severity.HIGH,
                evidence_reference = "ref_chat_transcript_7291",
                detection_source = "SIGNALEMENT_COMMUNAUTAIRE",
                review_status = ReviewStatus.PENDING,
                created_at = System.currentTimeMillis() - 7200000L,
                reporter_user = "julie_dupont"
            ),
            ModerationCase(
                id = "case_6310",
                user = "spambot_prime",
                violation_type = "Spam et messages répétitifs",
                description = "45 messages identiques en 60 secondes envoyés dans des canaux publics.",
                severity = Severity.MEDIUM,
                evidence_reference = "ref_flood_audit_6310",
                detection_source = "SYSTEME_ANTI_SPAM",
                review_status = ReviewStatus.PENDING,
                created_at = System.currentTimeMillis() - 14400000L,
                reporter_user = "system_flood_detector"
            )
        )
    }

    private fun createInitialActions(): List<ModerationAction> {
        return listOf(
            ModerationAction(
                id = "act_1092",
                user = "fake_admin_nex",
                moderation_case = "case_5502",
                action_type = ActionType.PERMANENT_BAN,
                reason = "Usurpation flagrante de l'équipe Trust & Safety.",
                start_date = System.currentTimeMillis() - 70000000L,
                end_date = null,
                issued_by = "Admin_Marc",
                created_at = System.currentTimeMillis() - 70000000L
            ),
            ModerationAction(
                id = "act_0941",
                user = "troll_gamer",
                moderation_case = "case_4190",
                action_type = ActionType.RESTRICTION,
                reason = "Restriction d'envoi de messages pendant 7 jours suite à spam répétitif en Live.",
                start_date = System.currentTimeMillis() - 86400000L * 2,
                end_date = System.currentTimeMillis() + 86400000L * 5,
                issued_by = "Mod_Sarah",
                created_at = System.currentTimeMillis() - 86400000L * 2,
                appeal_status = AppealStatus.SUBMITTED
            )
        )
    }

    private fun createInitialAppeals(): List<Appeal> {
        return listOf(
            Appeal(
                id = "apl_4412",
                user = "troll_gamer",
                moderation_action = "act_0941",
                explanation = "Je m'excuse sincèrement, c'était un message répété par enthousiasme lors du Live de mon ami. Je respecterai scrupuleusement les règles.",
                created_at = System.currentTimeMillis() - 3600000L * 12,
                appeal_status = AppealStatus.UNDER_REVIEW
            )
        )
    }

    private fun createInitialAuditLogs(): List<ModerationAuditLog> {
        return listOf(
            ModerationAuditLog(
                id = "log_01",
                action_type = "PERMANENT_BAN",
                target_user = "fake_admin_nex",
                administrator = "Admin_Marc",
                timestamp = System.currentTimeMillis() - 70000000L,
                reason = "Article 3 & 4 : Usurpation d'identité et tentative d'escroquerie",
                related_case = "case_5502"
            ),
            ModerationAuditLog(
                id = "log_02",
                action_type = "RESTRICTION",
                target_user = "troll_gamer",
                administrator = "Mod_Sarah",
                timestamp = System.currentTimeMillis() - 86400000L * 2,
                reason = "Article 1 : Spam de commentaires répétitifs en Live",
                related_case = "case_4190"
            )
        )
    }

    private fun createInitialTickets(): List<SupportTicket> {
        return listOf(
            SupportTicket(
                ticketNumber = "NEX-28190",
                userEmail = "hectorgilberson7@gmail.com",
                nexchatId = "hector_sec",
                category = TicketCategory.DATA_PRIVACY,
                deviceType = "Pixel 9 Pro",
                appVersion = "v2.5.0",
                description = "Demande d'export certifié des journaux de sessions et clés de chiffrement de bout en bout.",
                status = TicketStatus.IN_ANALYSIS,
                createdAt = System.currentTimeMillis() - 86400000L * 3,
                messages = listOf(
                    TicketMessage(
                        sender = "Support Technique Gmail (support@nexchat.io)",
                        text = "Votre archive de données personnelles RGPD a été préparée de manière chiffrée. Vous pouvez également lancer le téléchargement direct depuis vos Paramètres.",
                        timestamp = System.currentTimeMillis() - 86400000L * 2,
                        isSupportStaff = true
                    )
                )
            )
        )
    }

    private fun createInitialConversations(): List<Conversation> {
        return listOf(
            Conversation(
                id = "conv_ai",
                title = "NexChat AI Assistant ⚡",
                participantId = "nexchat_ai",
                avatarLetter = "AI",
                lastMessage = "Comment puis-je vous assister aujourd'hui ?",
                lastMessageTime = "12:30",
                unreadCount = 0,
                isOnline = true,
                isPinned = true
            ),
            Conversation(
                id = "conv_sarah",
                title = "Sarah Modératrice",
                participantId = "sarah_mod",
                avatarLetter = "S",
                lastMessage = "Les nouveaux seuils anti-spam ont été validés sur le serveur.",
                lastMessageTime = "11:45",
                unreadCount = 1,
                isOnline = true
            ),
            Conversation(
                id = "conv_marc",
                title = "Marc DevSecOps",
                participantId = "marc_dev",
                avatarLetter = "M",
                lastMessage = "Chiffrement de bout en bout opérationnel sur la v2.5 🔒",
                lastMessageTime = "Hier",
                unreadCount = 0,
                isOnline = false
            ),
            Conversation(
                id = "conv_elena",
                title = "Elena Rostova",
                participantId = "elena_r",
                avatarLetter = "E",
                lastMessage = "Tu as vu les nouvelles vidéos publiées dans l'onglet Vidéos ?",
                lastMessageTime = "Hier",
                unreadCount = 0,
                isOnline = true
            )
        )
    }

    private fun createInitialMessages(): List<ChatMessage> {
        return listOf(
            ChatMessage(
                id = "m1",
                conversationId = "conv_sarah",
                senderId = "sarah_mod",
                senderName = "Sarah Modératrice",
                text = "Bonjour Hector, nous avons revu les procédures de recours Trust & Safety.",
                timestamp = System.currentTimeMillis() - 3600000L * 2,
                isFromMe = false,
                status = MessageStatus.READ,
                reactionEmoji = "👍"
            ),
            ChatMessage(
                id = "m2",
                conversationId = "conv_sarah",
                senderId = "usr_948291",
                senderName = "Hector Gilberson",
                text = "Parfait, le module de recours garantit un examen humain impartial sous 48h.",
                timestamp = System.currentTimeMillis() - 3600000L,
                isFromMe = true,
                status = MessageStatus.READ
            ),
            ChatMessage(
                id = "m3",
                conversationId = "conv_sarah",
                senderId = "sarah_mod",
                senderName = "Sarah Modératrice",
                text = "Les nouveaux seuils anti-spam ont été validés sur le serveur.",
                timestamp = System.currentTimeMillis() - 900000L,
                isFromMe = false,
                status = MessageStatus.READ
            )
        )
    }

    private fun createInitialStories(): List<StatusStory> {
        return listOf(
            StatusStory(
                id = "st_01",
                authorId = "nexchat_official",
                authorName = "NEXCHAT Officiel",
                textCaption = "🚀 Déploiement réussi du protocole anti-spam & NexChat Pro v2.5 !",
                backgroundGradientIndex = 0,
                timestamp = System.currentTimeMillis() - 3600000L * 4,
                viewsCount = 342,
                viewersList = listOf("Sarah Modératrice", "Marc DevSecOps", "Elena Rostova")
            ),
            StatusStory(
                id = "st_02",
                authorId = "elena_r",
                authorName = "Elena Rostova",
                textCaption = "Les nouvelles couleurs bleu électrique et turquoise sont magnifiques ✨",
                backgroundGradientIndex = 1,
                timestamp = System.currentTimeMillis() - 3600000L * 6,
                viewsCount = 89,
                viewersList = listOf("Hector Gilberson", "Sarah Modératrice")
            )
        )
    }

    private fun createInitialLives(): List<LiveStream> {
        return listOf(
            LiveStream(
                id = "live_01",
                streamerId = "nexchat_hq",
                streamerName = "NEXCHAT Tech Live",
                title = "Table ronde : Sécurité et Vie Privée sur les Messageries Modernes",
                description = "Discussion en direct avec l'équipe d'ingénieurs et démonstration des outils de modération proactive.",
                viewersCount = 1420,
                isActive = true,
                startedAt = System.currentTimeMillis() - 1800000L,
                category = "Cybersécurité & Tech"
            ),
            LiveStream(
                id = "live_02",
                streamerId = "design_studio",
                streamerName = "Studio UI/UX",
                title = "Atelier Design System : Dark Mode & Cyan Glow",
                description = "Création d'interfaces modernes et ergonomie des bulles de discussion.",
                viewersCount = 480,
                isActive = true,
                startedAt = System.currentTimeMillis() - 2700000L,
                category = "Design"
            )
        )
    }

    private fun createInitialLiveComments(): List<LiveComment> {
        return listOf(
            LiveComment("c1", "live_01", "Alexandre", "Impressionnant le niveau de transparence sur les recours !", System.currentTimeMillis() - 300000L),
            LiveComment("c2", "live_01", "Claire", "Est-ce que le chiffrement de bout en bout couvre aussi les vocaux ?", System.currentTimeMillis() - 180000L),
            LiveComment("c3", "live_01", "Marc DevSecOps", "Oui Claire, tous les fichiers et vocaux sont chiffrés E2EE.", System.currentTimeMillis() - 60000L)
        )
    }

    private fun createInitialCallLogs(): List<CallRecord> {
        return listOf(
            CallRecord("call_1", "Sarah Modératrice", "sarah_mod", CallType.VIDEO, CallDirection.INCOMING, "14 min 32 s", System.currentTimeMillis() - 86400000L),
            CallRecord("call_2", "Marc DevSecOps", "marc_dev", CallType.AUDIO, CallDirection.OUTGOING, "08 min 12 s", System.currentTimeMillis() - 86400000L * 2),
            CallRecord("call_3", "Elena Rostova", "elena_r", CallType.VIDEO, CallDirection.MISSED, "Manqué", System.currentTimeMillis() - 86400000L * 3)
        )
    }

    private fun createInitialCommunities(): List<CommunityItem> {
        return listOf(
            CommunityItem(
                id = "com_official",
                name = "NEXCHAT Annonces Officielles",
                description = "Canal de diffusion officiel des nouveautés produit, mises à jour de sécurité et notes de version.",
                type = CommunityType.CHANNEL,
                memberCount = 128400,
                isOfficialVerified = true,
                isJoined = true
            ),
            CommunityItem(
                id = "com_security",
                name = "Communauté Sécurité & Trust",
                description = "Échanges bienveillants entre passionnés de sécurité applicative, cryptographie et protection des données.",
                type = CommunityType.GROUP,
                memberCount = 8940,
                isOfficialVerified = true,
                isJoined = true
            ),
            CommunityItem(
                id = "com_developers",
                name = "NEXCHAT Developers & Bots API",
                description = "Documentation et partages pour les développeurs certifiés NexChat API.",
                type = CommunityType.GROUP,
                memberCount = 4210,
                isOfficialVerified = false,
                isJoined = false
            )
        )
    }

    private fun createInitialManagedUsers(): List<UserProfile> {
        return listOf(
            UserProfile(
                userId = "usr_948291",
                username = "hector_sec",
                displayName = "Hector Gilberson",
                email = "hectorgilberson7@gmail.com",
                phone = "+33 6 •••• 12",
                bio = "Ingénieur sécurité & Trust Lead ⚡",
                status = AccountStatus.ACTIVE,
                role = UserRole.SUPER_ADMIN,
                warningCount = 0,
                isProSubscriber = true,
                proBadge = "VIP PRO ⚡"
            ),
            UserProfile(
                userId = "usr_102841",
                username = "sarah_mod",
                displayName = "Sarah Modératrice",
                email = "sarah.trust@nexchat.io",
                phone = "+33 6 •••• 45",
                bio = "Modératrice senior Trust & Safety",
                status = AccountStatus.ACTIVE,
                role = UserRole.MODERATOR,
                warningCount = 0
            ),
            UserProfile(
                userId = "usr_309182",
                username = "marc_dev",
                displayName = "Marc DevSecOps",
                email = "marc.infra@nexchat.io",
                phone = "+33 6 •••• 88",
                bio = "Lead DevOps & Cryptographie",
                status = AccountStatus.ACTIVE,
                role = UserRole.ADMIN,
                warningCount = 0
            ),
            UserProfile(
                userId = "usr_841209",
                username = "crypto_king_99",
                displayName = "Crypto King 💎",
                email = "crypto99@anonmail.com",
                phone = "+33 7 •••• 99",
                bio = "Gagnez 10x vos fonds en 24h !",
                status = AccountStatus.TEMPORARILY_SUSPENDED,
                role = UserRole.USER,
                warningCount = 2,
                currentRestrictionReason = "Envoi automatisé de liens frauduleux (Suspension 24h)"
            ),
            UserProfile(
                userId = "usr_729104",
                username = "dark_shadow_x",
                displayName = "Dark Shadow",
                email = "darkshadow@proton.me",
                phone = "+33 6 •••• 33",
                bio = "Membre de la communauté",
                status = AccountStatus.RESTRICTED,
                role = UserRole.USER,
                warningCount = 1,
                currentRestrictionReason = "Harcèlement en message privé (Restriction d'envoi 7j)"
            ),
            UserProfile(
                userId = "usr_631022",
                username = "spambot_prime",
                displayName = "SpamBot Prime",
                email = "bot_fleet@matrix.net",
                phone = "+33 7 •••• 01",
                bio = "Automated promotional broadcast",
                status = AccountStatus.WARNING,
                role = UserRole.USER,
                warningCount = 1,
                currentRestrictionReason = "Envoi massif de messages identiques (Anti-Spam Tier 1)"
            ),
            UserProfile(
                userId = "usr_550211",
                username = "fake_admin_nex",
                displayName = "NexChat Support Officiel (Faux)",
                email = "support-phish@fake-nex.io",
                phone = "+33 6 •••• 00",
                bio = "Donnez vos identifiants pour vérification",
                status = AccountStatus.PERMANENTLY_BANNED,
                role = UserRole.USER,
                warningCount = 3,
                currentRestrictionReason = "Usurpation flagrante de l'équipe Trust & Safety (Bannissement 7j)"
            ),
            UserProfile(
                userId = "usr_441290",
                username = "troll_gamer",
                displayName = "Troll Gamer 🎮",
                email = "gamer44@gmail.com",
                phone = "+33 6 •••• 77",
                bio = "Streamer et joueur passionné",
                status = AccountStatus.ACTIVE,
                role = UserRole.USER,
                warningCount = 1,
                currentRestrictionReason = "Sanction levée après recours accepté"
            ),
            UserProfile(
                userId = "usr_119283",
                username = "elena_r",
                displayName = "Elena Rostova",
                email = "elena.design@art.org",
                phone = "+33 6 •••• 62",
                bio = "UI/UX Designer & Photographe 🎨",
                status = AccountStatus.ACTIVE,
                role = UserRole.USER,
                warningCount = 0,
                isProSubscriber = true,
                proBadge = "PRO CREATOR ✨"
            ),
            UserProfile(
                userId = "usr_882194",
                username = "claire_fontaine",
                displayName = "Claire Fontaine",
                email = "claire.f@sorbonne.fr",
                phone = "+33 6 •••• 91",
                bio = "Étudiante en droit numérique 📚",
                status = AccountStatus.ACTIVE,
                role = UserRole.USER,
                warningCount = 0
            )
        )
    }
}
