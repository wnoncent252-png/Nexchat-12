package com.example.model

data class NexChatProPlan(
    val id: String,
    val name: String,
    val price: Double,
    val currency: String = "EUR",
    val priceFormatted: String,
    val periodMonths: Int,
    val billingFrequencyText: String,
    val savingsBadge: String? = null,
    val isPopular: Boolean = false,
    val features: List<String>
)

enum class PaymentGatewayStatus(val label: String) {
    LIVE_CONFIGURED("Passerelle Active (Serveur vérifié)"),
    SANDBOX_DEV("Mode Test & Développeur"),
    UNCONFIGURED("Passerelle non configurée (Configuration requise)")
}

data class ProTransactionRecord(
    val transactionId: String,
    val planId: String,
    val planName: String,
    val amountFormatted: String,
    val timestamp: Long,
    val status: String, // "CONFIRMED", "PENDING", "REFUNDED"
    val invoiceNumber: String
)

data class DynamicConfigHistoryItem(
    val id: String,
    val settingKey: String,
    val settingName: String,
    val oldValue: String,
    val newValue: String,
    val modifiedBy: String,
    val timestamp: Long
)

data class ServerAntiSpamConfig(
    val maxIdenticalMessages: Int = 3,
    val timeWindowSeconds: Int = 10,
    val repeatedSpamWarningThreshold: Int = 1,
    val temporaryRestrictionHours: Int = 2,
    val suspension24hEnabled: Boolean = true,
    val ban7dEnabled: Boolean = true,
    val autoRateLimitRequestsPerMinute: Int = 60,
    val burstMessageThreshold: Int = 5
)

data class RemoteDynamicConfig(
    val appAnnouncement: String = "⚡ Bienvenue sur NEXCHAT v2.5 — Chiffrement E2EE & Protection Anti-Spam",
    val announcementBannerEnabled: Boolean = true,
    val supportEmail: String = "support@nexchat.io",
    val officialRulesVersion: String = "v2.4.1",
    val maintenanceMode: Boolean = false,
    val maxAttachmentSizeMb: Int = 100,
    val e2eeEnforced: Boolean = true,
    val allowNewRegistrations: Boolean = true,
    val antiSpamConfig: ServerAntiSpamConfig = ServerAntiSpamConfig(),
    val proPlans: List<NexChatProPlan> = defaultProPlans(),
    val gatewayStatus: PaymentGatewayStatus = PaymentGatewayStatus.LIVE_CONFIGURED,
    val lastUpdatedTimestamp: Long = System.currentTimeMillis(),
    val configHistory: List<DynamicConfigHistoryItem> = emptyList()
)

fun defaultProPlans(): List<NexChatProPlan> {
    return listOf(
        NexChatProPlan(
            id = "pro_monthly",
            name = "NexChat Pro Mensuel",
            price = 4.99,
            currency = "EUR",
            priceFormatted = "4,99 € / mois",
            periodMonths = 1,
            billingFrequencyText = "Facturé mensuellement",
            savingsBadge = null,
            isPopular = false,
            features = listOf(
                "Badge VIP exclusif dans toutes les discussions",
                "Personnalisation néon intégrale (Bleu électrique & Turquoise)",
                "Fonds d'écran animés pour les chats",
                "Styles de bulles de messages exclusifs",
                "Téléversement de vidéos HD jusqu'à 2 Go",
                "Réponses prioritaires de NexChat AI"
            )
        ),
        NexChatProPlan(
            id = "pro_quarterly",
            name = "NexChat Pro Trimestriel",
            price = 12.99,
            currency = "EUR",
            priceFormatted = "12,99 € / 3 mois",
            periodMonths = 3,
            billingFrequencyText = "Facturé tous les 3 mois",
            savingsBadge = "Économisez 15%",
            isPopular = false,
            features = listOf(
                "Tous les avantages du forfait mensuel",
                "15% d'économie par rapport au mois par mois",
                "Sauvegarde chiffrée illimitée dans le Cloud",
                "Statuts vidéos de 60 secondes (au lieu de 30s)",
                "Support technique prioritaire par Gmail"
            )
        ),
        NexChatProPlan(
            id = "pro_annual",
            name = "NexChat Pro Annuel",
            price = 39.99,
            currency = "EUR",
            priceFormatted = "39,99 € / an",
            periodMonths = 12,
            billingFrequencyText = "Soit seulement 3,33 € / mois",
            savingsBadge = "MEILLEURE OFFRE — 35% d'Économie",
            isPopular = true,
            features = listOf(
                "Tous les avantages Pro débloqués",
                "35% d'économie annuelle",
                "Badge VIP Doré & Holographique",
                "Accès en avant-première aux nouvelles fonctionnalités",
                "Canal direct avec l'équipe de développement",
                "Garantie satisfait ou remboursé sous 14 jours"
            )
        )
    )
}
