package com.example.model

enum class NexFeature(val code: String, val label: String, val iconName: String) {
    SEND_MESSAGES("MESSAGES", "Envoi de messages privés", "Chat"),
    CREATE_GROUP("CREATE_GROUP", "Création de groupes", "GroupAdd"),
    CREATE_CHANNEL("CREATE_CHANNEL", "Création de chaînes publiques", "BroadcastOnPersonal"),
    SEND_INVITES("SEND_INVITES", "Invitations de membres", "PersonAdd"),
    START_LIVE("START_LIVE", "Diffusion de Lives vidéo", "LiveTv"),
    AUDIO_VIDEO_CALLS("CALLS", "Appels vocaux et vidéo", "Call")
}

data class UserRestriction(
    val id: String,
    val user: String, // User ID or username
    val restriction_type: String, // ex: "LIMIT_OUTBOUND", "COMMUNITY_LOCK", "FULL_RESTRICTION"
    val affected_features: List<NexFeature>,
    val start_date: Long,
    val end_date: Long,
    val active: Boolean,
    val reason: String
)
