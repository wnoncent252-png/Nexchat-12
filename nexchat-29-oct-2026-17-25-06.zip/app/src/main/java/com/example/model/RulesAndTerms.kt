package com.example.model

data class RuleItem(
    val id: String,
    val articleNumber: Int,
    val title: String,
    val summary: String,
    val fullDescription: String,
    val category: String,
    val severityLevel: String
)

data class TermsAcceptanceRecord(
    val userId: String,
    val rulesVersion: String,
    val acceptedAt: Long,
    val lastUpdated: Long,
    val ipHash: String = "hash_sha256_enc",
    val explicitConsentSignature: String = "NEXCHAT-EULA-ACCEPTED"
)

object NexChatOfficialRules {
    const val CURRENT_VERSION = "v2.4.1"
    const val LAST_UPDATED_DATE = "28 Octobre 2026"

    val rulesList = listOf(
        RuleItem(
            id = "rule_1",
            articleNumber = 1,
            title = "Spam et messages répétitifs abusifs",
            summary = "Interdiction d'envois massifs automatisés, de messages non sollicités ou d'inondation de canaux.",
            fullDescription = "Tout envoi massif, chaîne non sollicitée, inondation de discussions privées ou de groupes par des scripts ou manuellement est strictement interdit. Les seuils de fréquence sont contrôlés côté serveur.",
            category = "Intégrité des communications",
            severityLevel = "Modérée à Élevée"
        ),
        RuleItem(
            id = "rule_2",
            articleNumber = 2,
            title = "Harcèlement, menaces et intimidation",
            summary = "Tolérance zéro contre les menaces physiques, le harcèlement ciblé et les propos haineux.",
            fullDescription = "Toute forme de menace directe ou indirecte, dénigrement continu, persécution ciblée contre un individu ou un groupe entraîne une suspension immédiate avec conservation des preuves pour transmission légale si requis.",
            category = "Sécurité des personnes",
            severityLevel = "Critique"
        ),
        RuleItem(
            id = "rule_3",
            articleNumber = 3,
            title = "Usurpation d'identité et faux profils",
            summary = "Interdiction de se faire passer pour un tiers, une autorité ou un membre officiel de NexChat.",
            fullDescription = "L'usurpation de l'identité d'un autre utilisateur, d'une entité officielle ou de l'équipe NEXCHAT Trust & Safety entraîne la clôture immédiate du compte sans préavis.",
            category = "Authenticité",
            severityLevel = "Élevée"
        ),
        RuleItem(
            id = "rule_4",
            articleNumber = 4,
            title = "Fraude, arnaques et escroqueries",
            summary = "Interdiction de tromperie financière, phishing, vente pyramidale et faux gains.",
            fullDescription = "Toute tentative d'extorsion de fonds, de sollicitation frauduleuse, d'arnaque sentimentale ou de faux investissements mène à un bannissement permanent.",
            category = "Protection financière",
            severityLevel = "Critique"
        ),
        RuleItem(
            id = "rule_5",
            articleNumber = 5,
            title = "Tentatives de piratage et atteinte aux systèmes",
            summary = "Interdiction formelle de compromission des serveurs, d'injection ou de rétro-ingénierie malveillante.",
            fullDescription = "Toute exploitation de vulnérabilités, tentative d'injection SQL/NoSQL, contournement d'authentification ou reverse engineering non autorisé est poursuivie juridiquement.",
            category = "Sécurité infrastructure",
            severityLevel = "Critique"
        ),
        RuleItem(
            id = "rule_6",
            articleNumber = 6,
            title = "Vol de compte et accès non autorisé",
            summary = "Interdiction d'accéder au compte d'un tiers ou de voler des sessions / tokens d'authentification.",
            fullDescription = "Le détournement de sessions, la capture frauduleuse de mots de passe ou l'utilisation d'identifiants dérobés est sanctionné par un verrouillage d'urgence.",
            category = "Protection des comptes",
            severityLevel = "Critique"
        ),
        RuleItem(
            id = "rule_7",
            articleNumber = 7,
            title = "Diffusion de logiciels malveillants et liens dangereux",
            summary = "Interdiction formelle de partage de virus, trojans, ransomwares ou liens de phishing.",
            fullDescription = "Les filtres de sécurité analysent les condensats d'empreintes des pièces jointes signalées. La diffusion de charges actives déclenche la révocation instantanée du compte.",
            category = "Cybersécurité",
            severityLevel = "Critique"
        ),
        RuleItem(
            id = "rule_8",
            articleNumber = 8,
            title = "Publication de contenus illégaux et d'extrême violence",
            summary = "Interdiction absolue des contenus illicites, terrorisme et pornographie non consentie.",
            fullDescription = "Tout contenu enfreignant les lois internationales, faisant l'apologie d'actes criminels ou de violence extrême fait l'objet d'un bannissement immédiat et d'un signalement aux autorités compétentes.",
            category = "Conformité légale",
            severityLevel = "Critique"
        ),
        RuleItem(
            id = "rule_9",
            articleNumber = 9,
            title = "Partage de données personnelles sans consentement (Doxxing)",
            summary = "Protection de la vie privée: interdiction de publier adresses, téléphones ou documents privés.",
            fullDescription = "Divulguer des informations nominatives, coordonnées géographiques, documents d'identité ou correspondances privées sans l'accord explicite de la personne est passible de sanctions lourdes.",
            category = "Vie privée",
            severityLevel = "Élevée"
        ),
        RuleItem(
            id = "rule_10",
            articleNumber = 10,
            title = "Faux signalements et signalements abusifs",
            summary = "Interdiction d'utiliser le système de signalement pour nuire délibérément à autrui.",
            fullDescription = "Le harcèlement par signalements calomnieux répétés contre un utilisateur honnête entraîne des sanctions contre le compte de l'émetteur du faux signalement.",
            category = "Intégrité du système de modération",
            severityLevel = "Modérée à Élevée"
        ),
        RuleItem(
            id = "rule_11",
            articleNumber = 11,
            title = "Contournement délibéré d'une sanction",
            summary = "Interdiction de recréer un compte pour éluder un avertissement, une restriction ou un bannissement.",
            fullDescription = "La création de comptes clones ou l'utilisation de proxies/VPN pour contourner une sanction existante entraîne l'extension automatique du bannissement à toutes les sessions affiliées.",
            category = "Discipline plateforme",
            severityLevel = "Élevée"
        ),
        RuleItem(
            id = "rule_12",
            articleNumber = 12,
            title = "Utilisation de robots et scripts non autorisés",
            summary = "Interdiction d'automatisation des actions sans validation par l'API officielle NexChat.",
            fullDescription = "Le scraping, l'automatisation de likes/vues, ou l'utilisation de bots d'interaction non déclarés est prohibé afin de préserver l'authenticité des échanges.",
            category = "Intégrité applicative",
            severityLevel = "Modérée"
        ),
        RuleItem(
            id = "rule_13",
            articleNumber = 13,
            title = "Tentatives de perturbation de service (DDoS & Flooding)",
            summary = "Interdiction de saturer volontairement les passerelles d'appels, lives ou messagerie.",
            fullDescription = "La provocation volontaire de congestion réseau, d'appels répétés abusifs ou de saturation du service NexChat AI entraîne un blocage IP immédiat.",
            category = "Disponibilité de l'infrastructure",
            severityLevel = "Critique"
        ),
        RuleItem(
            id = "rule_14",
            articleNumber = 14,
            title = "Abus des fonctionnalités de Groupes, Chaînes et Lives",
            summary = "Obligation pour les modérateurs et diffuseurs de maintenir des espaces conformes aux règles.",
            fullDescription = "Les propriétaires de chaînes ou créateurs de lives sont coresponsables de la modération de leurs spectateurs. Les diffusions en direct doivent respecter scrupuleusement la dignité et la loi.",
            category = "Espaces communautaires",
            severityLevel = "Élevée"
        )
    )
}
