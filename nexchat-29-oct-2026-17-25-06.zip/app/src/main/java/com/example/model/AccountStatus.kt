package com.example.model

enum class AccountStatus(val label: String, val badgeColorHex: Long) {
    ACTIVE("Normal (Actif)", 0xFF10B981),
    WARNING("Niveau 1 — Avertissement", 0xFFF59E0B),
    RESTRICTED("Niveau 2 — Restriction temporaire", 0xFFF97316),
    TEMPORARILY_SUSPENDED("Niveau 3 — Suspension anti-spam 24h", 0xFFEF4444),
    PERMANENTLY_BANNED("Niveau 4 — Bannissement 7 jours", 0xFFDC2626),
    APPEAL_PENDING("Recours en cours d'examen", 0xFF06B6D4),
    UNDER_REVIEW("Dossier en révision", 0xFF8B5CF6)
}

enum class UserRole(
    val displayName: String,
    val canModerate: Boolean,
    val canManageUsers: Boolean,
    val canEditConfig: Boolean,
    val canManageBilling: Boolean,
    val canViewAuditLogs: Boolean
) {
    SUPER_ADMIN("Super Administrateur", true, true, true, true, true),
    ADMIN("Administrateur", true, true, true, true, true),
    MODERATOR("Modérateur Trust & Safety", true, false, false, false, true),
    SUPPORT_AGENT("Agent Support Client", false, false, false, false, false),
    ANALYST("Analyste Sécurité", false, false, false, false, true),
    USER("Utilisateur vérifié", false, false, false, false, false)
}

data class ConnectedDeviceSession(
    val sessionId: String,
    val deviceName: String,
    val deviceType: String, // Android, iOS, Web, Desktop
    val location: String,
    val ipAddress: String,
    val lastActive: Long,
    val isCurrent: Boolean = false
)

data class UserPrivacySettings(
    val whoCanSeeStatus: String = "Mes contacts",
    val readReceiptsEnabled: Boolean = true,
    val onlinePresenceVisible: Boolean = true,
    val whoCanCallMe: String = "Mes contacts",
    val whoCanAddToGroups: String = "Mes contacts",
    val biometricUnlock: Boolean = false,
    val blockedUsers: Set<String> = emptySet()
)

data class UserPersonalization(
    val primaryAccentColorHex: Long = 0xFF0066FF, // Electric Blue default
    val secondaryNeonColorHex: Long = 0xFF00F5D4, // Turquoise / Cyan default
    val chatWallpaperIndex: Int = 0,
    val bubbleStyleIndex: Int = 0,
    val isDarkTheme: Boolean = true,
    val themeMode: String = "DARK" // "SYSTEM", "LIGHT", "DARK"
)

data class UserProfile(
    val userId: String,
    val username: String,
    val displayName: String,
    val email: String,
    val phone: String = "+33 6 12 34 56 78",
    val bio: String = "Membre de la communauté sécurisée NEXCHAT ⚡",
    val avatarUrl: String = "",
    val status: AccountStatus = AccountStatus.ACTIVE,
    val role: UserRole = UserRole.USER,
    val warningCount: Int = 0,
    val currentRestrictionReason: String? = null,
    val restrictionStartDate: Long? = null,
    val restrictionEndDate: Long? = null,
    val privacySettings: UserPrivacySettings = UserPrivacySettings(),
    val personalization: UserPersonalization = UserPersonalization(),
    val termsAcceptance: TermsAcceptanceRecord? = null,
    val isProSubscriber: Boolean = false,
    val proPlanId: String? = null,
    val proExpiryDate: Long? = null,
    val proBadge: String? = null,
    val proAutoRenew: Boolean = true,
    val createdAt: Long = System.currentTimeMillis() - 86400000L * 45
)
