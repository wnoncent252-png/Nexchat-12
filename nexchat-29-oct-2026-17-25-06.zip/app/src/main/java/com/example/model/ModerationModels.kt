package com.example.model

enum class Severity(val label: String, val levelNumber: Int) {
    LOW("Faible (Info)", 1),
    MEDIUM("Moyenne", 2),
    HIGH("Élevée", 3),
    CRITICAL("Critique (Urgent)", 4)
}

enum class ReviewStatus(val label: String) {
    PENDING("En attente"),
    IN_PROGRESS("En cours d'examen"),
    RESOLVED("Résolu"),
    DISMISSED("Classé sans suite")
}

enum class ActionType(val label: String) {
    WARNING("Avertissement officiel"),
    RESTRICTION("Restriction de fonctionnalités"),
    TEMPORARY_SUSPENSION("Suspension temporaire"),
    PERMANENT_BAN("Bannissement permanent"),
    SANCTION_LIFTED("Sanction levée")
}

enum class AppealStatus(val label: String) {
    NONE("Aucun recours"),
    SUBMITTED("Recours déposé"),
    UNDER_REVIEW("En cours d'examen humain"),
    APPROVED("Recours accepté (sanction levée)"),
    REJECTED("Recours rejeté (sanction maintenue)")
}

data class ModerationCase(
    val id: String,
    val user: String, // Target user ID / username
    val violation_type: String,
    val description: String,
    val severity: Severity,
    val evidence_reference: String,
    val detection_source: String, // "SIGNALEMENT_COMMUNAUTAIRE", "FILTRE_AUTOMATIQUE", "SYSTEME_ANTI_SPAM"
    val review_status: ReviewStatus,
    val created_at: Long,
    val reviewed_at: Long? = null,
    val reporter_user: String? = null
)

data class ModerationAction(
    val id: String,
    val user: String,
    val moderation_case: String, // Reference to case ID
    val action_type: ActionType,
    val reason: String,
    val start_date: Long,
    val end_date: Long?, // Null if permanent ban or immediate warning
    val issued_by: String, // Moderator name / system
    val created_at: Long,
    val appeal_status: AppealStatus = AppealStatus.NONE
)

data class Appeal(
    val id: String,
    val user: String,
    val moderation_action: String, // Reference to ModerationAction id
    val explanation: String,
    val created_at: Long,
    val appeal_status: AppealStatus,
    val reviewed_by: String? = null,
    val decision_reason: String? = null,
    val decision_date: Long? = null
)

data class ModerationAuditLog(
    val id: String,
    val action_type: String,
    val target_user: String,
    val administrator: String,
    val timestamp: Long,
    val reason: String,
    val related_case: String?
)

data class PaginatedAuditLogsResult(
    val logs: List<ModerationAuditLog>,
    val totalCount: Int,
    val currentPage: Int,
    val totalPages: Int,
    val pageSize: Int
)


enum class ReportEntityType(val label: String) {
    USER_ACCOUNT("Compte utilisateur"),
    MESSAGE("Message privé"),
    STATUS_STORY("Statut / Story"),
    GROUP("Groupe de discussion"),
    CHANNEL("Chaîne publique"),
    SHARED_CONTENT("Pièce jointe / Média")
}

data class UserReport(
    val id: String,
    val reporterId: String,
    val entityType: ReportEntityType,
    val entityId: String,
    val targetUser: String,
    val reason: String,
    val detailedComment: String,
    val riskScore: Int, // 1 to 100 calculated automatically
    val isAutoUrgent: Boolean,
    val createdAt: Long,
    val relatedCaseId: String
)
