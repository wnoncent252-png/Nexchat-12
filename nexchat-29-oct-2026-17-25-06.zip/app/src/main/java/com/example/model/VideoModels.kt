package com.example.model

data class VideoComment(
    val id: String,
    val authorName: String,
    val authorUsername: String,
    val text: String,
    val timestamp: Long
)

data class VideoPost(
    val id: String,
    val authorId: String,
    val authorName: String,
    val authorUsername: String,
    val caption: String,
    val videoDurationText: String = "0:30",
    val timestamp: Long,
    val likesCount: Int,
    val likedByUsers: Set<String> = emptySet(), // Exact server-side record of user IDs who liked
    val commentsCount: Int,
    val comments: List<VideoComment> = emptyList(),
    val sharesCount: Int = 0,
    val tags: List<String> = listOf("NexChat", "Tech", "Sécurité")
)
