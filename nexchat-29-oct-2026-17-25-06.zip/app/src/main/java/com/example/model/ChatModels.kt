package com.example.model

enum class MessageStatus {
    SENDING, SENT, DELIVERED, READ
}

data class ChatMessage(
    val id: String,
    val conversationId: String,
    val senderId: String,
    val senderName: String,
    val text: String,
    val timestamp: Long,
    val isFromMe: Boolean,
    val status: MessageStatus = MessageStatus.READ,
    val mediaType: String? = null, // "AUDIO", "IMAGE", "VIDEO", "DOCUMENT"
    val mediaUrl: String? = null,
    val mediaName: String? = null,
    val mediaDurationOrSize: String? = null,
    val reactionEmoji: String? = null,
    val repliedToSnippet: String? = null,
    val isPinned: Boolean = false,
    val isEncrypted: Boolean = true,
    val isViewOnce: Boolean = false,
    val isViewed: Boolean = false
)

data class Conversation(
    val id: String,
    val title: String,
    val participantId: String,
    val avatarLetter: String,
    val lastMessage: String,
    val lastMessageTime: String,
    val unreadCount: Int = 0,
    val isOnline: Boolean = false,
    val isTyping: Boolean = false,
    val isPinned: Boolean = false,
    val isArchived: Boolean = false,
    val isEndToEndEncrypted: Boolean = true
)

data class StatusStory(
    val id: String,
    val authorId: String,
    val authorName: String,
    val textCaption: String,
    val backgroundGradientIndex: Int = 0,
    val mediaType: String = "TEXT", // "TEXT", "PHOTO", "VIDEO", "AUDIO"
    val mediaUrl: String? = null,
    val audioDurationSeconds: Int = 0,
    val timestamp: Long,
    val expiresAt: Long = timestamp + 86400000L, // 24h
    val viewsCount: Int = 0,
    val viewersList: List<String> = emptyList(),
    val audience: String = "Mes contacts"
)

data class LiveStream(
    val id: String,
    val streamerId: String,
    val streamerName: String,
    val title: String,
    val description: String,
    val viewersCount: Int,
    val isActive: Boolean = true,
    val startedAt: Long,
    val category: String = "Discussion Sécurisée"
)

data class LiveComment(
    val id: String,
    val liveId: String,
    val authorName: String,
    val comment: String,
    val timestamp: Long
)

enum class CallType { AUDIO, VIDEO }
enum class CallDirection { INCOMING, OUTGOING, MISSED }

data class CallRecord(
    val id: String,
    val contactName: String,
    val contactId: String,
    val type: CallType,
    val direction: CallDirection,
    val durationText: String,
    val timestamp: Long
)

enum class CommunityType { GROUP, CHANNEL }

data class CommunityItem(
    val id: String,
    val name: String,
    val description: String,
    val type: CommunityType,
    val memberCount: Int,
    val isOfficialVerified: Boolean = false,
    val isJoined: Boolean = false,
    val channelRuleSnippet: String = "Respect strict des règles NEXCHAT"
)
