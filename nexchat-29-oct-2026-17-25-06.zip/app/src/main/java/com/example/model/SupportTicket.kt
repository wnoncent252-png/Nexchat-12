package com.example.model

enum class TicketCategory(val label: String) {
    CONNECTION("Problème de connexion"),
    ACCOUNT_BLOCKED("Compte bloqué ou restreint"),
    ACCOUNT_HACKED("Compte piraté ou suspect"),
    MESSAGING("Problème de messagerie privée"),
    CALL_OR_LIVE("Problème d'appel ou de Live"),
    NOTIFICATIONS("Problème de notifications push"),
    USER_REPORT("Signalement d'un utilisateur"),
    DATA_PRIVACY("Demande concernant les données personnelles (RGPD)"),
    OTHER("Autre problème technique")
}

enum class TicketStatus(val label: String) {
    OPEN("Dossier ouvert"),
    IN_ANALYSIS("En cours d'analyse par l'équipe"),
    WAITING_USER("En attente de réponse utilisateur"),
    ESCALATED_ADMIN("Escaladé aux administrateurs"),
    RESOLVED("Résolu et archivé")
}

data class TicketMessage(
    val sender: String,
    val text: String,
    val timestamp: Long,
    val isSupportStaff: Boolean
)

data class SupportTicket(
    val ticketNumber: String, // ex: NEX-84920
    val userEmail: String,
    val nexchatId: String,
    val category: TicketCategory,
    val deviceType: String,
    val appVersion: String,
    val description: String,
    val status: TicketStatus,
    val createdAt: Long,
    val messages: List<TicketMessage> = emptyList(),
    val gmailEscalated: Boolean = true
)
