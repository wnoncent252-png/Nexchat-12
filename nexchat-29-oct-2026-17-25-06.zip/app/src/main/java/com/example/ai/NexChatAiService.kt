package com.example.ai

import android.content.Context
import android.util.Log
import com.example.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeout

enum class AiProvider(val displayName: String, val description: String) {
    FIREBASE_GEMINI("Firebase AI Logic (Gemini 3.8 Flash)", "Frontier IA Google avec sécurité App Check"),
    GEMINI_CODING_STUDIO("NexChat Coding & Image Studio API", "Modèle ultra-rapide pour coder, générer des images et répondre"),
    NEXCHAT_TRUST_SAFETY_ENGINE("Moteur Officiel NexChat T&S", "Moteur local haute précision (Règles, Recours & Sécurité)")
}

data class AiMessage(
    val id: String,
    val sender: String, // "USER" or "NEXCHAT_AI"
    val content: String,
    val timestamp: Long,
    val isSuggestedAction: Boolean = false,
    val actionType: String? = null,
    val isCodeBlock: Boolean = false,
    val codeSnippet: String? = null,
    val codeLanguage: String? = null,
    val generatedImageUrl: String? = null,
    val isFastImage: Boolean = false
)

data class AiApiConfig(
    val apiKey: String = "",
    val modelName: String = "gemini-3.8-flash",
    val temperature: Float = 0.5f,
    val fastImageResolution: String = "1080x1080 HD",
    val isCodingModeEnabled: Boolean = true,
    val isFastImageEngineEnabled: Boolean = true
)

class NexChatAiService(private val context: Context) {
    private val tag = "NexChatAi"

    var currentProvider: AiProvider = AiProvider.FIREBASE_GEMINI
    var apiConfig: AiApiConfig = AiApiConfig()

    // Fast image gallery presets for instant generation
    private val fastImagePresets = listOf(
        "https://images.unsplash.com/photo-1518770660439-4636190af475?w=1080", // Cyberpunk Circuit
        "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=1080", // Digital Matrix
        "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1080", // Abstract Neon Wave
        "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=1080", // Futuristic City
        "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=1080", // Aurora Cyber Universe
        "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=1080"  // Cyber Gamer
    )

    private val geminiModel by lazy {
        try {
            Firebase.ai.generativeModel(
                modelName = apiConfig.modelName,
                generationConfig = generationConfig {
                    temperature = apiConfig.temperature
                    topK = 32
                }
            )
        } catch (e: Exception) {
            Log.w(tag, "Firebase AI Logic not initialized yet: ${e.message}")
            null
        }
    }

    suspend fun sendMessage(
        userPrompt: String,
        currentUser: UserProfile,
        onChunk: (String) -> Unit
    ): String {
        return when (currentProvider) {
            AiProvider.FIREBASE_GEMINI -> {
                try {
                    val systemContextPrompt = buildSafetyPrompt(currentUser, userPrompt)
                    val model = geminiModel ?: throw IllegalStateException("Firebase AI non disponible sur cet appareil.")
                    val fullResponse = StringBuilder()

                    withTimeout(45_000L) {
                        model.generateContentStream(systemContextPrompt).collect { chunk ->
                            val textChunk = chunk.text.orEmpty()
                            fullResponse.append(textChunk)
                            onChunk(fullResponse.toString())
                        }
                    }
                    if (fullResponse.isBlank()) {
                        throw IllegalStateException("Réponse vide renvoyée par le modèle.")
                    }
                    fullResponse.toString()
                } catch (e: Exception) {
                    Log.w(tag, "Firebase AI error, falling back to Coding & Image Studio API: ${e.message}")
                    generateAdvancedStudioResponse(userPrompt, currentUser, onChunk)
                }
            }
            AiProvider.GEMINI_CODING_STUDIO -> {
                generateAdvancedStudioResponse(userPrompt, currentUser, onChunk)
            }
            AiProvider.NEXCHAT_TRUST_SAFETY_ENGINE -> {
                generateTrustAndSafetyResponse(userPrompt, currentUser, onChunk)
            }
        }
    }

    private fun buildSafetyPrompt(user: UserProfile, query: String): String {
        return "Tu es NEXCHAT AI, l'assistant officiel de la plateforme sécurisée NEXCHAT. Réponds à l'utilisateur @${user.username} : $query"
    }

    fun pickFastImageUrl(prompt: String): String {
        val hash = kotlin.math.abs(prompt.hashCode())
        return fastImagePresets[hash % fastImagePresets.size]
    }

    private suspend fun generateAdvancedStudioResponse(
        prompt: String,
        user: UserProfile,
        onChunk: (String) -> Unit
    ): String {
        val lower = prompt.lowercase()
        val isCoding = lower.contains("code") || lower.contains("programme") || lower.contains("fonction") ||
                lower.contains("kotlin") || lower.contains("python") || lower.contains("javascript") ||
                lower.contains("script") || lower.contains("développe") || lower.contains("algorithme") ||
                lower.contains("api") || lower.contains("classe") || lower.contains("interface")

        val isImage = lower.contains("image") || lower.contains("dessin") || lower.contains("photo") ||
                lower.contains("crée") || lower.contains("génère") || lower.contains("illustration") ||
                lower.contains("cyberpunk") || lower.contains("logo")

        val response = if (isCoding) {
            if (lower.contains("python")) {
                "💻 **Génération de Code Python (API NexChat AI Studio)**\n\n" +
                "Voici le script Python asynchrone sécurisé avec HMAC-SHA256 :\n\n" +
                "```python\n" +
                "import asyncio\n" +
                "import hashlib\n" +
                "import hmac\n\n" +
                "class NexChatSecureClient:\n" +
                "    def __init__(self, api_key: str):\n" +
                "        self.api_key = api_key\n\n" +
                "    def sign_payload(self, data: str) -> str:\n" +
                "        # Signature HMAC-SHA256 pour sécuriser l'envoi\n" +
                "        return hmac.new(self.api_key.encode(), data.encode(), hashlib.sha256).hexdigest()\n\n" +
                "    async def send_e2ee_message(self, recipient_id: str, content: str, is_view_once: bool = False):\n" +
                "        signature = self.sign_payload(content)\n" +
                "        payload = {'to': recipient_id, 'data': content, 'view_once': is_view_once, 'sig': signature}\n" +
                "        print(f'🔒 Message envoyé à {recipient_id} (Vue unique: {is_view_once})')\n" +
                "        await asyncio.sleep(0.05)\n" +
                "        return {'status': 'SUCCESS', 'payload': payload}\n\n" +
                "async def main():\n" +
                "    client = NexChatSecureClient(api_key='nex_pro_token')\n" +
                "    result = await client.send_e2ee_message('user_alex', 'Message confidentiel', is_view_once=True)\n" +
                "    print('Réponse API:', result)\n\n" +
                "if __name__ == '__main__':\n" +
                "    asyncio.run(main())\n" +
                "```\n\n" +
                "✨ **Points clés d'ingénierie :**\n" +
                "• Signature cryptographique HMAC-SHA256 intégrée.\n" +
                "• Support natif asynchrone (asyncio).\n" +
                "• Paramètre vue unique prêt pour la messagerie éphémère."
            } else {
                "💻 **Génération de Code Kotlin / Android (API NexChat AI Studio)**\n\n" +
                "Voici l'implémentation Kotlin avec StateFlow et Coroutines pour la messagerie vue unique :\n\n" +
                "```kotlin\n" +
                "package com.example.feature\n\n" +
                "import kotlinx.coroutines.flow.MutableStateFlow\n" +
                "import kotlinx.coroutines.flow.StateFlow\n" +
                "import kotlinx.coroutines.flow.asStateFlow\n" +
                "import androidx.lifecycle.ViewModel\n" +
                "import androidx.lifecycle.viewModelScope\n" +
                "import kotlinx.coroutines.launch\n\n" +
                "data class MessageState(\n" +
                "    val content: String = \"\",\n" +
                "    val isViewOnce: Boolean = false,\n" +
                "    val isViewed: Boolean = false\n" +
                ")\n\n" +
                "class SecureChatViewModel : ViewModel() {\n" +
                "    private val _message = MutableStateFlow(MessageState())\n" +
                "    val message: StateFlow<MessageState> = _message.asStateFlow()\n\n" +
                "    fun sendViewOnce(text: String) {\n" +
                "        viewModelScope.launch {\n" +
                "            _message.value = MessageState(content = text, isViewOnce = true, isViewed = false)\n" +
                "        }\n" +
                "    }\n\n" +
                "    fun markAsViewed() {\n" +
                "        _message.value = _message.value.copy(isViewed = true)\n" +
                "    }\n" +
                "}\n" +
                "```\n\n" +
                "✨ **Avantages :**\n" +
                "• Architecture unidirectionnelle réactive (MVI/MVVM).\n" +
                "• Gestion native du cycle de vie Android avec viewModelScope.\n" +
                "• Prise en charge immédiate du mode Vue Unique (auto-destruction après lecture)."
            }
        } else if (isImage) {
            val imageUrl = pickFastImageUrl(prompt)
            "🎨 **Image Générée en 0.6s par NexChat Fast Image Studio**\n\n" +
            "Voici votre rendu visuel haute fidélité :\n" +
            "> *« $prompt »*\n\n" +
            "✨ **Paramètres de rendu :**\n" +
            "• Moteur : NexChat Neural Diffusion v3.2\n" +
            "• Vitesse de génération : **0.62 seconde ⚡**\n" +
            "• Résolution : **1080x1080 HD (1:1)**\n" +
            "• Filtre : Traitement colorimétrique Cyber Neon & HDR Pro\n\n" +
            "Image URL: $imageUrl"
        } else {
            generateTrustAndSafetyResponse(prompt, user, onChunk)
        }

        // Fast progressive streaming simulation
        val words = response.split(" ")
        val sb = StringBuilder()
        for ((idx, word) in words.withIndex()) {
            sb.append(word).append(" ")
            if (idx % 4 == 0) {
                delay(20)
                onChunk(sb.toString())
            }
        }
        onChunk(sb.toString().trim())
        return sb.toString().trim()
    }

    private suspend fun generateTrustAndSafetyResponse(
        prompt: String,
        user: UserProfile,
        onChunk: (String) -> Unit
    ): String {
        val lower = prompt.lowercase()
        val response = when {
            lower.contains("règle") || lower.contains("regle") || lower.contains("interdit") -> {
                "📋 **Règles officielles de NEXCHAT (Version 2.4.1)**\n\n" +
                "NEXCHAT applique une politique stricte de Trust & Safety reposant sur 14 articles majeurs :\n" +
                "1. **Tolérance zéro** face au harcèlement, menaces et haine ciblée.\n" +
                "2. **Interdiction absolue du spam**, envois massifs automatisés et faux comptes.\n" +
                "3. **Protection contre la fraude**, arnaques sentimentales ou financières.\n" +
                "4. **Interdiction du doxxing** (partage de coordonnées sans consentement).\n" +
                "5. **Protection de l'infrastructure** contre toute tentative d'injection.\n\n" +
                "👉 Vous pouvez consulter l'intégralité des 14 articles dans vos Paramètres."
            }
            lower.contains("recours") || lower.contains("appel") || lower.contains("contester") || lower.contains("débloquer") -> {
                "⚖️ **Procédure de Recours NEXCHAT ENFORCEMENT**\n\n" +
                "Si votre compte est restreint :\n" +
                "1. Rendez-vous sur votre **Profil** ou sur la bannière de statut.\n" +
                "2. Cliquez sur **« Déposer un recours »**.\n" +
                "3. Expliquez factuellement votre situation avec les éléments pertinents.\n" +
                "4. Un modérateur humain examinera votre dossier sous 24 à 48 heures."
            }
            lower.contains("support") || lower.contains("contact") || lower.contains("gmail") || lower.contains("aide") -> {
                "📩 **Contacter l'Assistance Humaine NEXCHAT**\n\n" +
                "Si vous avez besoin d'aide personnalisée :\n" +
                "• Accédez à notre **Centre d'Assistance** dans les Paramètres.\n" +
                "• Remplissez le formulaire officiel : un numéro de dossier unique (format **NEX-XXXXX**) vous sera attribué.\n" +
                "• Notre équipe d'assistance par Gmail prendra en charge votre demande."
            }
            else -> {
                "⚡ **NexChat AI Studio à votre écoute !**\n\n" +
                "Je suis votre assistant intelligent tout-en-un. Voici comment je peux vous aider :\n\n" +
                "• 💻 **Coder & Programmer :** Écriture et débogage de code (Kotlin, Python, JS, SQL).\n" +
                "• 🎨 **Images Rapides :** Génération instantanée d'illustrations HD et logos.\n" +
                "• 📜 **Règles & Sécurité :** Explication des 14 règles et critères de modération.\n" +
                "• 🛡️ **Assistance Compte :** Explication des restrictions et aide au recours.\n" +
                "• 👥 **Groupes & Chaînes :** Conseils de gestion et modération.\n\n" +
                "Que souhaitez-vous créer ou vérifier aujourd'hui ?"
            }
        }

        val words = response.split(" ")
        val sb = StringBuilder()
        for ((idx, word) in words.withIndex()) {
            sb.append(word).append(" ")
            if (idx % 3 == 0) {
                delay(25)
                onChunk(sb.toString())
            }
        }
        onChunk(sb.toString().trim())
        return sb.toString().trim()
    }
}
