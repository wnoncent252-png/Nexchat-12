package com.example

import com.example.model.*
import com.example.repository.NexChatRepository
import com.example.security.AdminAuthGuard
import com.example.security.AdminOperationResult
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class NexChatSecurityModerationTest {

    private lateinit var repository: NexChatRepository

    @Before
    fun setUp() {
        repository = NexChatRepository()
    }

    @Test
    fun testOfficialRulesDataIntegrity() {
        assertEquals("v2.4.1", NexChatOfficialRules.CURRENT_VERSION)
        assertEquals(14, NexChatOfficialRules.rulesList.size)
        assertTrue(NexChatOfficialRules.rulesList.any { it.title.contains("Spam", ignoreCase = true) })
        assertTrue(NexChatOfficialRules.rulesList.any { it.title.contains("Harcèlement", ignoreCase = true) })
        assertTrue(NexChatOfficialRules.rulesList.any { it.title.contains("Usurpation", ignoreCase = true) })
        assertTrue(NexChatOfficialRules.rulesList.any { it.title.contains("Fraude", ignoreCase = true) })
    }

    @Test
    fun testTermsAcceptanceRecording() {
        val testUser = "usr_test_99"
        repository.acceptTerms(testUser)
        val record = repository.currentUser.value.termsAcceptance
        assertNotNull(record)
        assertEquals(testUser, record?.userId)
        assertEquals("v2.4.1", record?.rulesVersion)
        assertTrue(record?.acceptedAt ?: 0 > 0)
    }

    @Test
    fun testVideoLikesToggleOperation() {
        val video = repository.videoPosts.value.first()
        val initialLikes = video.likesCount

        // 1st click: adds like
        val (isLiked1, newCount1) = repository.toggleLikeVideo(video.id)
        assertTrue(isLiked1)
        assertEquals(initialLikes + 1, newCount1)

        // 2nd click: removes like
        val (isLiked2, newCount2) = repository.toggleLikeVideo(video.id)
        assertFalse(isLiked2)
        assertEquals(initialLikes, newCount2)
    }

    @Test
    fun testAntiSpamProgressiveTiers() {
        val testConvId = "conv_sarah"
        val spamText = "Message identique flood test"

        // 1st message: accepted
        val (res1, _) = repository.sendMessage(testConvId, spamText)
        assertTrue(res1)

        // 2nd message: accepted
        val (res2, _) = repository.sendMessage(testConvId, spamText)
        assertTrue(res2)

        // 3rd identical message triggers anti-spam warning (Tier 1)
        val (res3, spamNotice) = repository.sendMessage(testConvId, spamText)
        assertFalse(res3)
        assertNotNull(spamNotice)
        assertTrue(spamNotice?.contains("Anti-Spam", ignoreCase = true) == true)
        assertTrue(repository.currentUser.value.warningCount > 0)
    }

    @Test
    fun testSanction24hAnd7dAutoExpiration() {
        // Apply a sanction that ended 1 minute ago
        repository.setUserAccountStatus(
            status = AccountStatus.TEMPORARILY_SUSPENDED,
            reason = "Suspension 24h échue",
            durationMillis = -60000L
        )

        // Verify that checkAndAutoExpireSanctions restores user to ACTIVE
        repository.checkAndAutoExpireSanctions()
        assertEquals(AccountStatus.ACTIVE, repository.currentUser.value.status)
        assertNull(repository.currentUser.value.currentRestrictionReason)
    }

    @Test
    fun testNexChatProSubscriptionVerification() {
        // Subscribe to annual plan
        val tx = repository.subscribeToPro("pro_annual")
        assertNotNull(tx)
        assertEquals("CONFIRMED", tx.status)
        assertTrue(tx.invoiceNumber.startsWith("INV-NEX-"))

        val updatedUser = repository.currentUser.value
        assertTrue(updatedUser.isProSubscriber)
        assertEquals("pro_annual", updatedUser.proPlanId)
        assertNotNull(updatedUser.proExpiryDate)
        assertEquals("VIP PRO ⚡", updatedUser.proBadge)

        // Toggle auto renew
        repository.toggleProAutoRenew()
        assertFalse(repository.currentUser.value.proAutoRenew)
    }

    @Test
    fun testSuperAdminDynamicConfigurationWithoutRebuild() {
        // Authenticate caller as Super Admin
        repository.setUserRole(UserRole.SUPER_ADMIN)

        // Update price directly
        val priceResult = repository.updateProPlanPrice("pro_monthly", 5.99, "5,99 € / mois")
        assertTrue(priceResult is AdminOperationResult.Success)
        val updatedPlan = repository.dynamicConfig.value.proPlans.find { it.id == "pro_monthly" }
        assertEquals(5.99, updatedPlan?.price ?: 0.0, 0.01)
        assertEquals("5,99 € / mois", updatedPlan?.priceFormatted)

        // Update anti-spam thresholds directly
        val spamResult = repository.updateAntiSpamThresholds(maxIdentical = 4, timeWindowSeconds = 15, tempHours = 3)
        assertTrue(spamResult is AdminOperationResult.Success)
        val updatedSpamCfg = repository.dynamicConfig.value.antiSpamConfig
        assertEquals(4, updatedSpamCfg.maxIdenticalMessages)
        assertEquals(15, updatedSpamCfg.timeWindowSeconds)
        assertEquals(3, updatedSpamCfg.temporaryRestrictionHours)

        // Update announcement and general settings
        val annResult = repository.updateAnnouncement("⚡ Annonce Test Unitaire", isBannerEnabled = true)
        assertTrue(annResult is AdminOperationResult.Success)
        assertEquals("⚡ Annonce Test Unitaire", repository.dynamicConfig.value.appAnnouncement)
    }

    @Test
    fun testRolePermissionsMatrix() {
        // Super Admin has full powers
        assertTrue(UserRole.SUPER_ADMIN.canModerate)
        assertTrue(UserRole.SUPER_ADMIN.canManageUsers)
        assertTrue(UserRole.SUPER_ADMIN.canEditConfig)
        assertTrue(UserRole.SUPER_ADMIN.canManageBilling)
        assertTrue(UserRole.SUPER_ADMIN.canViewAuditLogs)

        // Admin has moderation, user and config management
        assertTrue(UserRole.ADMIN.canModerate)
        assertTrue(UserRole.ADMIN.canManageUsers)
        assertTrue(UserRole.ADMIN.canEditConfig)

        // Moderator can moderate and view logs but NOT edit billing or manage users
        assertTrue(UserRole.MODERATOR.canModerate)
        assertFalse(UserRole.MODERATOR.canManageUsers)
        assertFalse(UserRole.MODERATOR.canManageBilling)

        // User has no admin powers
        assertFalse(UserRole.USER.canModerate)
        assertFalse(UserRole.USER.canManageUsers)
        assertFalse(UserRole.USER.canEditConfig)
    }

    @Test
    fun testAdminAuthGuardBlocksRegularUserServerSide() {
        // Ensure user is regular USER
        repository.setUserRole(UserRole.USER)

        // Attempting to modify anti-spam threshold should return Unauthorized
        val result = repository.updateAntiSpamThresholds(maxIdentical = 2, timeWindowSeconds = 20, tempHours = 5)
        assertTrue(result is AdminOperationResult.Unauthorized)
        val unauth = result as AdminOperationResult.Unauthorized
        assertEquals("ERR_403_FORBIDDEN", unauth.errorCode)
        assertEquals("canEditConfig", unauth.requiredPermission)

        // Attempting to modify pricing should also return Unauthorized
        val priceResult = repository.updateProPlanPrice("pro_monthly", 1.99, "1,99 €")
        assertTrue(priceResult is AdminOperationResult.Unauthorized)

        // Attempting to issue a warning should return Unauthorized
        val warnResult = repository.issueWarning("target_user", "case_1", "Raison", "fake_admin")
        assertTrue(warnResult is AdminOperationResult.Unauthorized)

        // Verify unauthorized access attempt was logged to audit trail
        assertTrue(repository.auditLogs.value.any { it.action_type.contains("UNAUTHORIZED") })
    }

    @Test
    fun testDynamicConfigValidationAndAuditHistory() {
        repository.setUserRole(UserRole.SUPER_ADMIN)

        // Test validation: negative price should fail
        val invalidPrice = repository.updateProPlanPrice("pro_monthly", -5.0, "-5,00 €")
        assertTrue(invalidPrice is AdminOperationResult.ValidationError)

        // Test validation: invalid threshold (< 1) should fail
        val invalidThreshold = repository.updateAntiSpamThresholds(maxIdentical = 0, timeWindowSeconds = 10, tempHours = 2)
        assertTrue(invalidThreshold is AdminOperationResult.ValidationError)

        // Valid update records configuration history item
        repository.updateAntiSpamThresholds(maxIdentical = 5, timeWindowSeconds = 12, tempHours = 4)
        assertTrue(repository.dynamicConfig.value.configHistory.isNotEmpty())
        val latestHistory = repository.dynamicConfig.value.configHistory.first()
        assertEquals("antiSpamConfig", latestHistory.settingKey)
    }

    @Test
    fun testAppealsWorkflowAndSanctionLifting() {
        // Put user in suspended status
        repository.setUserAccountStatus(
            status = AccountStatus.TEMPORARILY_SUSPENDED,
            reason = "Suspension test pour recours",
            durationMillis = 86400000L
        )
        assertEquals(AccountStatus.TEMPORARILY_SUSPENDED, repository.currentUser.value.status)

        // Submit an appeal
        val appeal = repository.submitAppeal("act_test_123", "Je conteste formellement cette sanction.")
        assertNotNull(appeal)
        assertEquals(AccountStatus.APPEAL_PENDING, repository.currentUser.value.status)

        // As Moderator, approve the appeal
        repository.setUserRole(UserRole.MODERATOR)
        val processResult = repository.processAppeal(appeal.id, approve = true, decisionReason = "Erreur de détection vérifiée", adminName = "moderator_marc")
        assertTrue(processResult is AdminOperationResult.Success)

        // Sanction should be lifted and status restored to ACTIVE
        assertEquals(AccountStatus.ACTIVE, repository.currentUser.value.status)
        assertNull(repository.currentUser.value.currentRestrictionReason)
    }

    @Test
    fun testSecretMaskingNeverExposesTokens() {
        val secretKey = "sec_live_981290481204812"
        val masked = AdminAuthGuard.maskSecret(secretKey)
        assertFalse(masked.contains("981290481204812"))
        assertTrue(masked.contains("••••••••"))
        assertEquals("******", AdminAuthGuard.maskSecret("12345"))
        assertEquals("[AUCUN]", AdminAuthGuard.maskSecret(null))
    }

    @Test
    fun testExportAuditLogsWithPiAndSecretsSanitization() {
        val adminUser = repository.currentUser.value.copy(role = UserRole.SUPER_ADMIN)
        val regularUser = repository.currentUser.value.copy(role = UserRole.USER)

        // 1. Regular user cannot export logs (403 Forbidden)
        val unauthorizedResult = repository.exportAuditLogs("JSON", regularUser)
        assertTrue(unauthorizedResult is AdminOperationResult.Unauthorized)

        // 2. Add an audit log with potentially sensitive token / password pattern
        repository.logAudit(
            actionType = "SECURITY_INCIDENT",
            targetUser = "victim@domain.com",
            admin = "system_sec",
            reason = "Tentative de connexion avec token=eyJhbGciOiJIUzI1NiJ9.test and password: MySecretPassword123",
            caseId = "case_sec_01"
        )

        // 3. Admin exports in JSON format
        val jsonResult = repository.exportAuditLogs("JSON", adminUser)
        assertTrue(jsonResult is AdminOperationResult.Success)
        val jsonContent = (jsonResult as AdminOperationResult.Success).data
        assertNotNull(jsonContent)
        assertTrue(jsonContent.contains("exportMetadata"))
        assertTrue(jsonContent.contains("ISO/IEC 27001"))
        // Password and token MUST NOT be exposed
        assertFalse(jsonContent.contains("MySecretPassword123"))
        assertTrue(jsonContent.contains("[SECRET_PROTÉGÉ]"))

        // 4. Admin exports in CSV format
        val csvResult = repository.exportAuditLogs("CSV", adminUser)
        assertTrue(csvResult is AdminOperationResult.Success)
        val csvContent = (csvResult as AdminOperationResult.Success).data
        assertTrue(csvContent.contains("ID,TIMESTAMP,DATETIME_UTC,ACTION_TYPE,TARGET_USER,ADMINISTRATOR,REASON,RELATED_CASE"))
        assertFalse(csvContent.contains("MySecretPassword123"))

        // 5. Verify the export itself was recorded in audit log
        val latestLog = repository.auditLogs.value.first()
        assertEquals("AUDIT_LOGS_EXPORTED", latestLog.action_type)
    }

    @Test
    fun testSearchUsersByQueryAndPermissionGuard() {
        val adminUser = repository.currentUser.value.copy(role = UserRole.SUPER_ADMIN)
        val regularUser = repository.currentUser.value.copy(role = UserRole.USER)

        // 1. Regular user cannot search directory
        val unauthSearch = repository.searchUsers("crypto", regularUser)
        assertTrue(unauthSearch is AdminOperationResult.Unauthorized)

        // 2. Admin searches by pseudo without '@'
        val searchByPseudo = repository.searchUsers("crypto_king_99", adminUser)
        assertTrue(searchByPseudo is AdminOperationResult.Success)
        val list1 = (searchByPseudo as AdminOperationResult.Success).data
        assertEquals(1, list1.size)
        assertEquals("crypto_king_99", list1.first().username)

        // 3. Admin searches by pseudo with '@' prefix
        val searchWithAt = repository.searchUsers("@sarah_mod", adminUser)
        assertTrue(searchWithAt is AdminOperationResult.Success)
        val list2 = (searchWithAt as AdminOperationResult.Success).data
        assertEquals(1, list2.size)
        assertEquals("sarah_mod", list2.first().username)

        // 4. Admin searches by user ID
        val searchById = repository.searchUsers("usr_841209", adminUser)
        assertTrue(searchById is AdminOperationResult.Success)
        val list3 = (searchById as AdminOperationResult.Success).data
        assertEquals(1, list3.size)
        assertEquals("usr_841209", list3.first().userId)

        // 5. Admin searches with empty query returns all managed users
        val searchEmpty = repository.searchUsers("", adminUser)
        assertTrue(searchEmpty is AdminOperationResult.Success)
        val allUsers = (searchEmpty as AdminOperationResult.Success).data
        assertTrue(allUsers.size >= 8)
    }

    @Test
    fun testManagedUsersSanctionUpdateAndLift() {
        val admin = repository.currentUser.value.copy(role = UserRole.SUPER_ADMIN)

        // Issue warning to troll_gamer
        repository.issueWarning("troll_gamer", "case_test_warn", "Spam de commentaires", "Admin_Marc", admin)
        val userAfterWarn = repository.managedUsers.value.find { it.username == "troll_gamer" }
        assertNotNull(userAfterWarn)
        assertEquals(AccountStatus.WARNING, userAfterWarn?.status)
        assertEquals(2, userAfterWarn?.warningCount)

        // Suspend user 24h
        repository.applySuspension("troll_gamer", "case_test_susp", 1, "Répétition d'infraction", "Admin_Marc", admin)
        val userAfterSusp = repository.managedUsers.value.find { it.username == "troll_gamer" }
        assertEquals(AccountStatus.TEMPORARILY_SUSPENDED, userAfterSusp?.status)

        // Lift sanction
        val liftRes = repository.liftSanction("troll_gamer", "act_lift_1", "Pardon accordé", "Admin_Marc", admin)
        assertTrue(liftRes is AdminOperationResult.Success)
        val userAfterLift = repository.managedUsers.value.find { it.username == "troll_gamer" }
        assertEquals(AccountStatus.ACTIVE, userAfterLift?.status)
        assertNull(userAfterLift?.currentRestrictionReason)
    }
}
